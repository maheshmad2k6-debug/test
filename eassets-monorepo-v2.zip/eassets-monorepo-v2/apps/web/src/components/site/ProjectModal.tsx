import { useEffect, useState, useRef, type FormEvent } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { supabase, type Project, type ProjectMedia, type MediaLayout } from "@/lib/supabase";

interface Props {
  project: Project | null;
  onClose: () => void;
}

type Block =
  | { kind: "hero"; a: ProjectMedia }
  | { kind: "full"; a: ProjectMedia }
  | { kind: "mockup"; a: ProjectMedia }
  | { kind: "pair"; a: ProjectMedia; b: ProjectMedia };

function buildBlocks(media: ProjectMedia[]): Block[] {
  const out: Block[] = [];
  const sorted = [...media].sort((x, y) => x.sort_order - y.sort_order);
  let pendingLeft: ProjectMedia | null = null;

  const flushPending = () => {
    if (pendingLeft) {
      out.push({ kind: "full", a: pendingLeft });
      pendingLeft = null;
    }
  };

  for (const m of sorted) {
    const layout = (m.layout ?? "full") as MediaLayout;
    if (layout === "hero") { flushPending(); out.push({ kind: "hero", a: m }); continue; }
    if (layout === "full") { flushPending(); out.push({ kind: "full", a: m }); continue; }
    if (layout === "mockup") { flushPending(); out.push({ kind: "mockup", a: m }); continue; }
    if (layout === "left") {
      flushPending();
      pendingLeft = m;
      continue;
    }
    if (layout === "right") {
      if (pendingLeft) {
        out.push({ kind: "pair", a: pendingLeft, b: m });
        pendingLeft = null;
      } else {
        out.push({ kind: "full", a: m });
      }
      continue;
    }
  }
  flushPending();
  return out;
}

export function ProjectModal({ project, onClose }: Props) {
  const [media, setMedia] = useState<ProjectMedia[]>([]);
  const [showEnquire, setShowEnquire] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState("");
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const portalRef = useRef<HTMLDivElement | null>(null);

  // Create portal DOM node once
  useEffect(() => {
    const el = document.createElement("div");
    el.id = "project-modal-root";
    document.body.appendChild(el);
    portalRef.current = el;

    const style = document.createElement("style");
    style.id = "project-modal-style";
    style.textContent = `
      #project-modal-root { display: none; }
      #project-modal-root.open {
        display: block;
        position: fixed;
        inset: 0;
        z-index: 9999;
        background: var(--background);
        overflow-y: auto;
        overflow-x: hidden;
        -webkit-overflow-scrolling: touch;
      }
      #project-modal-root.open::-webkit-scrollbar { display: none; }
      #project-modal-root.open { -ms-overflow-style: none; scrollbar-width: none; }
    `;
    document.head.appendChild(style);

    return () => { el.remove(); style.remove(); };
  }, []);

  useEffect(() => {
    const el = portalRef.current;
    if (!el) return;

    if (project) {
      // Bug fix 1: lock body scroll so the background page doesn't scroll
      document.body.style.overflow = "hidden";
      // Bug fix 2: stop site Lenis so it doesn't fight with modal scroll
      window.dispatchEvent(new Event("lenis:stop"));
      el.classList.add("open");
      el.scrollTop = 0;

      setShowEnquire(false);
      setSent(false);
      setErr("");
      setMedia([]);

      supabase
        .from("project_media")
        .select("*")
        .eq("project_id", project.id)
        .order("sort_order")
        .then(({ data }) => setMedia(data ?? []));
    } else {
      el.classList.remove("open");
      // Bug fix 3: always restore body scroll and restart Lenis on close
      document.body.style.overflow = "";
      window.dispatchEvent(new Event("lenis:start"));
    }

    return () => {
      // Bug fix 4: restore body scroll on unmount/cleanup too
      document.body.style.overflow = "";
    };
  }, [project]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape" && project) onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [project, onClose]);

  if (!portalRef.current) return null;

  const blocks = buildBlocks(media);
  const year = project ? new Date(project.created_at).getFullYear() : "";

  async function submitEnquire(e: FormEvent) {
    e.preventDefault();
    if (!project) return;
    if (!name.trim() || !email.trim() || !phone.trim() || !message.trim()) {
      setErr("All fields are required.");
      return;
    }
    setSending(true);
    setErr("");
    const { error } = await supabase.from("project_inquiries").insert({
      project_id: project.id,
      project_title: project.title,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      message: message.trim(),
      status: "new",
    });
    setSending(false);
    if (error) setErr(error.message);
    else { setSent(true); setName(""); setEmail(""); setPhone(""); setMessage(""); }
  }

  return createPortal(
    <AnimatePresence>
      {project && (
        <motion.div
          key="proj"
          ref={scrollerRef}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          style={{ minHeight: "100%", color: "var(--foreground)" }}
        >
          {/* ── Sticky nav ── */}
          {/* Bug fix 5: sticky works because the modal root itself scrolls (overflow-y:auto),
              so position:sticky inside a normal flow child works correctly */}
          <div style={{
            position: "sticky", top: 0, zIndex: 10,
            borderBottom: "1px solid var(--border)",
            background: "var(--background)",
          }}>
            <div style={{ maxWidth: 1600, margin: "0 auto", padding: "0 20px", height: 64, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 16, minWidth: 0 }}>
                <button onClick={onClose} style={sCircle}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6"/></svg>
                </button>
                <div style={{ minWidth: 0 }}>
                  <p style={{ fontFamily: "monospace", fontSize: 10, letterSpacing: "0.3em", textTransform: "uppercase", color: "var(--muted-foreground)", marginBottom: 2 }}>
                    {project.sector || "Project"}
                  </p>
                  <h2 style={{ fontWeight: 600, fontSize: 18, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {project.title}
                  </h2>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
                {project.url && (
                  <button onClick={() => setShowPreview(true)} style={sGhost}>
                    Preview project <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 3h6v6M10 14L21 3M21 14v7H3V3h7"/></svg>
                  </button>
                )}
                <button onClick={() => setShowEnquire(true)} style={sPrimary}>
                  Send message <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
                </button>
                <button onClick={onClose} style={sCircle}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
              </div>
            </div>
          </div>

          {/* ── Title hero ── */}
          <div style={{ padding: "clamp(48px, 9vw, 80px) 20px clamp(24px, 5vw, 40px)", textAlign: "center" }}>
            <h1 style={{ fontWeight: 900, textTransform: "uppercase", lineHeight: 1, letterSpacing: "-0.02em", fontSize: "clamp(2rem, 9vw, 9rem)", wordBreak: "break-word" }}>
              {project.title}
            </h1>
            {project.description && (
              <p style={{ marginTop: 24, color: "var(--muted-foreground)", fontSize: "clamp(13px, 1.6vw, 16px)", maxWidth: 600, margin: "24px auto 0", lineHeight: 1.7, padding: "0 8px" }}>
                {project.description}
              </p>
            )}
          </div>

          {/* ── Media blocks ── */}
          {blocks.length === 0 ? (
            <p style={{ textAlign: "center", padding: "80px 20px", color: "var(--muted-foreground)", fontSize: 14 }}>No media uploaded yet.</p>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: "0 8px" }}>
              {blocks.map((blk, i) => (
                <div key={(blk.kind === "pair" ? blk.a.id + blk.b.id : blk.a.id) + i}>
  
                  {renderBlock(blk, project, portalRef.current, year)}
                </div>
              ))}
            </div>
          )}

          {/* ── Marquee ── */}
          <div style={{ marginTop: 80, borderTop: "1px solid var(--border)", padding: "24px 0", overflow: "hidden", userSelect: "none" }}>
            <div style={{ display: "flex", whiteSpace: "nowrap", animation: "marquee 18s linear infinite" }}>
              {Array.from({ length: 8 }).map((_, i) => (
                <span key={i} style={{ fontWeight: 900, textTransform: "uppercase", fontSize: "clamp(2.5rem, 7vw, 5rem)", color: "var(--muted-foreground)", opacity: 0.15, padding: "0 32px" }}>
                  MORE WORKS ✦
                </span>
              ))}
            </div>
          </div>

          {/* Bottom padding so content clears sticky nav on scroll */}
          <div style={{ height: 80 }} />

          {/* ── Enquire sheet ── */}
          <AnimatePresence>
            {showEnquire && (
              <motion.div
                key="enq"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                // Bug fix 6: position:fixed inside a portal on the body — works correctly
                style={{ position: "fixed", inset: 0, zIndex: 20, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}
                onClick={() => !sending && setShowEnquire(false)}
              >
                <motion.div
                  initial={{ y: 40, opacity: 0, scale: 0.96 }} animate={{ y: 0, opacity: 1, scale: 1 }} exit={{ y: 40, opacity: 0, scale: 0.96 }}
                  transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                  style={{ width: "100%", maxWidth: 560, maxHeight: "90vh", overflowY: "auto", background: "var(--card)", border: "1px solid var(--border)", borderRadius: 24, padding: "32px 24px" }}
                  onClick={e => e.stopPropagation()}
                >
                  {sent ? (
                    <div style={{ textAlign: "center", padding: "24px 0" }}>
                      <div style={{ width: 56, height: 56, borderRadius: "50%", background: "var(--primary)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px" }}>
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                      </div>
                      <h3 style={{ fontWeight: 600, fontSize: 20, marginBottom: 4 }}>Enquiry sent ✦</h3>
                      <p style={{ color: "var(--muted-foreground)", fontSize: 14 }}>We'll be in touch within 48 hours.</p>
                      <button onClick={() => setShowEnquire(false)} style={{ marginTop: 20, fontFamily: "monospace", fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "var(--primary)", background: "none", border: "none", cursor: "pointer" }}>Close</button>
                    </div>
                  ) : (
                    <form onSubmit={submitEnquire} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                        <div>
                          <p style={{ fontFamily: "monospace", fontSize: 10, letterSpacing: "0.3em", textTransform: "uppercase", color: "var(--primary)", marginBottom: 4 }}>Enquire about</p>
                          <h3 style={{ fontWeight: 600, fontSize: 18 }}>{project.title}</h3>
                        </div>
                        <button type="button" onClick={() => setShowEnquire(false)} style={sCircle}>
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                        </button>
                      </div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                        <input required type="text" placeholder="Your name *" value={name} onChange={e => setName(e.target.value)} style={sInput} />
                        <input required type="tel" placeholder="Phone *" value={phone} onChange={e => setPhone(e.target.value)} style={sInput} />
                      </div>
                      <input required type="email" placeholder="Email *" value={email} onChange={e => setEmail(e.target.value)} style={sInput} />
                      <textarea required rows={4} placeholder="What do you need? *" value={message} onChange={e => setMessage(e.target.value)} style={{ ...sInput, resize: "none" }} />
                      {err && <p style={{ color: "var(--destructive)", fontSize: 12 }}>{err}</p>}
                      <button type="submit" disabled={sending} style={{ padding: "12px", borderRadius: 999, background: "var(--primary)", color: "var(--primary-foreground)", border: "none", cursor: sending ? "not-allowed" : "pointer", opacity: sending ? 0.6 : 1, fontSize: 14, fontWeight: 500 }}>
                        {sending ? "Sending…" : "Send message →"}
                      </button>
                    </form>
                  )}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* ── Preview project overlay (laptop mockup, live iframe) ── */}
          <AnimatePresence>
            {showPreview && project.url && (
              <motion.div
                key="prev"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                style={{ position: "fixed", inset: 0, zIndex: 30, background: "rgba(0,0,0,0.88)", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}
                onClick={() => setShowPreview(false)}
              >
                <motion.div
                  initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
                  transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                  style={{ width: "100%", maxWidth: 1280, position: "relative" }}
                  onClick={e => e.stopPropagation()}
                >
                  <button onClick={() => setShowPreview(false)} style={{ ...sCircle, position: "absolute", top: -48, right: 0, color: "white", borderColor: "rgba(255,255,255,0.3)" }}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                  <div style={{ background: "linear-gradient(180deg, #2a2a2a, #111)", borderRadius: "18px 18px 4px 4px", padding: "14px 14px 0", boxShadow: "0 30px 80px rgba(0,0,0,0.6)" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, paddingBottom: 10 }}>
                      <span style={dot("#ff5f57")} /><span style={dot("#febc2e")} /><span style={dot("#28c840")} />
                      <div style={{ flex: 1, textAlign: "center", fontFamily: "monospace", fontSize: 10, color: "rgba(255,255,255,0.4)", letterSpacing: "0.2em" }}>
                        {project.title.toUpperCase()} · LIVE PREVIEW
                      </div>
                    </div>
                    <div style={{ background: "#fff", borderRadius: 6, overflow: "hidden", aspectRatio: "16/10" }}>
                      <iframe
                        src={project.url}
                        title={project.title}
                        style={{ width: "100%", height: "100%", border: 0, display: "block" }}
                        sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                      />
                    </div>
                  </div>
                  <div style={{ height: 14, background: "linear-gradient(180deg, #1a1a1a, #2a2a2a)", borderRadius: "0 0 22px 22px", margin: "0 -28px", boxShadow: "0 20px 40px -20px rgba(0,0,0,0.6)" }} />
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>,
    portalRef.current
  );
}


// Hero image — static, no scroll effects
function HeroBlock({ item, year, title, sector }: {
  item: ProjectMedia;
  portalEl?: HTMLDivElement | null;
  year: string | number;
  title: string;
  sector?: string;
}) {
  return (
    <div style={{ padding: "20px 24px 0", boxSizing: "border-box", width: "100%" }}>
      {/* Hero image */}
      <div style={{
        position: "relative",
        height: "clamp(320px, 78vh, 900px)",
        borderRadius: "16px 16px 0 0",
        overflow: "hidden",
        background: "var(--card)",
      }}>
        <MediaInner item={item} cover />
        <CornerBrackets />
      </div>

      {/* Meta card — always sits below the image, no movement */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr 1fr",
        padding: "clamp(16px, 3vw, 28px) clamp(16px, 3vw, 24px)",
        borderRadius: "0 0 16px 16px",
        background: "var(--card)",
        border: "1px solid var(--border)",
        borderTop: "none",
        marginBottom: 8,
      }}>
        <div>
          <p style={sMetaLabel}>Year</p>
          <p style={sMetaVal}>{year}</p>
        </div>
        <div style={{ textAlign: "center" }}>
          <p style={sMetaLabel}>Client</p>
          <p style={sMetaVal}>{title}</p>
        </div>
        <div style={{ textAlign: "right" }}>
          <p style={sMetaLabel}>Category</p>
          <p style={sMetaVal}>{sector || "Design"}</p>
        </div>
      </div>
    </div>
  );
}

function renderBlock(blk: Block, project: Project, portalEl?: HTMLDivElement | null, year?: string | number) {
  if (blk.kind === "hero") {
    return <HeroBlock item={blk.a} portalEl={portalEl} year={year ?? ""} title={project.title} sector={project.sector} />;
  }
  if (blk.kind === "full") {
    return (
      <div style={{ position: "relative", overflow: "hidden", aspectRatio: "16/9", background: "var(--card)" }}>
        <MediaInner item={blk.a} cover />
        <CornerBrackets />
      </div>
    );
  }
  if (blk.kind === "mockup") {
    return <LaptopMockup item={blk.a} project={project} />;
  }
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
      <MediaCell item={blk.a} />
      <MediaCell item={blk.b} />
    </div>
  );
}

function MediaCell({ item }: { item: ProjectMedia }) {
  return (
    <div style={{ position: "relative", overflow: "hidden", aspectRatio: "16/10", background: "var(--card)" }}>
      <MediaInner item={item} cover />
      <CornerBrackets />
    </div>
  );
}

function MediaInner({ item, cover, contain }: { item: ProjectMedia; cover?: boolean; contain?: boolean }) {
  const fit = contain ? "contain" : cover ? "cover" : "contain";
  const bg = contain ? "var(--background)" : undefined;
  return item.type === "video"
    ? <video src={item.url} style={{ width: "100%", height: "100%", objectFit: fit, background: bg }} autoPlay loop muted playsInline />
    : <img src={item.url} alt="" style={{ width: "100%", height: "100%", objectFit: fit, background: bg }} loading="lazy" />;
}

function LaptopMockup({ item, project }: { item: ProjectMedia; project: Project }) {
  const showLive = !!project.url;
  const [blocked, setBlocked] = useState(false);

  return (
    <div style={{ background: "var(--card)", padding: "48px 24px", display: "flex", justifyContent: "center" }}>
      <div style={{ width: "100%", maxWidth: 1200 }}>
        <div style={{
          position: "relative",
          background: "linear-gradient(180deg, #2a2a2a, #111)",
          borderRadius: "18px 18px 4px 4px",
          padding: "14px 14px 0",
          boxShadow: "0 30px 60px -20px rgba(0,0,0,0.5), inset 0 0 0 1px rgba(255,255,255,0.04)",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, paddingBottom: 10 }}>
            <span style={dot("#ff5f57")} /><span style={dot("#febc2e")} /><span style={dot("#28c840")} />
            <div style={{ flex: 1, textAlign: "center", fontFamily: "monospace", fontSize: 10, color: "rgba(255,255,255,0.4)", letterSpacing: "0.2em" }}>
              {project.title.toUpperCase()} · LIVE PREVIEW
            </div>
            {showLive && (
              <a
                href={project.url}
                target="_blank"
                rel="noopener noreferrer"
                style={{ fontFamily: "monospace", fontSize: 9, letterSpacing: "0.15em", color: "rgba(255,255,255,0.4)", textDecoration: "none", paddingRight: 4 }}
              >
                OPEN ↗
              </a>
            )}
          </div>
          <div style={{
            position: "relative",
            background: "#000",
            borderRadius: 6,
            overflow: "hidden",
            aspectRatio: "16/10",
          }}>
            {showLive && !blocked ? (
              <iframe
                key={project.url}
                src={project.url}
                title={project.title}
                style={{ width: "100%", height: "100%", border: 0, background: "#fff", display: "block" }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation"
                onError={() => setBlocked(true)}
              />
            ) : showLive && blocked ? (
              /* Site blocks iframe embedding — show fallback with direct link */
              <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16, background: "#0a0a0a" }}>
                <MediaInner item={item} cover />
                <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)" }}>
                  <p style={{ fontFamily: "monospace", fontSize: 11, color: "rgba(255,255,255,0.5)", letterSpacing: "0.2em" }}>SITE BLOCKS PREVIEW</p>
                  <a
                    href={project.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ padding: "10px 20px", borderRadius: 999, background: "white", color: "#000", fontSize: 13, fontWeight: 600, textDecoration: "none", display: "flex", alignItems: "center", gap: 6 }}
                  >
                    Visit Live Site ↗
                  </a>
                </div>
              </div>
            ) : (
              <MediaInner item={item} cover />
            )}
          </div>
        </div>
        <div style={{
          height: 14,
          background: "linear-gradient(180deg, #1a1a1a, #2a2a2a)",
          borderRadius: "0 0 22px 22px",
          margin: "0 -28px",
          boxShadow: "0 20px 40px -20px rgba(0,0,0,0.6)",
          position: "relative",
        }}>
          <div style={{
            position: "absolute", top: 0, left: "50%", transform: "translateX(-50%)",
            width: 110, height: 6, background: "#0a0a0a", borderRadius: "0 0 8px 8px",
          }} />
        </div>
      </div>
    </div>
  );
}

function dot(color: string): React.CSSProperties {
  return { width: 10, height: 10, borderRadius: "50%", background: color, display: "inline-block" };
}

function CornerBrackets() {
  const s = 20, sw = 1.5, c = "rgba(255,255,255,0.45)";
  return (
    <>
      <svg style={{ position:"absolute", top:10, left:10, pointerEvents:"none" }} width={s} height={s} viewBox={`0 0 ${s} ${s}`}><path d={`M${s} 0L0 0L0 ${s}`} fill="none" stroke={c} strokeWidth={sw}/></svg>
      <svg style={{ position:"absolute", top:10, right:10, pointerEvents:"none" }} width={s} height={s} viewBox={`0 0 ${s} ${s}`}><path d={`M0 0L${s} 0L${s} ${s}`} fill="none" stroke={c} strokeWidth={sw}/></svg>
      <svg style={{ position:"absolute", bottom:10, left:10, pointerEvents:"none" }} width={s} height={s} viewBox={`0 0 ${s} ${s}`}><path d={`M0 0L0 ${s}L${s} ${s}`} fill="none" stroke={c} strokeWidth={sw}/></svg>
      <svg style={{ position:"absolute", bottom:10, right:10, pointerEvents:"none" }} width={s} height={s} viewBox={`0 0 ${s} ${s}`}><path d={`M${s} 0L${s} ${s}L0 ${s}`} fill="none" stroke={c} strokeWidth={sw}/></svg>
    </>
  );
}

const sCircle: React.CSSProperties = { width:36, height:36, borderRadius:"50%", border:"1px solid var(--border)", background:"transparent", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", color:"var(--foreground)", flexShrink:0 };
const sPrimary: React.CSSProperties = { display:"inline-flex", alignItems:"center", gap:6, padding:"8px 16px", borderRadius:999, background:"var(--primary)", color:"var(--primary-foreground)", border:"none", fontSize:11, fontFamily:"monospace", letterSpacing:"0.18em", textTransform:"uppercase", cursor:"pointer" };
const sGhost: React.CSSProperties = { display:"inline-flex", alignItems:"center", gap:6, padding:"8px 14px", borderRadius:999, background:"transparent", color:"var(--foreground)", border:"1px solid var(--border)", fontSize:11, fontFamily:"monospace", letterSpacing:"0.18em", textTransform:"uppercase", cursor:"pointer" };
const sMetaLabel: React.CSSProperties = { fontFamily:"monospace", fontSize:10, letterSpacing:"0.25em", textTransform:"uppercase", color:"var(--muted-foreground)", marginBottom:4 };
const sMetaVal: React.CSSProperties = { fontWeight:700, fontSize:"clamp(1.2rem, 3vw, 1.8rem)" };
const sInput: React.CSSProperties = { width:"100%", background:"var(--background)", border:"1px solid var(--border)", borderRadius:12, padding:"10px 16px", fontSize:14, color:"var(--foreground)", outline:"none", boxSizing:"border-box" };
