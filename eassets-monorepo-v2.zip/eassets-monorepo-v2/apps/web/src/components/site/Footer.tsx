import { Logo } from "./Logo";

export function Footer() {
  return (
    <footer className="relative border-t border-border bg-background pt-20 pb-10">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="md:col-span-2">
            <Logo />
            <p className="mt-6 text-muted-foreground max-w-md">
              An independent web development studio crafting immersive digital experiences for ambitious teams worldwide.
            </p>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-4">Studio</h4>
            <ul className="space-y-3 text-sm">
              <li><a href="#work" className="hover:text-primary transition-colors">Work</a></li>
              <li><a href="#services" className="hover:text-primary transition-colors">Services</a></li>
              <li><a href="#process" className="hover:text-primary transition-colors">Process</a></li>
              <li><a href="#contact" className="hover:text-primary transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-4">Connect</h4>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-primary transition-colors">Dribbble</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Awwwards</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">GitHub</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">LinkedIn</a></li>
            </ul>
          </div>
        </div>

        <div className="font-display font-bold text-[clamp(3rem,15vw,12rem)] leading-none tracking-tighter text-gradient-crimson opacity-90 select-none">
          EAssets.
        </div>

        <div className="flex items-center justify-between flex-wrap gap-4 pt-10 mt-10 border-t border-border text-xs font-mono text-muted-foreground">
          <span>© 2026 EAssets Studio. All rights reserved.</span>
          <span>Crafted with care</span>
        </div>
      </div>
    </footer>
  );
}
