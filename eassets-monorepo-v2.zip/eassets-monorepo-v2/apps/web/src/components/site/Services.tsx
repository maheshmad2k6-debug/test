import { motion } from "framer-motion";
import svc1 from "@/assets/svc-1.jpg";
import svc2 from "@/assets/svc-2.jpg";
import svc3 from "@/assets/svc-3.jpg";
import svc4 from "@/assets/svc-4.jpg";

const EASE: [number, number, number, number] = [0.22, 1, 0.36, 1];

const services = [
  {
    n: "01",
    title: "Brand & Marketing Sites",
    body: "Award-worthy websites that convert visitors into believers.",
    image: svc1,
    items: [
      "Strategy & Positioning",
      "Identity & Art Direction",
      "Marketing Site Builds",
      "Continuous Iteration",
    ],
  },
  {
    n: "02",
    title: "3D & Interactive",
    body: "Immersive experiences your users screenshot and share.",
    image: svc2,
    items: [
      "Real-Time WebGL & Three.js",
      "Custom GLSL Shaders",
      "Motion-Driven Storytelling",
      "Product Configurators",
    ],
  },
  {
    n: "03",
    title: "Product & SaaS UI",
    body: "Polished design systems that scale with your roadmap.",
    image: svc3,
    items: [
      "Design Systems & Tokens",
      "Component Architecture",
      "Dashboards & Tooling",
      "Developer Experience",
    ],
  },
  {
    n: "04",
    title: "Performance Engineering",
    body: "We make slow feel instant — every millisecond matters.",
    image: svc4,
    items: [
      "Core Web Vitals Audits",
      "SSR & Edge Optimization",
      "Asset & Bundle Pipelines",
      "Accessibility & SEO",
    ],
  },
];

function ServiceCard({ svc, index }: { svc: (typeof services)[0]; index: number }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.25 }}
      transition={{ duration: 0.8, ease: EASE, delay: index * 0.05 }}
      className="rounded-3xl border border-border bg-card overflow-hidden"
    >
      <div className="grid grid-cols-1 md:grid-cols-[1.1fr_1fr] min-h-[26rem]">
        {/* LEFT — text */}
        <div className="p-7 lg:p-10 flex flex-col">
          <span className="font-mono text-xs text-muted-foreground tracking-widest mb-8">
            / {svc.n}
          </span>

          <h3 className="font-display font-semibold text-3xl lg:text-[2.4rem] tracking-tight leading-[1.05] text-foreground">
            {svc.title}
          </h3>

          <p className="mt-3 text-muted-foreground text-base lg:text-[1.05rem] leading-relaxed max-w-md">
            {svc.body}
          </p>

          <div className="mt-auto pt-10">
            <ul className="divide-y divide-border border-y border-border">
              {svc.items.map((item) => (
                <li
                  key={item}
                  className="py-3.5 font-mono text-[11px] lg:text-xs uppercase tracking-[0.18em] text-muted-foreground"
                >
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* RIGHT — image */}
        <div className="relative min-h-[16rem] md:min-h-full overflow-hidden bg-muted">
          <img
            src={svc.image}
            alt={svc.title}
            loading="lazy"
            width={1024}
            height={1024}
            className="absolute inset-0 w-full h-full object-cover grayscale"
          />
        </div>
      </div>
    </motion.article>
  );
}

export function Services() {
  return (
    <section id="services" className="relative bg-background py-32 lg:py-40">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-[0.85fr_1.15fr] gap-12 lg:gap-20 items-start">
          {/* LEFT — sticky intro */}
          <div className="lg:sticky lg:top-28">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.7, ease: EASE }}
            >
              <span className="inline-block px-2.5 py-1 border border-border rounded-md font-mono text-[10px] uppercase tracking-widest text-foreground bg-card mb-8">
                Services
              </span>
              <h2 className="font-display font-bold text-5xl lg:text-6xl xl:text-7xl tracking-tight leading-[1.02] text-foreground">
                Built to Simplify Operations
              </h2>
              <p className="mt-7 text-muted-foreground text-base lg:text-lg leading-relaxed max-w-md">
                We design intelligent systems that streamline workflows,
                strengthen revenue processes, and connect your tools into one
                cohesive ecosystem.
              </p>
            </motion.div>
          </div>

          {/* RIGHT — stacked cards */}
          <div className="flex flex-col gap-6 lg:gap-8">
            {services.map((svc, i) => (
              <ServiceCard key={svc.n} svc={svc} index={i} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
