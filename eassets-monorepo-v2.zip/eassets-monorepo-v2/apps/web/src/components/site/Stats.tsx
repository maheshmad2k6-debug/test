import { motion, useInView, animate } from "framer-motion";
import { useEffect, useRef, useState } from "react";

function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, to, {
      duration: 2,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setVal(v),
    });
    return () => controls.stop();
  }, [inView, to]);
  return (
    <span ref={ref} className="font-display font-bold text-6xl md:text-8xl tracking-tight">
      {Math.round(val)}{suffix}
    </span>
  );
}

const stats = [
  { value: 64, suffix: "+", label: "Shipped projects" },
  { value: 98, suffix: "", label: "Avg Lighthouse score" },
  { value: 12, suffix: "", label: "Awards & features" },
  { value: 24, suffix: "h", label: "Avg response time" },
];

export function Stats() {
  return (
    <section id="studio" className="relative py-32 lg:py-44 bg-card/30 border-y border-border">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-10 md:gap-6"
        >
          {stats.map((s) => (
            <div key={s.label}>
              <Counter to={s.value} suffix={s.suffix} />
              <p className="mt-3 text-sm text-muted-foreground max-w-[14ch]">{s.label}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
