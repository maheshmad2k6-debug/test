import { useRef } from "react";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";

const quotes = [
  {
    quote: "EAssets delivered something we genuinely didn't think was possible on the web. The launch traffic doubled our quarterly leads.",
    name: "Anika Roy",
    role: "Head of Marketing, Aurora Robotics",
  },
  {
    quote: "Pixel-perfect, blazing fast, and somehow it still feels playful. They set a new bar for our brand online.",
    name: "Marcus Lee",
    role: "Creative Director, Lumen Festival",
  },
  {
    quote: "The performance work alone paid for the project. Our Core Web Vitals went from red to green across every page.",
    name: "Priya Shah",
    role: "VP Engineering, Meridian Bank",
  },
];

const COUNT = quotes.length; // 3

export function Testimonials() {
  const ref = useRef<HTMLDivElement>(null);

  // Pin for COUNT screens — page only advances after all quotes scroll through
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const smooth = useSpring(scrollYProgress, { stiffness: 60, damping: 20, mass: 0.6 });

  return (
    // 3 screens tall so the section holds the page while all quotes play
    <section ref={ref} className="relative" style={{ height: `${COUNT * 100}vh` }}>
      <div className="sticky top-0 h-screen w-full overflow-hidden flex flex-col items-center justify-center">

        {/* Label — fades in once on entry */}
        <motion.p
          style={{
            opacity: useTransform(smooth, [0, 0.08], [0, 1]),
            y: useTransform(smooth, [0, 0.08], [20, 0]),
          }}
          className="font-mono text-xs uppercase tracking-widest text-primary mb-12"
        >
          ✦ Clients
        </motion.p>

        {/* Quote panels — each centered, fades in/out as you scroll */}
        <div className="relative w-full max-w-5xl px-6 lg:px-10 min-h-[260px] md:min-h-[220px] flex items-center justify-center">
          {quotes.map((q, i) => {
            const start  = i / COUNT;
            const center = (i + 0.5) / COUNT;
            const end    = (i + 1) / COUNT;

            const opacity = useTransform(
              smooth,
              [start, start + 0.1, center, end - 0.1, end],
              [0,     1,           1,      1,          0]
            );
            const y = useTransform(
              smooth,
              [start, start + 0.12, center, end - 0.12, end],
              [50,    0,            0,       0,          -50]
            );

            return (
              <motion.blockquote
                key={i}
                style={{ opacity, y }}
                className="absolute inset-0 flex flex-col items-center justify-center text-center px-6 lg:px-10"
              >
                <p className="font-display text-2xl md:text-4xl leading-snug tracking-tight">
                  <span className="text-primary">"</span>
                  {q.quote}
                  <span className="text-primary">"</span>
                </p>
                <footer className="mt-8 text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">{q.name}</span> — {q.role}
                </footer>
              </motion.blockquote>
            );
          })}
        </div>

        {/* Dot indicators — animate with scroll */}
        <div className="flex items-center justify-center gap-2 mt-12">
          {quotes.map((_, i) => {
            const start = i / COUNT;
            const end   = (i + 1) / COUNT;
            const w  = useTransform(smooth, [start, start + 0.1, end - 0.1, end], [6, 28, 28, 6]);
            const op = useTransform(smooth, [start, start + 0.1, end - 0.1, end], [0.3, 1, 1, 0.3]);
            return (
              <motion.div
                key={i}
                style={{ width: w, opacity: op }}
                className="h-1.5 rounded-full bg-primary"
              />
            );
          })}
        </div>

      </div>
    </section>
  );
}
