import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * Curtain loader — vertical bars wipe upward to reveal the site.
 * Word-by-word reveal of the studio name + percentage counter.
 */
export function Loader({ onDone }: { onDone?: () => void }) {
  const [visible, setVisible] = useState(true);
  const [progress, setProgress] = useState(0);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    // Honor reduced-motion: skip immediately
    if (typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setVisible(false);
      onDone?.();
      return;
    }
    let p = 0;
    const id = setInterval(() => {
      p += Math.random() * 14 + 8;
      if (p >= 100) {
        p = 100;
        clearInterval(id);
        setTimeout(() => {
          setLeaving(true);
          setTimeout(() => {
            setVisible(false);
            onDone?.();
          }, 900);
        }, 200);
      }
      setProgress(Math.min(p, 100));
    }, 60);
    return () => clearInterval(id);
  }, []);

  if (!visible) return null;

  const bars = 8;

  return (
    <AnimatePresence>
      {!leaving && (
        <motion.div
          key="loader-root"
          className="fixed inset-0 z-[99999] pointer-events-none"
          exit={{ opacity: 1 }}
        >
          {/* Vertical curtain bars */}
          <div className="absolute inset-0 flex">
            {Array.from({ length: bars }).map((_, i) => (
              <motion.div
                key={i}
                className="flex-1 bg-black"
                initial={{ y: 0 }}
                animate={leaving ? { y: "-100%" } : { y: 0 }}
                transition={{
                  duration: 0.9,
                  delay: leaving ? i * 0.03 : 0,
                  ease: [0.86, 0, 0.07, 1],
                }}
              />
            ))}
          </div>

          {/* Center content */}
          <motion.div
            className="absolute inset-0 flex flex-col items-center justify-center text-white"
            animate={leaving ? { opacity: 0, y: -20 } : { opacity: 1 }}
            transition={{ duration: 0.4 }}
          >
            {/* Wordmark with mask reveal */}
            <div className="overflow-hidden mb-6 py-6">
              <motion.div
                className="font-display font-bold text-[clamp(2.5rem,8vw,6rem)] leading-none tracking-tight"
                initial={{ y: "110%" }}
                animate={{ y: 0 }}
                transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.1 }}
              >
                EAssets <span className="italic font-light text-white/50">Studio</span>
              </motion.div>
            </div>

            {/* Progress bar */}
            <div className="w-[min(360px,70vw)] h-px bg-white/15 overflow-hidden">
              <motion.div
                className="h-full bg-white origin-left"
                style={{ scaleX: progress / 100 }}
                transition={{ ease: "linear" }}
              />
            </div>

            {/* Counter + status */}
            <div className="mt-4 w-[min(360px,70vw)] flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.35em] text-white/50">
              <span>Loading</span>
              <span className="tabular-nums text-white">
                {String(Math.round(progress)).padStart(3, "0")}
              </span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
