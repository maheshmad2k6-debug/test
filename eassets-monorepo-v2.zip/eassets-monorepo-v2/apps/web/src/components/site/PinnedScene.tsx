import { Canvas, useFrame } from "@react-three/fiber";
import { motion, useScroll, useTransform, useSpring, type MotionValue } from "framer-motion";
import { Suspense, useRef } from "react";
import * as THREE from "three";
import { usePerfTier } from "@/hooks/use-perf";

function MorphingShape({ progress, tier }: { progress: MotionValue<number>; tier: "low" | "mid" | "high" }) {
  const ref = useRef<THREE.Mesh>(null);
  const target = useRef(0);
  const frameCount = useRef(0);
  const detail = tier === "high" ? 24 : tier === "mid" ? 12 : 6;

  useFrame((state, delta) => {
    if (!ref.current) return;
    frameCount.current++;

    target.current = progress.get();
    const t = state.clock.elapsedTime;

    ref.current.rotation.y = target.current * Math.PI * 4 + t * 0.1;
    ref.current.rotation.x = target.current * Math.PI * 2;

    const s = 1 + Math.sin(t * 1.4) * 0.04 + target.current * 0.4;
    ref.current.scale.setScalar(s);

    // Throttle vertex morphing per tier
    const shouldMorph = tier === "high" || (tier === "mid" && frameCount.current % 2 === 0);
    if (!shouldMorph) return;

    const geo = ref.current.geometry as THREE.IcosahedronGeometry;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    const orig = (geo.userData.orig as Float32Array) || pos.array.slice();
    if (!geo.userData.orig) geo.userData.orig = orig;

    const intensity = 0.04 + target.current * 0.4;
    const freq = 1.5 + target.current * 3;
    for (let i = 0; i < pos.count; i++) {
      const ix = i * 3;
      const ox = orig[ix]; const oy = orig[ix + 1]; const oz = orig[ix + 2];
      const n = Math.sin(ox * freq + t * 1.2) * intensity + Math.cos(oy * freq + t * 1.5) * intensity + Math.sin(oz * freq + t * 0.9) * intensity;
      const len = Math.sqrt(ox * ox + oy * oy + oz * oz) || 1;
      const f = 1 + n / len;
      pos.array[ix] = ox * f; pos.array[ix + 1] = oy * f; pos.array[ix + 2] = oz * f;
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();

    if (ref.current.material instanceof THREE.MeshStandardMaterial) {
      ref.current.material.roughness = 0.05 + target.current * 0.5;
    }
  });

  return (
    <mesh ref={ref}>
      <icosahedronGeometry args={[1.2, detail]} />
      <meshStandardMaterial color="#ffffff" metalness={0.95} roughness={0.1} />
    </mesh>
  );
}

const captions = [
  { kw: "Form", body: "We sculpt geometry — every vertex on the page intentional." },
  { kw: "Motion", body: "Every interaction has rhythm, weight, and a reason to exist." },
  { kw: "Performance", body: "Visual ambition without compromising on Core Web Vitals." },
];

function Caption({ c, idx, stage }: { c: (typeof captions)[number]; idx: number; stage: MotionValue<number> }) {
  const opacity = useTransform(stage, [idx - 0.5, idx, idx + 0.5], [0, 1, 0]);
  const y = useTransform(stage, [idx - 0.5, idx, idx + 0.5], [30, 0, -30]);
  return (
    <motion.div style={{ opacity, y }} className="absolute inset-x-0">
      <h3 className="font-display font-bold text-5xl md:text-7xl tracking-tight mb-6">
        {c.kw}<span className="text-muted-foreground">.</span>
      </h3>
      <p className="text-lg text-muted-foreground max-w-md leading-relaxed">{c.body}</p>
    </motion.div>
  );
}

export function PinnedScene() {
  const tier = usePerfTier();
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end end"],
  });

  // Stiffer spring = snappier but lighter. Low tier gets very stiff (less smoothing work).
  const springConfig = tier === "low"
    ? { stiffness: 200, damping: 40, mass: 0.3 }
    : tier === "mid"
    ? { stiffness: 120, damping: 32, mass: 0.4 }
    : { stiffness: 100, damping: 30, mass: 0.4 };

  const smooth = useSpring(scrollYProgress, springConfig);
  const stage = useTransform(smooth, [0, 0.5, 1], [0, 1, 2]);
  const haloOpacity = useTransform(smooth, [0, 0.5, 1], [0.3, 0.7, 0.3]);
  const dpr: [number, number] = tier === "high" ? [1, 1.5] : [1, 1];

  return (
    <section ref={ref} className="relative" style={{ height: "300vh" }}>
      <div className="sticky top-0 h-screen w-full overflow-hidden bg-background">
        <motion.div
          style={{ opacity: haloOpacity }}
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[80vh] w-[80vh] rounded-full bg-mesh"
        />

        <div className="absolute inset-0">
          <Canvas
            dpr={dpr}
            camera={{ position: [0, 0, 4], fov: 45 }}
            gl={{ antialias: tier === "high", alpha: true, powerPreference: "high-performance", depth: false }}
            frameloop={tier === "low" ? "demand" : "always"}
          >
            <ambientLight intensity={0.2} />
            <directionalLight position={[4, 4, 4]} intensity={1.6} />
            {tier !== "low" && <pointLight position={[-4, -2, 3]} intensity={1.2} color="#ffffff" />}
            {tier !== "low" && <pointLight position={[0, 5, -3]} intensity={0.6} />}
            <Suspense fallback={null}>
              <MorphingShape progress={smooth} tier={tier} />
            </Suspense>
          </Canvas>
        </div>

        <div className="relative z-10 h-full mx-auto max-w-7xl px-6 lg:px-10 grid grid-cols-12 items-center pointer-events-none">
          <div className="col-span-12 md:col-span-5 md:col-start-1 relative h-64">
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-6">✦ The craft</p>
            {captions.map((c, idx) => (
              <Caption key={c.kw} c={c} idx={idx} stage={stage} />
            ))}
          </div>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-48 h-px bg-border overflow-hidden">
          <motion.div style={{ scaleX: smooth, transformOrigin: "0 0" }} className="h-full w-full bg-foreground" />
        </div>
      </div>
    </section>
  );
}
