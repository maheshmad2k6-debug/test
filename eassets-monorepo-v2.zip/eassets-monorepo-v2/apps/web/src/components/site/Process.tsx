import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import { useRef } from "react";

const steps = [
  { n: "01", title: "Discover", body: "Workshops to align on goals, audience, and the metrics that define success." },
  { n: "02", title: "Design",   body: "Concept directions, prototypes, and motion studies that prove the experience." },
  { n: "03", title: "Engineer", body: "Production builds with performance budgets baked in from day one." },
  { n: "04", title: "Launch",   body: "Soft launch, RUM monitoring, and iterative improvements post-release." },
];

const COUNT = steps.length; // 4

export function Process() {
  const ref = useRef<HTMLDivElement>(null);

  // scroll range = COUNT screens tall → page advances only after all stages pass
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });

  // Smooth spring so stage transitions feel weighted, not instant
  const smooth = useSpring(scrollYProgress, { stiffness: 60, damping: 20, mass: 0.6 });

  // Progress bar across header
  const lineWidth = useTransform(smooth, [0, 1], ["0%", "100%"]);

  return (
    <section id="process" ref={ref} className="relative" style={{ height: `${COUNT * 100}vh` }}>
      <div className="sticky top-0 h-screen w-full overflow-hidden bg-background flex flex-col">

        {/* ── Header ── */}
        <div className="relative z-10 mx-auto max-w-7xl w-full px-6 lg:px-10 pt-28 pb-8 shrink-0">
          <div className="flex items-end justify-between flex-wrap gap-4">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-3">✦ Process</p>
              <h2 className="font-display font-bold text-3xl md:text-5xl tracking-tight">
                From idea to <span className="italic text-muted-foreground">launch.</span>
              </h2>
            </div>
            <div className="font-mono text-xs text-muted-foreground hidden md:block">Scroll →</div>
          </div>
          <div className="mt-8 h-px bg-border relative overflow-hidden">
            <motion.div style={{ width: lineWidth }} className="absolute inset-y-0 left-0 bg-foreground" />
          </div>
        </div>

        {/* ── Stage panels stacked via opacity/transform — each centered ── */}
        <div className="flex-1 relative flex items-center justify-center">
          {steps.map((s, i) => {
            // Each stage occupies 1/(COUNT) of the scroll range
            const start  = i / COUNT;
            const center = (i + 0.5) / COUNT;
            const end    = (i + 1) / COUNT;

            // Fade + slide in, hold at center, fade + slide out
            const opacity = useTransform(
              smooth,
              [start, start + 0.08, center, end - 0.08, end],
              [0,     1,            1,      1,           0]
            );
            const x = useTransform(
              smooth,
              [start, start + 0.1, center, end - 0.1, end],
              [60,    0,           0,      0,          -60]
            );
            const scale = useTransform(
              smooth,
              [start, start + 0.1, center, end - 0.1, end],
              [0.92,  1,           1,      1,          0.92]
            );

            // Stage number counter ticks up as each panel becomes active
            const stageOpacity = useTransform(smooth, [start + 0.05, start + 0.15], [0, 1]);

            return (
              <motion.div
                key={s.n}
                style={{ opacity, x, scale }}
                className="absolute inset-0 flex items-center justify-center px-6 lg:px-10"
              >
                <div className="w-full max-w-2xl text-center mx-auto">
                  <motion.div
                    style={{ opacity: stageOpacity }}
                    className="font-mono text-sm text-muted-foreground mb-6"
                  >
                    {s.n} / 04
                  </motion.div>

                  <h3 className="font-display font-bold text-6xl md:text-[clamp(4rem,12vw,9rem)] tracking-tighter mb-8 leading-[0.9] text-center">
                    {s.title}<span className="text-muted-foreground">.</span>
                  </h3>

                  <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-xl mx-auto text-center">
                    {s.body}
                  </p>

                  <div className="mt-10 inline-flex items-center gap-3 px-4 py-2 rounded-full border border-border font-mono text-xs uppercase tracking-widest text-muted-foreground">
                    Stage {i + 1}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* ── Dot nav showing which stage is active ── */}
        <div className="shrink-0 flex justify-center gap-2 pb-10">
          {steps.map((_, i) => {
            const start  = i / COUNT;
            const end    = (i + 1) / COUNT;
            const w = useTransform(smooth, [start, start + 0.1, end - 0.1, end], [6, 28, 28, 6]);
            const op = useTransform(smooth, [start, start + 0.1, end - 0.1, end], [0.3, 1, 1, 0.3]);
            return (
              <motion.div
                key={i}
                style={{ width: w, opacity: op }}
                className="h-1.5 rounded-full bg-foreground"
              />
            );
          })}
        </div>

      </div>
    </section>
  );
}
