import { motion, useScroll, useSpring, useTransform, useVelocity, useMotionValue, useAnimationFrame } from "framer-motion";
import { useRef, useState } from "react";

const items = [
  "WebGL",
  "Three.js",
  "GLSL Shaders",
  "Motion Design",
  "Parallax",
  "Performance",
  "Accessibility",
  "Design Systems",
  "Storytelling",
];

export function Marquee() {
  const baseX = useMotionValue(0);
  const { scrollY } = useScroll();
  const scrollVelocity = useVelocity(scrollY);
  const smoothVelocity = useSpring(scrollVelocity, { damping: 50, stiffness: 400 });
  const velocityFactor = useTransform(smoothVelocity, [0, 1000], [0, 4], { clamp: false });
  const directionRef = useRef(1);
  const [width, setWidth] = useState(0);
  const measureRef = useRef<HTMLDivElement>(null);

  useAnimationFrame((_t, delta) => {
    if (!width) {
      if (measureRef.current) setWidth(measureRef.current.offsetWidth);
      return;
    }
    let moveBy = directionRef.current * (40 * (delta / 1000));
    const v = velocityFactor.get();
    if (v < 0) directionRef.current = -1;
    else if (v > 0) directionRef.current = 1;
    moveBy += directionRef.current * moveBy * v;
    let next = baseX.get() + moveBy;
    // wrap
    next = ((next % width) + width) % width;
    baseX.set(next - width);
  });

  const x = useTransform(baseX, (v) => `${v}px`);

  const loop = [...items, ...items, ...items];

  return (
    <div className="relative border-y border-border bg-background py-8 overflow-hidden">
      <motion.div
        ref={measureRef}
        style={{ x }}
        className="flex gap-12 whitespace-nowrap will-change-transform"
      >
        {loop.map((t, i) => (
          <div key={i} className="flex items-center gap-12 text-3xl md:text-5xl font-display font-medium">
            <span className={i % 2 === 0 ? "text-foreground" : "text-muted-foreground italic"}>{t}</span>
            <span className="text-muted-foreground">✦</span>
          </div>
        ))}
      </motion.div>
    </div>
  );
}
