import { useEffect, useState } from "react";
import { Reveal } from "./Reveal";
import { TiltCard } from "./TiltCard";
import { ProjectModal } from "./ProjectModal";
import { supabase, type Project } from "@/lib/supabase";

export function Work() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<Project | null>(null);

  useEffect(() => {
    supabase
      .from("projects")
      .select("*")
      .eq("published", true)
      .order("sort_order")
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setProjects((data ?? []).filter(p => p.cover_url));
        setLoading(false);
      });
  }, []);

  return (
    <section id="work" className="relative py-32 lg:py-44 bg-background">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <Reveal>
          <div className="flex items-end justify-between flex-wrap gap-6 mb-16">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-4">
                ✦ Selected Work
              </p>
              <h2 className="font-display font-bold text-4xl md:text-6xl tracking-tight">
                Recent <span className="italic text-muted-foreground">launches.</span>
              </h2>
            </div>
            <a href="#contact" className="text-sm font-mono uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors">
              All projects →
            </a>
          </div>
        </Reveal>

        {loading ? (
          <div className="text-center py-20 text-muted-foreground text-sm">Loading projects…</div>
        ) : projects.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground text-sm">
            New projects coming soon.
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6 lg:gap-10">
            {projects.map((p, i) => (
              <Reveal key={p.id} delay={i * 0.08}>
                <TiltCard className="group">
                  <button
                    type="button"
                    onClick={() => setActive(p)}
                    className="block w-full text-left"
                    data-cursor="view"
                    data-cursor-label="Open"
                  >
                    <div className="relative aspect-[4/3] rounded-3xl overflow-hidden bg-card border border-border">
                      {p.cover_type === "video" ? (
                        <video
                          src={p.cover_url}
                          className="absolute inset-0 w-full h-full object-contain transition-all duration-700 ease-out grayscale group-hover:grayscale-0 group-hover:scale-105"
                          autoPlay loop muted playsInline
                        />
                      ) : (
                        <img
                          src={p.cover_url}
                          alt={p.title}
                          className="absolute inset-0 w-full h-full object-contain transition-all duration-700 ease-out grayscale group-hover:grayscale-0 group-hover:scale-105"
                          loading={i < 2 ? "eager" : "lazy"}
                          fetchPriority={i === 0 ? "high" : "auto"}
                          decoding="async"
                        />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                      <div className="absolute top-6 right-6 h-12 w-12 rounded-full bg-background/40 backdrop-blur-md grid place-items-center border border-white/15 group-hover:bg-foreground group-hover:text-background transition-all">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M7 17L17 7M9 7h8v8"/></svg>
                      </div>
                      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between gap-3">
                        <span className="px-3 py-1.5 rounded-full bg-background/80 backdrop-blur text-xs font-medium">
                          View gallery →
                        </span>
                        <span
                          role="button"
                          tabIndex={0}
                          onClick={(e) => { e.stopPropagation(); setActive(p); }}
                          className="px-3 py-1.5 rounded-full bg-primary text-primary-foreground text-xs font-medium hover:shadow-[var(--shadow-glow)] transition-all cursor-pointer"
                        >
                          Book / Enquire
                        </span>
                      </div>
                    </div>
                    <div className="flex items-end justify-between mt-5">
                      <h3 className="font-display font-semibold text-xl">{p.title}</h3>
                      {p.sector && <span className="font-mono text-xs text-muted-foreground">{p.sector}</span>}
                    </div>
                  </button>
                </TiltCard>
              </Reveal>
            ))}
          </div>
        )}
      </div>

      <ProjectModal project={active} onClose={() => setActive(null)} />
    </section>
  );
}
