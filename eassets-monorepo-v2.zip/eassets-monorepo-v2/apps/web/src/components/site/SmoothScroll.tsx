import { useEffect } from "react";
import Lenis from "lenis";

let lenisInstance: InstanceType<typeof Lenis> | null = null;
let rafId = 0;

function startLenis() {
  if (lenisInstance) return;
  if (window.matchMedia("(pointer: coarse)").matches) return;

  lenisInstance = new Lenis({
    duration: 1.15,
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smoothWheel: true,
    lerp: 0.1,
    wheelMultiplier: 1,
  });

  const tick = (time: number) => {
    lenisInstance?.raf(time);
    rafId = requestAnimationFrame(tick);
  };
  rafId = requestAnimationFrame(tick);
}

function stopLenis() {
  if (!lenisInstance) return;
  cancelAnimationFrame(rafId);
  lenisInstance.destroy();
  lenisInstance = null;
}

export function SmoothScroll() {
  useEffect(() => {
    if (typeof window === "undefined") return;

    startLenis();

    // Fully destroy on modal open, recreate on close
    const onStop = () => stopLenis();
    const onStart = () => startLenis();
    window.addEventListener("lenis:stop", onStop);
    window.addEventListener("lenis:start", onStart);

    // anchor links
    const onClick = (e: MouseEvent) => {
      if (!lenisInstance) return;
      const a = (e.target as HTMLElement)?.closest('a[href^="#"]') as HTMLAnchorElement | null;
      if (!a) return;
      const id = a.getAttribute("href");
      if (!id || id === "#") return;
      const el = document.querySelector(id);
      if (!el) return;
      e.preventDefault();
      lenisInstance.scrollTo(el as HTMLElement, { offset: -10, duration: 1.4 });
    };
    document.addEventListener("click", onClick);

    return () => {
      stopLenis();
      document.removeEventListener("click", onClick);
      window.removeEventListener("lenis:stop", onStop);
      window.removeEventListener("lenis:start", onStart);
    };
  }, []);

  return null;
}
