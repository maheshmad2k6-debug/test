import { motion, AnimatePresence } from "framer-motion";
import { useState, useRef, type FormEvent } from "react";
import { Reveal } from "./Reveal";
import { supabase } from "@/lib/supabase";
import { sendContactEmails, sendBookingEmail } from "@/lib/brevo";
import { CalBooking } from "./CalBooking";

// ─── Contact form (left) ──────────────────────────────────────────────────────

function ContactForm() {
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSending(true);
    setError(false);
    const form = formRef.current!;
    const name = (form.elements.namedItem("name") as HTMLInputElement).value.trim();
    const email = (form.elements.namedItem("email") as HTMLInputElement).value.trim();
    const company = (form.elements.namedItem("company") as HTMLInputElement).value.trim();
    const message = (form.querySelector("textarea") as HTMLTextAreaElement).value.trim();

    const { error: err } = await supabase.from("messages").insert({
      name, email, subject: company || null, message,
    });
    setSending(false);
    if (err) {
      setError(true);
    } else {
      sendContactEmails({ name, email, message, company: company || undefined }).catch(
        (e) => console.error("Email notification failed:", e)
      );
      setSent(true);
      form.reset();
      setTimeout(() => setSent(false), 5000);
    }
  };

  return (
    <form ref={formRef} onSubmit={onSubmit} className="bg-card/60 backdrop-blur-xl border border-border rounded-3xl p-6 md:p-8 space-y-5 h-full flex flex-col">
      <div>
        <p className="font-mono text-xs uppercase tracking-widest text-primary mb-2">✦ Send a message</p>
        <h3 className="font-display font-bold text-2xl tracking-tight">Tell us about your project</h3>
        <p className="text-sm text-muted-foreground mt-1">We'll reply within 48 hours.</p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Name" name="name" placeholder="Ada Lovelace" required />
        <Field label="Email" name="email" type="email" placeholder="ada@studio.com" required />
      </div>
      <Field label="Company" name="company" placeholder="Studio Inc." />
      <div className="flex-1 flex flex-col">
        <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
          Project details
        </label>
        <textarea
          name="message"
          required
          rows={5}
          placeholder="What are you trying to build, launch, or improve?"
          className="flex-1 w-full bg-background/50 border border-border rounded-2xl px-4 py-3.5 text-sm placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors resize-none"
        />
      </div>
      {error && (
        <p className="text-xs text-destructive">Something went wrong. Email us at hreassets@gmail.com</p>
      )}
      <div className="flex items-center justify-between flex-wrap gap-3 pt-1">
        <p className="text-xs text-muted-foreground">
          Or{" "}
          <a href="mailto:hreassets@gmail.com" className="text-primary hover:underline">hreassets@gmail.com</a>
        </p>
        <motion.button
          whileTap={{ scale: 0.97 }}
          type="submit"
          disabled={sending || sent}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-primary text-primary-foreground text-sm font-medium hover:shadow-[var(--shadow-glow)] transition-all disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {sent ? "Sent ✓" : sending ? "Sending…" : "Send message →"}
        </motion.button>
      </div>
    </form>
  );
}

// ─── Booking widget (right) ───────────────────────────────────────────────────

type BookingStep = "choose" | "call" | "quote" | "done";

const BUDGET_OPTIONS: { label: string; min: number; max: number }[] = [
  { label: "$500 – $2k",    min: 500,    max: 2000 },
  { label: "$2k – $5k",     min: 2000,   max: 5000 },
  { label: "$5k – $10k",    min: 5000,   max: 10000 },
  { label: "$10k – $25k",   min: 10000,  max: 25000 },
  { label: "$25k – $50k",   min: 25000,  max: 50000 },
  { label: "$50k+",         min: 50000,  max: 250000 },
];

function BookingWidget() {
  const [step, setStep] = useState<BookingStep>("choose");
  const [, setMode] = useState<"call" | "quote" | null>(null);

  // Quote state
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [quoteMsg, setQuoteMsg] = useState("");
  const [budgetIdx, setBudgetIdx] = useState<number>(0);
  const [useCustom, setUseCustom] = useState(false);
  const [customMin, setCustomMin] = useState("");
  const [customMax, setCustomMax] = useState("");
  const [sending, setSending] = useState(false);
  const [err, setErr] = useState("");

  async function submitQuote() {
    if (!name.trim() || !email.trim() || !phone.trim() || !company.trim() || !quoteMsg.trim()) {
      setErr("All fields are required.");
      return;
    }
    let budget: { label: string; min: number; max: number };
    if (useCustom) {
      const min = parseFloat(customMin);
      const max = parseFloat(customMax);
      if (!min || !max || max < min) {
        setErr("Enter a valid custom budget range (min and max in USD).");
        return;
      }
      budget = { label: `$${min.toLocaleString()} – $${max.toLocaleString()}`, min, max };
    } else {
      budget = BUDGET_OPTIONS[budgetIdx];
    }

    setSending(true);
    setErr("");
    try {
      const { error: dbErr } = await supabase.from("quotations").insert({
        client_name: name.trim(),
        client_email: email.trim(),
        items: [{ description: quoteMsg.trim(), quantity: 1, rate: 0 }],
        total: 0,
        currency: "USD",
        budget_min: budget.min,
        budget_max: budget.max,
        status: "draft",
      });
      if (dbErr) throw new Error(dbErr.message);

      sendBookingEmail({
        name: name.trim(),
        email: email.trim(),
        mode: "quote",
        message:
          `Company: ${company.trim()}\n` +
          `Phone: ${phone.trim()}\n` +
          `Budget: ${budget.label} (USD)\n\n` +
          `Requirements:\n${quoteMsg.trim()}`,
      }).catch(console.error);

      setStep("done");
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setSending(false);
    }
  }

  function reset() {
    setStep("choose"); setMode(null);
    setName(""); setEmail(""); setPhone(""); setCompany(""); setQuoteMsg("");
    setBudgetIdx(0); setUseCustom(false); setCustomMin(""); setCustomMax(""); setErr("");
  }

  return (
    <div className="bg-card/60 backdrop-blur-xl border border-border rounded-3xl p-6 md:p-8 h-full flex flex-col min-h-[480px]">
      <AnimatePresence mode="wait">

        {/* ── Choose mode ── */}
        {step === "choose" && (
          <motion.div key="choose" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2 }} className="flex flex-col flex-1">
            <p className="font-mono text-xs uppercase tracking-widest text-primary mb-2">✦ Work with us</p>
            <h3 className="font-display font-bold text-2xl tracking-tight mb-1">Ready to start?</h3>
            <p className="text-sm text-muted-foreground mb-6">Book a call or get an instant quote estimate.</p>
            <div className="space-y-3 mt-auto">
              <ChoiceCard
                icon={<CalIcon />}
                title="Book a discovery call"
                desc="30 min intro call · powered by Cal.com"
                onClick={() => { setMode("call"); setStep("call"); }}
              />
              <ChoiceCard
                icon={<DocIcon />}
                title="Request a quote"
                desc="Describe your project, get an estimate in 48h"
                onClick={() => { setMode("quote"); setStep("quote"); }}
              />
            </div>
          </motion.div>
        )}

        {/* ── Cal.com booking ── */}
        {step === "call" && (
          <motion.div key="call" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2 }} className="flex flex-col flex-1">
            <StepHeader onBack={() => setStep("choose")} label="Book a discovery call" />
            <CalBooking />
            <p className="text-xs text-muted-foreground text-center mt-3">
              Confirmation emails sent to you & us automatically · timezone-correct
            </p>
          </motion.div>
        )}

        {/* ── Quote form ── */}
        {step === "quote" && (
          <motion.div key="quote" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2 }} className="flex flex-col flex-1">
            <StepHeader onBack={() => setStep("choose")} label="Request a quote" />
            <div className="space-y-3 flex-1">
              <SmallField label="Name *" value={name} onChange={setName} placeholder="Ada Lovelace" />
              <SmallField label="Email *" value={email} onChange={setEmail} type="email" placeholder="ada@studio.com" />
              <SmallField label="Phone *" value={phone} onChange={setPhone} type="tel" placeholder="+1 555 123 4567" />
              <SmallField label="Company *" value={company} onChange={setCompany} placeholder="Studio Inc." />

              {/* Budget selector — USD only */}
              <div>
                <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1.5">Budget range (USD) *</label>
                <div className="grid grid-cols-2 gap-2">
                  {BUDGET_OPTIONS.map((b, i) => (
                    <button
                      key={b.label}
                      type="button"
                      onClick={() => { setBudgetIdx(i); setUseCustom(false); }}
                      className={`py-2 px-2 rounded-lg text-xs font-medium border transition-all ${
                        !useCustom && budgetIdx === i
                          ? "bg-primary/10 border-primary text-primary"
                          : "border-border text-muted-foreground hover:border-primary/40"
                      }`}
                    >
                      {b.label}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setUseCustom(true)}
                    className={`py-2 px-2 rounded-lg text-xs font-medium border transition-all col-span-2 ${
                      useCustom
                        ? "bg-primary/10 border-primary text-primary"
                        : "border-border border-dashed text-muted-foreground hover:border-primary/40"
                    }`}
                  >
                    + Custom budget
                  </button>
                </div>
                {useCustom && (
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <input type="number" min="0" placeholder="Min $" value={customMin} onChange={e => setCustomMin(e.target.value)}
                      className="bg-background/50 border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary" />
                    <input type="number" min="0" placeholder="Max $" value={customMax} onChange={e => setCustomMax(e.target.value)}
                      className="bg-background/50 border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary" />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1.5">Requirements *</label>
                <textarea
                  rows={3}
                  value={quoteMsg}
                  onChange={e => setQuoteMsg(e.target.value)}
                  placeholder="Scope, timeline, references…"
                  className="w-full bg-background/50 border border-border rounded-xl px-4 py-3 text-sm placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors resize-none"
                />
              </div>
            </div>
            {err && <p className="text-xs text-destructive mt-2">{err}</p>}
            <motion.button whileTap={{ scale: 0.97 }} onClick={submitQuote} disabled={sending}
              className="mt-4 w-full py-3 rounded-full bg-primary text-primary-foreground text-sm font-medium hover:shadow-[var(--shadow-glow)] transition-all disabled:opacity-70">
              {sending ? "Submitting…" : "Request quote →"}
            </motion.button>
          </motion.div>
        )}

        {/* ── Done ── */}
        {step === "done" && (
          <motion.div key="done" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.25 }} className="flex flex-col flex-1 items-center justify-center text-center py-6">
            <div className="h-16 w-16 rounded-full bg-primary/10 grid place-items-center text-primary mb-4">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <h3 className="font-display font-bold text-xl text-foreground mb-2">Quote requested! ✦</h3>
            <p className="text-sm text-muted-foreground max-w-xs">
              We'll review your requirements and send a detailed quote within 48 hours.
            </p>
            <button onClick={reset} className="mt-6 text-xs text-primary hover:underline">← Back to start</button>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}

// ─── Small shared components ──────────────────────────────────────────────────

function ChoiceCard({ icon, title, desc, onClick }: {
  icon: React.ReactNode; title: string; desc: string; onClick: () => void;
}) {
  return (
    <button onClick={onClick}
      className="w-full flex items-center gap-4 p-4 rounded-2xl border border-border bg-background/50 hover:border-primary hover:bg-primary/5 transition-all group text-left">
      <span className="h-10 w-10 rounded-xl bg-primary/10 grid place-items-center text-primary flex-shrink-0">{icon}</span>
      <div className="flex-1 min-w-0">
        <div className="font-semibold text-sm text-foreground group-hover:text-primary transition-colors">{title}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{desc}</div>
      </div>
      <svg className="text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
    </button>
  );
}

function StepHeader({ onBack, label }: { onBack: () => void; label: string }) {
  return (
    <div className="flex items-center gap-2 mb-4">
      <button onClick={onBack} className="text-muted-foreground hover:text-foreground transition-colors p-0.5">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
      </button>
      <p className="font-mono text-xs uppercase tracking-widest text-primary">{label}</p>
    </div>
  );
}

function SmallField({ label, value, onChange, placeholder, type = "text" }: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string;
}) {
  return (
    <div>
      <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1.5">{label}</label>
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="w-full bg-background/50 border border-border rounded-xl px-4 py-3 text-sm placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors" />
    </div>
  );
}

function Field({ label, name, type = "text", placeholder, required }: {
  label: string; name: string; type?: string; placeholder?: string; required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={name} className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">{label}</label>
      <input id={name} name={name} type={type} placeholder={placeholder} required={required}
        className="w-full bg-background/50 border border-border rounded-2xl px-4 py-3.5 text-sm placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors" />
    </div>
  );
}

function CalIcon({ size = 18 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>;
}
function DocIcon() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>;
}

// ─── Main section ─────────────────────────────────────────────────────────────

export function Contact() {
  return (
    <section id="contact" className="relative py-32 lg:py-44 overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[80vh] w-[80vh] rounded-full bg-mesh opacity-50" />
      </div>

      <div className="relative mx-auto max-w-6xl px-6 lg:px-10">
        <Reveal>
          <div className="text-center mb-16">
            <p className="font-mono text-xs uppercase tracking-widest text-primary mb-6">✦ Start a project</p>
            <h2 className="font-display font-bold text-5xl md:text-7xl tracking-tight">
              Let's build something{" "}
              <span className="italic text-gradient-crimson">unforgettable.</span>
            </h2>
            <p className="mt-6 text-muted-foreground max-w-xl mx-auto">
              We're booking discovery calls for Q3 2026. Send a message or book a slot directly.
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="grid lg:grid-cols-2 gap-6 items-stretch">
            <ContactForm />
            <BookingWidget />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
