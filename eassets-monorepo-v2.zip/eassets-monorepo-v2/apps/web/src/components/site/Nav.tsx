import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Logo } from "./Logo";

export function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled
          ? "backdrop-blur-xl bg-background/70 border-b border-border"
          : "bg-transparent"
      }`}
    >
      <motion.div
        animate={
          scrolled
            ? { scale: 1, paddingTop: "0px", paddingBottom: "0px" }
            : { scale: 1.06, paddingTop: "10px", paddingBottom: "10px" }
        }
        transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        className="mx-auto max-w-7xl px-6 lg:px-10 h-20 flex items-center justify-between gap-6 origin-top"
      >
        <a href="#top" className="group flex items-center gap-3" aria-label="EAssets Studio — home">
          <Logo />
        </a>

        <a
          href="#contact"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary text-primary-foreground text-sm font-medium hover:shadow-[var(--shadow-glow)] transition-shadow"
        >
          <span>Start a project</span>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 12h14M13 5l7 7-7 7" />
          </svg>
        </a>
      </motion.div>
    </motion.header>
  );
}
