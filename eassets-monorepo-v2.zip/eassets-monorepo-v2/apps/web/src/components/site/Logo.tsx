interface LogoProps {
  className?: string;
  showWordmark?: boolean;
}

/**
 * EAssets Studio logo — abstract geometric mark evoking 3D form & motion.
 * Two intersecting arcs forming an "E" suggest depth, the studio's craft of
 * sculpting digital geometry. Monochrome to match the pitch-black theme.
 */
export function Logo({ className = "", showWordmark = true }: LogoProps) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <svg
        viewBox="0 0 32 32"
        xmlns="http://www.w3.org/2000/svg"
        className="h-8 w-8 shrink-0"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="eaLogoGrad" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="currentColor" stopOpacity="1" />
            <stop offset="100%" stopColor="currentColor" stopOpacity="0.55" />
          </linearGradient>
        </defs>
        {/* Outer ring — orbit / sphere silhouette */}
        <circle cx="16" cy="16" r="14" fill="none" stroke="url(#eaLogoGrad)" strokeWidth="1.5" />
        {/* Inner E formed by three offset bars */}
        <g stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
          <line x1="9" y1="10" x2="20" y2="10" />
          <line x1="9" y1="16" x2="17" y2="16" />
          <line x1="9" y1="22" x2="20" y2="22" />
        </g>
        {/* Vertical accent — the studio mark */}
        <line
          x1="9"
          y1="9"
          x2="9"
          y2="23"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
        />
        {/* Floating dot — motion / particle */}
        <circle cx="24" cy="16" r="1.6" fill="currentColor" />
      </svg>
      {showWordmark && (
        <span className="font-display font-semibold tracking-tight text-foreground">
          EAssets<span className="text-muted-foreground">.</span>Studio
        </span>
      )}
    </div>
  );
}
