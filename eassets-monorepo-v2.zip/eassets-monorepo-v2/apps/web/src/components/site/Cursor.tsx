import { useEffect, useRef, useState } from "react";

export function Cursor() {
  const ball = useRef<HTMLDivElement>(null);
  const [enabled, setEnabled] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (window.matchMedia("(pointer: coarse)").matches) return;
    setEnabled(true);

    const style = document.createElement("style");
    style.id = "__cursor-hide";
    style.textContent = "*, *::before, *::after { cursor: none !important; }";
    document.head.appendChild(style);

    let mx = 0;
    let my = 0;
    let bx = 0;
    let by = 0;
    let raf = 0;
    let lastMode = "default";
    let hasAppeared = false;

    const setMode = (mode: "default" | "text") => {
      if (!ball.current || lastMode === mode) return;
      lastMode = mode;

      if (mode === "text") {
        ball.current.style.width = "20px";
        ball.current.style.height = "20px";
        ball.current.style.background = "#f7f8fa";
        ball.current.style.border = "none";
        ball.current.style.mixBlendMode = "difference";
      } else {
        ball.current.style.width = "25px";
        ball.current.style.height = "25px";
        ball.current.style.background = "rgba(255,255,255,0.18)";
        ball.current.style.border = "1px solid rgba(255,255,255,0.5)";
        ball.current.style.mixBlendMode = "difference";
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      mx = e.clientX;
      my = e.clientY;

      // Snap to real position on first move — no slide-in from center
      if (!hasAppeared) {
        bx = mx;
        by = my;
        hasAppeared = true;
        setVisible(true);
      }

      const t = e.target as HTMLElement;
      const isCanvas = t.tagName === "CANVAS";
      const isText = isCanvas || !!t.closest('a, button, h1, h2, h3, h4, h5, h6, p, span, li, label, [data-cursor="hover"], .hoverable, section, footer');
      setMode(isText ? "text" : "default");
    };

    const tick = () => {
      // Snappy follow — near-direct tracking, no perceived lag
      bx += (mx - bx) * 0.45;
      by += (my - by) * 0.45;
      if (ball.current && hasAppeared) {
        ball.current.style.transform = `translate3d(${bx}px, ${by}px, 0) translate(-50%, -50%)`;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    window.addEventListener("mousemove", onMouseMove);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      cancelAnimationFrame(raf);
      document.getElementById("__cursor-hide")?.remove();
    };
  }, []);

  if (!enabled) return null;

  return (
    <div
      ref={ball}
      style={{
        position: "fixed",
        left: 0,
        top: 0,
        width: "30px",
        height: "30px",
        borderRadius: "50%",
        pointerEvents: "none",
        zIndex: 99999,
        mixBlendMode: "difference",
        background: "rgba(255,255,255,0.18)",
        border: "1px solid rgba(255,255,255,0.5)",
        opacity: visible ? 1 : 0,
        transition: "width 0.25s ease, height 0.25s ease, background 0.2s, border 0.2s, opacity 0.3s",
      }}
    />
  );
}
