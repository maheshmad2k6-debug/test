/**
 * Cal.com inline embed for booking flow.
 *
 * Uses the official @calcom/embed-react SDK so a real Cal.com calendar is shown
 * inside the page. This:
 *   - eliminates the timezone bug (Cal handles user-vs-admin timezones natively)
 *   - sends booking confirmation emails to BOTH user and owner (Cal does it)
 *   - lets the user pick a date and time in their own zone
 *   - shows the same instant in your Cal.com dashboard / admin
 *
 * Configure your Cal.com event-type URL via the prop or env var.
 */
import Cal, { getCalApi } from "@calcom/embed-react";
import { useEffect } from "react";

const DEFAULT_CAL_LINK = "eassets-studio-pgzdmw/30min";

export function CalBooking({ calLink = DEFAULT_CAL_LINK }: { calLink?: string }) {
  useEffect(() => {
    (async () => {
      const cal = await getCalApi();
      cal("ui", {
        theme: "dark",
        cssVarsPerTheme: {
          light: {
            "cal-brand": "#000000",
          },
          dark: {
            "cal-brand": "#ffffff",
            "cal-bg": "#0a0a0a",
            "cal-bg-emphasis": "#171717",
            "cal-bg-muted": "#0f0f0f",
            "cal-border": "#262626",
            "cal-text": "#fafafa",
            "cal-text-emphasis": "#ffffff",
            "cal-text-muted": "#a3a3a3",
          },
        },
        hideEventTypeDetails: false,
        layout: "month_view",
      });
    })();
  }, []);

  return (
    <div className="rounded-2xl overflow-hidden border border-border bg-background min-h-[560px]">
      <Cal
        calLink={calLink}
        style={{ width: "100%", height: "560px", overflow: "scroll" }}
        config={{ layout: "month_view" }}
      />
    </div>
  );
}
