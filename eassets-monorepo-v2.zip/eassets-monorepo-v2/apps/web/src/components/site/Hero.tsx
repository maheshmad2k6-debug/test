import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Magnetic } from "./Magnetic";

const headline = ["Immersive", "experiences,", "engineered."];

export function Hero({ ready = true }: { ready?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const opacity = useTransform(scrollYProgress, [0, 0.85], [1, 0]);
  const textY = useTransform(scrollYProgress, [0, 1], [0, -80]);

  return (
    <section
      ref={ref}
      id="top"
      className="relative min-h-[100svh] overflow-hidden"
      style={{ background: "var(--gradient-hero)" }}
    >
      {/* Static decorative blobs — pure CSS gradients, no springs, no per-frame work */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden>
        <div
          className="absolute -top-40 -left-40 h-[50vh] w-[50vh] rounded-full opacity-60"
          style={{ background: "radial-gradient(circle, oklch(0.7 0.15 280 / 0.35), transparent 70%)" }}
        />
        <div
          className="absolute top-1/3 -right-40 h-[45vh] w-[45vh] rounded-full opacity-30"
          style={{ background: "radial-gradient(circle, oklch(1 0 0 / 0.18), transparent 70%)" }}
        />
      </div>

      {/* Static grid overlay (no JS) */}
      <div
        className="absolute inset-0 opacity-[0.06] pointer-events-none"
        aria-hidden
        style={{
          backgroundImage:
            "linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)",
          backgroundSize: "80px 80px",
          maskImage: "radial-gradient(ellipse at center, black 30%, transparent 80%)",
        }}
      />

      <motion.div
        style={{ y: textY, opacity, willChange: "transform, opacity" }}
        className="relative z-10 mx-auto max-w-7xl px-6 lg:px-10 pt-40 pb-24 min-h-[100svh] flex flex-col justify-center"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={ready ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ delay: 0.1, duration: 0.8 }}
          className="inline-flex items-center gap-2 self-start px-3 py-1.5 rounded-full border border-border bg-card/40 text-xs font-mono uppercase tracking-widest text-muted-foreground"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-foreground animate-pulse" />
          EAssets Studio · Web Developer
        </motion.div>

        <h1 className="font-display font-bold tracking-tight mt-8 text-[clamp(2.8rem,9vw,8.5rem)] leading-[0.95] max-w-5xl">
          {headline.map((word, wi) => (
            <span key={wi} className="block overflow-hidden pb-2">
              <motion.span
                className="inline-block"
                initial={{ y: "110%" }}
                animate={ready ? { y: 0 } : { y: "110%" }}
                transition={{ delay: 0.05 + wi * 0.08, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              >
                {wi === 2 ? <span className="italic text-muted-foreground">{word}</span> : word}
              </motion.span>
            </span>
          ))}
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={ready ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ delay: 0.85, duration: 0.7 }}
          className="mt-8 max-w-xl text-lg text-muted-foreground"
        >
          We design and engineer visually rich, performant websites — 3D, motion,
          and interaction crafted to run beautifully on every device.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={ready ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ delay: 1, duration: 0.7 }}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <Magnetic>
            <a href="#work" className="group inline-flex items-center gap-3 px-7 py-4 rounded-full bg-foreground text-background font-medium hover:shadow-[var(--shadow-glow)] transition-shadow">
              Explore our work
              <span className="h-7 w-7 rounded-full bg-background/15 grid place-items-center group-hover:translate-x-1 transition-transform">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
              </span>
            </a>
          </Magnetic>
          <Magnetic strength={0.25}>
            <a href="#contact" className="inline-flex items-center gap-2 px-6 py-4 rounded-full border border-border hover:border-foreground transition-colors text-sm font-medium">
              Book a discovery call
            </a>
          </Magnetic>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={ready ? { opacity: 1 } : { opacity: 0 }}
          transition={{ delay: 1.3, duration: 1 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground"
        >
          Scroll
          <span className="block h-10 w-px bg-gradient-to-b from-foreground to-transparent" />
        </motion.div>
      </motion.div>
    </section>
  );
}
