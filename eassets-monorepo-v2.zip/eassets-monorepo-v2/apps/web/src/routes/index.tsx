import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Nav } from "@/components/site/Nav";
import { Cursor } from "@/components/site/Cursor";
import { SmoothScroll } from "@/components/site/SmoothScroll";
import { Loader } from "@/components/site/Loader";
import { Hero } from "@/components/site/Hero";
import { Marquee } from "@/components/site/Marquee";
import { Services } from "@/components/site/Services";
import { Work } from "@/components/site/Work";
import { Process } from "@/components/site/Process";
import { Testimonials } from "@/components/site/Testimonials";
import { Contact } from "@/components/site/Contact";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  const [heroReady, setHeroReady] = useState(true);

  return (
    <main className="relative bg-background text-foreground">
      <Loader onDone={() => setHeroReady(true)} />
      <SmoothScroll />
      <Cursor />
      <Nav />
      <Hero ready={heroReady} />
      <Marquee />
      <Work />
      <Services />
      <Process />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  );
}
