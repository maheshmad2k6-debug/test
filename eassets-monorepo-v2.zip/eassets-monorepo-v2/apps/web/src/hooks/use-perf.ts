import { useEffect, useState } from "react";

export type PerfTier = "low" | "mid" | "high";

/**
 * Detects approximate device capability so heavy 3D / animation work can scale down.
 * - low:  mobile, touch, low memory, reduced-motion, or ≤4 cores
 * - mid:  average laptop / tablet
 * - high: desktop with ≥8 cores and ≥8 GB RAM
 */
export function usePerfTier(): PerfTier {
  // Start conservative (low) to avoid flashing heavy content on weak devices
  const [tier, setTier] = useState<PerfTier>("low");

  useEffect(() => {
    if (typeof window === "undefined") return;

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) { setTier("low"); return; }

    const coarse = window.matchMedia("(pointer: coarse)").matches;
    const small = window.innerWidth < 768;
    // @ts-expect-error non-standard
    const mem: number | undefined = navigator.deviceMemory;
    const cores = navigator.hardwareConcurrency || 2;

    // Definite low tier
    if (coarse || small || (mem !== undefined && mem <= 2) || cores <= 2) {
      setTier("low");
      return;
    }

    // Try GPU sniffing via WebGL renderer
    try {
      const canvas = document.createElement("canvas");
      const gl = (canvas.getContext("webgl") || canvas.getContext("experimental-webgl")) as WebGLRenderingContext | null;
      if (gl) {
        const ext = gl.getExtension("WEBGL_debug_renderer_info");
        if (ext) {
          const renderer = gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) as string;
          const lowGPU = /intel\s+(u?hd|iris)/i.test(renderer) || /mali-[gt][0-9]/i.test(renderer) || /adreno\s*(3|4)/i.test(renderer);
          if (lowGPU && cores <= 4) { setTier("low"); return; }
          if (lowGPU) { setTier("mid"); return; }
        }
      }
    } catch { /* ignore */ }

    // Memory/core based classification
    if (cores >= 8 && (!mem || mem >= 8)) {
      setTier("high");
    } else if (cores >= 4 && (!mem || mem >= 4)) {
      setTier("mid");
    } else {
      setTier("low");
    }
  }, []);

  return tier;
}

export function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const set = () => setReduced(mq.matches);
    set();
    mq.addEventListener("change", set);
    return () => mq.removeEventListener("change", set);
  }, []);
  return reduced;
}
