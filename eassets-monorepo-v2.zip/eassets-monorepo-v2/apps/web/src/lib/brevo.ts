// src/lib/brevo.ts
// Uses supabase.functions.invoke — no manual URL or auth header needed.

import { supabase } from "@/lib/supabase";

async function callEmailFunction(payload: Record<string, unknown>): Promise<void> {
  const { error } = await supabase.functions.invoke("send-email", {
    body: payload,
  });

  if (error) {
    throw new Error(error.message ?? "Email send failed");
  }
}

/** Notify owner + send confirmation to the contact form sender */
export async function sendContactEmails(params: {
  name: string;
  email: string;
  message: string;
  company?: string;
}): Promise<void> {
  return callEmailFunction({ type: "contact", ...params });
}

/** Send invoice to client + notify owner. pdfBase64 attaches the HTML invoice as a file. */
export async function sendInvoiceEmail(params: {
  clientEmail: string;
  clientName: string;
  invoiceNumber: string;
  total: string;
  currency: string;
  pdfBase64?: string;
}): Promise<void> {
  return callEmailFunction({ type: "invoice", ...params });
}

/** Send quotation to client + notify owner. pdfBase64 attaches the HTML quotation as a file. */
export async function sendQuotationEmail(params: {
  clientEmail: string;
  clientName: string;
  quotationId: string;
  total: string;
  pdfBase64?: string;
}): Promise<void> {
  return callEmailFunction({ type: "quotation", ...params });
}

/**
 * Notify owner of a new booking/quote request.
 * For discovery calls (mode="call"), set pendingCall=true to suppress the
 * client confirmation email — it will be sent later when admin approves.
 */
export async function sendBookingEmail(params: {
  name: string;
  email: string;
  mode: "call" | "quote";
  date?: string;
  time?: string;
  message?: string;
  /** When true, only the owner notification is sent; client confirmation is withheld until admin approves */
  pendingCall?: boolean;
}): Promise<void> {
  return callEmailFunction({ type: "booking", ...params });
}

/**
 * Send the confirmation email to a discovery call client after admin approval.
 * Called from the admin Bookings panel when a booking is marked as "confirmed".
 */
export async function sendBookingConfirmationEmail(params: {
  name: string;
  email: string;
  date: string;
  time: string;
}): Promise<void> {
  return callEmailFunction({ type: "booking_confirm", ...params });
}
