import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";
import { ClientGate } from "./components/client/ClientGate";
import { PortalApp } from "./components/portal/PortalApp";

const rootEl = document.getElementById("root")!;
createRoot(rootEl).render(
  <StrictMode>
    <ClientGate>{(session) => <PortalApp session={session} />}</ClientGate>
  </StrictMode>
);
