import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { supabase } from "@/lib/supabase";

export interface ClientSession {
  client_id: string;
  client_name: string;
  client_email: string;
  user_id: string;
  company?: string;
}

const KEY = "client_portal_session";

export function getClientSession(): ClientSession | null {
  try {
    const raw = sessionStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as ClientSession) : null;
  } catch {
    return null;
  }
}

export function setClientSession(s: ClientSession) {
  sessionStorage.setItem(KEY, JSON.stringify(s));
}

export function clearClientSession() {
  sessionStorage.removeItem(KEY);
  window.location.reload();
}

export function ClientGate({ children }: { children: (s: ClientSession) => ReactNode }) {
  const [session, setSessionState] = useState<ClientSession | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setSessionState(getClientSession());
    setReady(true);
  }, []);

  if (!ready) return null;
  if (session) return <>{children(session)}</>;
  return <ClientLogin onLogin={(s) => { setClientSession(s); setSessionState(s); }} />;
}

function ClientLogin({ onLogin }: { onLogin: (s: ClientSession) => void }) {
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      const { data: row } = await supabase
        .from("client_portal_users")
        .select("id, user_id, password_hash, client_id")
        .eq("user_id", userId.trim())
        .maybeSingle();
      if (!row || row.password_hash !== password) {
        setErr("Invalid user ID or password.");
        return;
      }
      const { data: client } = await supabase
        .from("clients")
        .select("id, name, email, company")
        .eq("id", row.client_id)
        .maybeSingle();
      if (!client) {
        setErr("Client account not found. Contact support.");
        return;
      }
      await supabase.from("client_portal_users").update({ last_login: new Date().toISOString() }).eq("id", row.id);
      onLogin({
        client_id: client.id,
        client_name: client.name,
        client_email: client.email,
        company: client.company ?? undefined,
        user_id: row.user_id,
      });
    } catch {
      setErr("Login failed. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <form onSubmit={submit} className="w-full max-w-sm bg-card border border-border rounded-2xl p-7 shadow-sm">
        <div className="mb-6 text-center">
          <div className="font-bold text-xl text-foreground">eassets<span className="text-primary">.studio</span></div>
          <div className="text-xs text-muted-foreground mt-1">Client Portal</div>
        </div>
        <label className="block text-xs font-medium text-muted-foreground mb-1.5">User ID</label>
        <input
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
          required
          autoFocus
          className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-foreground mb-4 focus:outline-none focus:border-primary"
        />
        <label className="block text-xs font-medium text-muted-foreground mb-1.5">Password</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-foreground mb-4 focus:outline-none focus:border-primary"
        />
        {err && <div className="text-xs text-destructive mb-3">{err}</div>}
        <button
          type="submit"
          disabled={busy}
          className="w-full bg-primary text-primary-foreground rounded-lg py-2.5 text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-60"
        >
          {busy ? "Signing in…" : "Sign in"}
        </button>
        <div className="text-[11px] text-muted-foreground text-center mt-4">
          Don't have credentials? Contact your project manager.
        </div>
      </form>
    </div>
  );
}
