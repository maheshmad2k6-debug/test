import { useState } from "react";
import type { ClientSession } from "@/components/client/ClientGate";
import { clearClientSession } from "@/components/client/ClientGate";
import { DashboardModule, TasksModule, MessagesModule, FilesModule, FinanceModule, OnboardingModule, ReportModule } from "./modules";
import { useRealtimeNotifications } from "@/hooks/useRealtimeNotifications";

type Tab = "dashboard" | "tasks" | "messages" | "files" | "finance" | "onboarding" | "report";

const NAV: { id: Tab; label: string; icon: string }[] = [
  { id: "dashboard", label: "Dashboard", icon: "📊" },
  { id: "tasks", label: "Tasks", icon: "✓" },
  { id: "messages", label: "Messages", icon: "💬" },
  { id: "files", label: "Files", icon: "📁" },
  { id: "finance", label: "Finance", icon: "₹" },
  { id: "onboarding", label: "Onboarding", icon: "🚀" },
  { id: "report", label: "Report", icon: "📈" },
];

export function PortalApp({ session }: { session: ClientSession }) {
  const [tab, setTab] = useState<Tab>("dashboard");
  useRealtimeNotifications({ clientId: session.client_id });

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur border-b border-border px-5 py-4 flex items-center gap-4">
        <div className="flex-1 min-w-0">
          <div className="font-bold text-foreground">eassets<span className="text-primary">.studio</span></div>
          <div className="text-xs text-muted-foreground truncate">{session.client_name} · {session.user_id}</div>
        </div>
        <button onClick={clearClientSession} className="text-xs text-muted-foreground hover:text-destructive">Log out</button>
      </header>

      <nav className="sticky top-[73px] z-10 bg-background/80 backdrop-blur border-b border-border px-3 py-2 overflow-x-auto">
        <div className="flex gap-1 min-w-max">
          {NAV.map((n) => (
            <button
              key={n.id}
              onClick={() => setTab(n.id)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${tab === n.id ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}
            >
              <span className="mr-1.5">{n.icon}</span>{n.label}
            </button>
          ))}
        </div>
      </nav>

      <main className="flex-1 p-5 max-w-5xl w-full mx-auto">
        {tab === "dashboard" && <DashboardModule clientId={session.client_id} role="client" onJump={(t) => setTab(t as Tab)} />}
        {tab === "tasks" && <TasksModule clientId={session.client_id} role="client" />}
        {tab === "messages" && <MessagesModule clientId={session.client_id} role="client" />}
        {tab === "files" && <FilesModule clientId={session.client_id} role="client" />}
        {tab === "finance" && <FinanceModule clientId={session.client_id} clientEmail={session.client_email} role="client" />}
        {tab === "onboarding" && <OnboardingModule clientId={session.client_id} role="client" />}
        {tab === "report" && <ReportModule clientId={session.client_id} role="client" />}
      </main>
    </div>
  );
}
