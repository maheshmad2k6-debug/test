import { useEffect } from "react";

export interface ViewableFile {
  url: string;
  name: string;
  mime?: string;
}

export function FileViewerOverlay({ file, onClose }: { file: ViewableFile | null; onClose: () => void }) {
  useEffect(() => {
    if (!file) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [file, onClose]);
  if (!file) return null;
  const mime = (file.mime ?? "").toLowerCase();
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  const isImage = mime.startsWith("image/") || ["png","jpg","jpeg","gif","webp","svg","avif"].includes(ext);
  const isPdf = mime === "application/pdf" || ext === "pdf";
  const isVideo = mime.startsWith("video/") || ["mp4","webm","mov","ogv"].includes(ext);
  const isAudio = mime.startsWith("audio/") || ["mp3","wav","ogg","m4a"].includes(ext);
  return (
    <div className="fixed inset-0 z-[100] bg-black/90 flex flex-col" onClick={onClose}>
      <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 text-white" onClick={(e) => e.stopPropagation()}>
        <div className="text-sm font-medium truncate flex-1">{file.name}</div>
        <div className="flex items-center gap-2">
          <a href={file.url} download={file.name} target="_blank" rel="noreferrer" className="text-xs bg-white/10 hover:bg-white/20 rounded-lg px-3 py-1.5">Download</a>
          <button onClick={onClose} className="text-xs bg-white/10 hover:bg-white/20 rounded-lg px-3 py-1.5">Close ✕</button>
        </div>
      </div>
      <div className="flex-1 overflow-auto flex items-center justify-center p-4" onClick={(e) => e.stopPropagation()}>
        {isImage ? <img src={file.url} alt={file.name} className="max-w-full max-h-full object-contain" />
          : isPdf ? <iframe src={file.url} title={file.name} className="w-full h-full bg-white rounded-lg" />
          : isVideo ? <video src={file.url} controls className="max-w-full max-h-full" />
          : isAudio ? <audio src={file.url} controls className="w-full max-w-md" />
          : <a href={file.url} download={file.name} target="_blank" rel="noreferrer" className="bg-white text-black rounded-lg px-4 py-2 text-sm font-medium">Download</a>}
      </div>
    </div>
  );
}
