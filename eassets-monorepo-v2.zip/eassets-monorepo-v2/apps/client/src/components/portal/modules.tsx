import { useEffect, useRef, useState, type FormEvent } from "react";
import { supabase, type Invoice, type Quotation } from "@/lib/supabase";
import { FileViewerOverlay, type ViewableFile } from "./FileViewerOverlay";
import {
  uploadPortalFile, deletePortalFile, publicUrl, uploadOnboardingFile,
  fmtBytes, fmtDate, fmtTime,
  type PortalTask, type PortalMessage, type PortalFile, type PortalOnboardingDoc, type PortalReport, type TaskStatus, type OnboardingStatus,
} from "@/lib/portalApi";

export type Role = "admin" | "client";

const card = "bg-card border border-border rounded-2xl p-5";
const btn = "rounded-lg px-3 py-1.5 text-xs font-medium transition-colors";
const btnPri = `${btn} bg-primary text-primary-foreground hover:opacity-90`;
const btnSec = `${btn} bg-muted text-foreground hover:bg-muted/70`;
const btnDanger = `${btn} bg-destructive/10 text-destructive hover:bg-destructive/20`;
const input = "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:border-primary";

// ─── TASKS ────────────────────────────────────────────────────────────────────
export function TasksModule({ clientId, role }: { clientId: string; role: Role }) {
  const [tasks, setTasks] = useState<PortalTask[]>([]);
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [due, setDue] = useState("");

  async function load() {
    const { data } = await supabase.from("portal_tasks").select("*").eq("client_id", clientId).order("created_at", { ascending: false });
    setTasks((data ?? []) as PortalTask[]);
  }
  useEffect(() => { load(); }, [clientId]);

  async function add(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    await supabase.from("portal_tasks").insert({ client_id: clientId, title, description: desc, due_date: due || null });
    setTitle(""); setDesc(""); setDue(""); load();
  }
  async function setStatus(id: string, status: TaskStatus) {
    await supabase.from("portal_tasks").update({ status, updated_at: new Date().toISOString() }).eq("id", id);
    load();
  }
  async function del(id: string) {
    await supabase.from("portal_tasks").delete().eq("id", id);
    load();
  }

  return (
    <div className="space-y-4">
      {role === "admin" && (
        <form onSubmit={add} className={card + " space-y-2"}>
          <div className="text-sm font-semibold text-foreground">New task</div>
          <input className={input} placeholder="Task title" value={title} onChange={(e) => setTitle(e.target.value)} />
          <textarea className={input} placeholder="Description" rows={2} value={desc} onChange={(e) => setDesc(e.target.value)} />
          <div className="flex gap-2">
            <input type="date" className={input + " flex-1"} value={due} onChange={(e) => setDue(e.target.value)} />
            <button className={btnPri}>Add task</button>
          </div>
        </form>
      )}
      <div className="space-y-2">
        {tasks.length === 0 && <div className="text-sm text-muted-foreground text-center py-8">No tasks yet.</div>}
        {tasks.map((t) => (
          <div key={t.id} className={card}>
            <div className="flex items-start gap-3">
              <div className="flex-1">
                <div className="text-sm font-semibold text-foreground">{t.title}</div>
                {t.description && <div className="text-xs text-muted-foreground mt-1">{t.description}</div>}
                <div className="flex items-center gap-2 mt-2 text-[11px] text-muted-foreground">
                  <span className={`px-2 py-0.5 rounded-full ${t.status === "done" ? "bg-green-500/15 text-green-600" : t.status === "in_progress" ? "bg-amber-500/15 text-amber-600" : "bg-muted text-muted-foreground"}`}>
                    {t.status.replace("_", " ")}
                  </span>
                  {t.due_date && <span>Due {fmtDate(t.due_date)}</span>}
                </div>
              </div>
              {role === "admin" && (
                <div className="flex flex-col gap-1.5">
                  {t.status !== "done" ? (
                    <button onClick={() => setStatus(t.id, "done")} className={btnPri}>Complete</button>
                  ) : (
                    <button onClick={() => setStatus(t.id, "todo")} className={btnSec}>Reopen</button>
                  )}
                  {t.status === "todo" && <button onClick={() => setStatus(t.id, "in_progress")} className={btnSec}>Start</button>}
                  <button onClick={() => del(t.id)} className={btnDanger}>Delete</button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── MESSAGES ────────────────────────────────────────────────────────────────
export function MessagesModule({ clientId, role }: { clientId: string; role: Role }) {
  const [msgs, setMsgs] = useState<PortalMessage[]>([]);
  const [body, setBody] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  async function load() {
    const { data } = await supabase.from("portal_messages").select("*").eq("client_id", clientId).order("created_at", { ascending: true });
    setMsgs((data ?? []) as PortalMessage[]);
  }
  useEffect(() => {
    load();
    const ch = supabase
      .channel(`portal-msgs-${clientId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "portal_messages", filter: `client_id=eq.${clientId}` }, (p) => {
        setMsgs((m) => [...m, p.new as PortalMessage]);
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [clientId]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs.length]);

  async function send(e: FormEvent) {
    e.preventDefault();
    if (!body.trim()) return;
    await supabase.from("portal_messages").insert({ client_id: clientId, sender: role, body });
    setBody("");
  }

  return (
    <div className="flex flex-col h-[70vh] bg-card border border-border rounded-2xl overflow-hidden">
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {msgs.length === 0 && <div className="text-sm text-muted-foreground text-center py-12">No messages yet — say hello.</div>}
        {msgs.map((m) => {
          const mine = m.sender === role;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[75%] rounded-2xl px-4 py-2 ${mine ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>
                <div className="text-sm whitespace-pre-wrap break-words">{m.body}</div>
                <div className={`text-[10px] mt-1 ${mine ? "text-primary-foreground/70" : "text-muted-foreground"}`}>{fmtTime(m.created_at)}</div>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>
      <form onSubmit={send} className="border-t border-border p-3 flex gap-2">
        <input className={input + " flex-1"} placeholder="Type a message…" value={body} onChange={(e) => setBody(e.target.value)} />
        <button className={btnPri}>Send</button>
      </form>
    </div>
  );
}

// ─── FILES ────────────────────────────────────────────────────────────────────
interface FileComment { id: string; file_id: string; sender: Role; body: string; created_at: string }
type FileDecision = "pending" | "approved" | "rejected" | "redesign";

export function FilesModule({ clientId, role }: { clientId: string; role: Role }) {
  const [files, setFiles] = useState<PortalFile[]>([]);
  const [decisions, setDecisions] = useState<Record<string, FileDecision>>({});
  const [comments, setComments] = useState<Record<string, FileComment[]>>({});
  const [open, setOpen] = useState<ViewableFile | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    const { data } = await supabase.from("portal_files").select("*").eq("client_id", clientId).order("created_at", { ascending: false });
    const arr = (data ?? []) as (PortalFile & { decision?: FileDecision; comments?: FileComment[] })[];
    setFiles(arr);
    const dec: Record<string, FileDecision> = {};
    const cm: Record<string, FileComment[]> = {};
    arr.forEach((f) => { dec[f.id] = f.decision ?? "pending"; cm[f.id] = f.comments ?? []; });
    setDecisions(dec); setComments(cm);
  }
  useEffect(() => { load(); }, [clientId]);

  async function upload(e: React.ChangeEvent<HTMLInputElement>) {
    const fl = e.target.files; if (!fl?.length) return;
    setBusy(true);
    for (const f of Array.from(fl)) await uploadPortalFile(clientId, f, role);
    setBusy(false); e.target.value = ""; load();
  }
  async function setDecision(f: PortalFile, decision: FileDecision) {
    await supabase.from("portal_files").update({ decision }).eq("id", f.id);
    setDecisions((d) => ({ ...d, [f.id]: decision }));
  }
  async function addComment(f: PortalFile, body: string) {
    if (!body.trim()) return;
    const c: FileComment = { id: crypto.randomUUID(), file_id: f.id, sender: role, body, created_at: new Date().toISOString() };
    const next = [...(comments[f.id] ?? []), c];
    await supabase.from("portal_files").update({ comments: next }).eq("id", f.id);
    setComments((m) => ({ ...m, [f.id]: next }));
  }

  return (
    <div className="space-y-4">
      <div className={card + " flex items-center justify-between"}>
        <div className="text-sm font-semibold text-foreground">Shared files</div>
        <label className={btnPri + " cursor-pointer"}>
          {busy ? "Uploading…" : "Upload"}
          <input type="file" multiple className="hidden" onChange={upload} disabled={busy} />
        </label>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {files.length === 0 && <div className="text-sm text-muted-foreground text-center py-8 col-span-full">No files yet.</div>}
        {files.map((f) => {
          const url = publicUrl(f.storage_path);
          const dec = decisions[f.id] ?? "pending";
          return (
            <div key={f.id} className={card + " space-y-2"}>
              <div className="flex items-start gap-3">
                <button onClick={() => setOpen({ url, name: f.name, mime: f.mime })} className="text-left flex-1">
                  <div className="text-sm font-semibold text-foreground truncate">{f.name}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {f.uploader} · {fmtBytes(f.size)} · {fmtDate(f.created_at)}
                  </div>
                </button>
                <span className={`text-[10px] px-2 py-0.5 rounded-full ${dec === "approved" ? "bg-green-500/15 text-green-600" : dec === "rejected" ? "bg-destructive/15 text-destructive" : dec === "redesign" ? "bg-amber-500/15 text-amber-600" : "bg-muted text-muted-foreground"}`}>{dec}</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                <button onClick={() => setDecision(f, "approved")} className={btnSec}>Approve</button>
                <button onClick={() => setDecision(f, "rejected")} className={btnSec}>Reject</button>
                <button onClick={() => setDecision(f, "redesign")} className={btnSec}>Redesign</button>
                {role === "admin" && <button onClick={() => deletePortalFile(f).then(load)} className={btnDanger}>Delete</button>}
              </div>
              <FileComments items={comments[f.id] ?? []} onAdd={(b) => addComment(f, b)} />
            </div>
          );
        })}
      </div>
      <FileViewerOverlay file={open} onClose={() => setOpen(null)} />
    </div>
  );
}

function FileComments({ items, onAdd }: { items: FileComment[]; onAdd: (b: string) => void }) {
  const [v, setV] = useState("");
  return (
    <div className="border-t border-border pt-2 mt-1 space-y-1.5">
      {items.map((c) => (
        <div key={c.id} className="text-[11px] text-foreground">
          <span className="font-medium">{c.sender}:</span> {c.body}
        </div>
      ))}
      <form onSubmit={(e) => { e.preventDefault(); onAdd(v); setV(""); }} className="flex gap-1.5">
        <input className={input + " text-xs py-1"} placeholder="Add comment…" value={v} onChange={(e) => setV(e.target.value)} />
        <button className={btnSec}>Add</button>
      </form>
    </div>
  );
}

// ─── FINANCE ─────────────────────────────────────────────────────────────────
export function FinanceModule({ clientId, clientEmail, role }: { clientId: string; clientEmail?: string; role: Role }) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [quotes, setQuotes] = useState<Quotation[]>([]);

  async function load() {
    const [inv, qt] = await Promise.all([
      supabase.from("invoices").select("*").or(`client_id.eq.${clientId}${clientEmail ? `,client_email.eq.${clientEmail}` : ""}`).order("created_at", { ascending: false }),
      supabase.from("quotations").select("*").or(`client_id.eq.${clientId}${clientEmail ? `,client_email.eq.${clientEmail}` : ""}`).order("created_at", { ascending: false }),
    ]);
    setInvoices((inv.data ?? []) as Invoice[]);
    setQuotes((qt.data ?? []) as Quotation[]);
  }
  useEffect(() => { load(); }, [clientId, clientEmail]);

  return (
    <div className="space-y-6">
      <Section title="Invoices">
        {invoices.length === 0 ? <Empty label="No invoices." /> : invoices.map((i) => (
          <FinanceCard key={i.id} title={`Invoice ${i.invoice_number}`} subtitle={`${i.currency === "USD" ? "$" : "₹"}${i.total} · ${i.status}`} pdf={i.pdf_url} razorpayHtml={i.razorpay_button_html} role={role} />
        ))}
      </Section>
      <Section title="Quotations">
        {quotes.length === 0 ? <Empty label="No quotations." /> : quotes.map((q) => (
          <FinanceCard key={q.id} title={`Quotation`} subtitle={`${q.currency === "USD" ? "$" : "₹"}${q.total} · ${q.status}`} pdf={q.pdf_url} razorpayHtml={q.razorpay_button_html} role={role} />
        ))}
      </Section>
    </div>
  );
}
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <div><div className="text-sm font-semibold text-foreground mb-2">{title}</div><div className="space-y-2">{children}</div></div>;
}
function Empty({ label }: { label: string }) { return <div className="text-sm text-muted-foreground text-center py-6">{label}</div>; }
function FinanceCard({ title, subtitle, pdf, razorpayHtml, role }: { title: string; subtitle: string; pdf?: string; razorpayHtml?: string; role: Role }) {
  return (
    <div className={card + " space-y-2"}>
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm font-semibold text-foreground">{title}</div>
          <div className="text-xs text-muted-foreground">{subtitle}</div>
        </div>
        <div className="flex gap-2">
          {pdf && <a href={pdf} target="_blank" rel="noreferrer" className={btnSec}>Download PDF</a>}
        </div>
      </div>
      {razorpayHtml && <div className="pt-1" dangerouslySetInnerHTML={{ __html: razorpayHtml }} />}
      {role === "admin" && <div className="text-[11px] text-muted-foreground">Edit / send from the admin Invoices / Quotations tab.</div>}
    </div>
  );
}

// ─── ONBOARDING ──────────────────────────────────────────────────────────────
export function OnboardingModule({ clientId, role }: { clientId: string; role: Role }) {
  const [docs, setDocs] = useState<PortalOnboardingDoc[]>([]);
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [open, setOpen] = useState<ViewableFile | null>(null);

  async function load() {
    const { data } = await supabase.from("portal_onboarding_docs").select("*").eq("client_id", clientId).order("created_at", { ascending: false });
    setDocs((data ?? []) as PortalOnboardingDoc[]);
  }
  useEffect(() => { load(); }, [clientId]);

  async function addDoc(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    await supabase.from("portal_onboarding_docs").insert({ client_id: clientId, title, description: desc });
    setTitle(""); setDesc(""); load();
  }
  async function requestDocs() {
    await supabase.from("portal_onboarding_docs").insert({ client_id: clientId, title: "Document request", description: "Please upload required documents." });
    load();
  }
  async function attach(d: PortalOnboardingDoc, file: File) {
    const up = await uploadOnboardingFile(clientId, file);
    if (!up) return;
    await supabase.from("portal_onboarding_docs").update({ doc_storage_path: up.path, doc_name: up.name, doc_mime: up.mime, updated_at: new Date().toISOString() }).eq("id", d.id);
    load();
  }
  async function decide(d: PortalOnboardingDoc, status: OnboardingStatus, comment?: string, signature?: string) {
    await supabase.from("portal_onboarding_docs").update({
      status, client_comment: comment ?? null,
      signature_name: signature ?? null,
      signed_at: status === "esigned" ? new Date().toISOString() : null,
      updated_at: new Date().toISOString(),
    }).eq("id", d.id);
    load();
  }
  async function del(id: string) {
    await supabase.from("portal_onboarding_docs").delete().eq("id", id);
    load();
  }

  return (
    <div className="space-y-4">
      {role === "admin" ? (
        <form onSubmit={addDoc} className={card + " space-y-2"}>
          <div className="text-sm font-semibold text-foreground">Add document request</div>
          <input className={input} placeholder="Title (e.g. NDA, Brand assets)" value={title} onChange={(e) => setTitle(e.target.value)} />
          <textarea className={input} rows={2} placeholder="Description" value={desc} onChange={(e) => setDesc(e.target.value)} />
          <button className={btnPri}>Add</button>
        </form>
      ) : (
        <div className={card + " flex items-center justify-between"}>
          <div className="text-sm text-foreground">Need to send documents to the team?</div>
          <button onClick={requestDocs} className={btnPri}>Request documents</button>
        </div>
      )}
      <div className="space-y-3">
        {docs.length === 0 && <Empty label="No onboarding documents yet." />}
        {docs.map((d) => (
          <OnboardingItem key={d.id} d={d} role={role} onAttach={attach} onDecide={decide} onView={(v) => setOpen(v)} onDelete={() => del(d.id)} />
        ))}
      </div>
      <FileViewerOverlay file={open} onClose={() => setOpen(null)} />
    </div>
  );
}

function OnboardingItem({ d, role, onAttach, onDecide, onView, onDelete }: {
  d: PortalOnboardingDoc; role: Role;
  onAttach: (d: PortalOnboardingDoc, f: File) => void;
  onDecide: (d: PortalOnboardingDoc, s: OnboardingStatus, c?: string, sig?: string) => void;
  onView: (v: ViewableFile) => void;
  onDelete: () => void;
}) {
  const [comment, setComment] = useState("");
  const [sig, setSig] = useState("");
  return (
    <div className={card + " space-y-2"}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1">
          <div className="text-sm font-semibold text-foreground">{d.title}</div>
          {d.description && <div className="text-xs text-muted-foreground mt-0.5">{d.description}</div>}
          <div className="text-[11px] mt-1">
            <span className={`px-2 py-0.5 rounded-full ${d.status === "pending" ? "bg-muted text-muted-foreground" : d.status === "rejected" ? "bg-destructive/15 text-destructive" : d.status === "changes" ? "bg-amber-500/15 text-amber-600" : "bg-green-500/15 text-green-600"}`}>{d.status}</span>
          </div>
        </div>
        {role === "admin" && <button onClick={onDelete} className={btnDanger}>Delete</button>}
      </div>
      {d.doc_storage_path ? (
        <button onClick={() => onView({ url: publicUrl(d.doc_storage_path!), name: d.doc_name ?? "document", mime: d.doc_mime })} className={btnSec}>
          📄 Open {d.doc_name ?? "document"}
        </button>
      ) : role === "admin" ? (
        <label className={btnSec + " cursor-pointer inline-block"}>
          Upload file
          <input type="file" className="hidden" onChange={(e) => e.target.files?.[0] && onAttach(d, e.target.files[0])} />
        </label>
      ) : <div className="text-xs text-muted-foreground">Waiting for document…</div>}
      {role === "client" && d.doc_storage_path && d.status === "pending" && (
        <div className="space-y-2 pt-2 border-t border-border">
          <input className={input} placeholder="Type your full name to e-sign" value={sig} onChange={(e) => setSig(e.target.value)} />
          <textarea className={input} rows={2} placeholder="Optional comment" value={comment} onChange={(e) => setComment(e.target.value)} />
          <div className="flex flex-wrap gap-2">
            <button onClick={() => sig.trim() && onDecide(d, "esigned", comment, sig)} className={btnPri}>E-sign</button>
            <button onClick={() => onDecide(d, "accepted", comment)} className={btnSec}>Accept</button>
            <button onClick={() => onDecide(d, "rejected", comment)} className={btnDanger}>Reject</button>
            <button onClick={() => onDecide(d, "changes", comment)} className={btnSec}>Request changes</button>
          </div>
        </div>
      )}
      {d.client_comment && <div className="text-xs text-muted-foreground border-t border-border pt-2">Client: {d.client_comment}</div>}
      {d.signature_name && <div className="text-xs text-muted-foreground">Signed by {d.signature_name} on {fmtDate(d.signed_at)}</div>}
    </div>
  );
}

// ─── REPORT ──────────────────────────────────────────────────────────────────
export function ReportModule({ clientId, role }: { clientId: string; role: Role }) {
  const [r, setR] = useState<PortalReport | null>(null);
  const [stage, setStage] = useState("");
  const [progress, setProgress] = useState(0);
  const [notes, setNotes] = useState("");
  const [milestones, setMilestones] = useState<{ title: string; done: boolean }[]>([]);
  const [milestoneTitle, setMilestoneTitle] = useState("");

  async function load() {
    const { data } = await supabase.from("portal_reports").select("*").eq("client_id", clientId).maybeSingle();
    if (data) {
      setR(data as PortalReport);
      setStage(data.stage ?? ""); setProgress(data.progress_pct ?? 0); setNotes(data.notes ?? "");
      setMilestones((data.milestones as any) ?? []);
    }
  }
  useEffect(() => { load(); }, [clientId]);

  async function save() {
    await supabase.from("portal_reports").upsert({
      client_id: clientId, stage, progress_pct: progress, notes, milestones, updated_at: new Date().toISOString(),
    });
    load();
  }
  async function delReport() {
    await supabase.from("portal_reports").delete().eq("client_id", clientId);
    setR(null); setStage(""); setProgress(0); setNotes(""); setMilestones([]);
  }

  if (role === "client") {
    return (
      <div className={card + " space-y-3"}>
        {!r ? <Empty label="No report yet." /> : (
          <>
            <div className="text-sm font-semibold text-foreground">{r.stage || "Project status"}</div>
            <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
              <div className="h-full bg-primary" style={{ width: `${r.progress_pct ?? 0}%` }} />
            </div>
            <div className="text-xs text-muted-foreground">{r.progress_pct ?? 0}% complete · updated {fmtDate(r.updated_at)}</div>
            {r.notes && <div className="text-sm text-foreground whitespace-pre-wrap">{r.notes}</div>}
            {milestones.length > 0 && (
              <ul className="space-y-1.5 pt-2 border-t border-border">
                {milestones.map((m, i) => (
                  <li key={i} className="text-sm flex items-center gap-2">
                    <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${m.done ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>{m.done ? "✓" : ""}</span>
                    <span className={m.done ? "line-through text-muted-foreground" : "text-foreground"}>{m.title}</span>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </div>
    );
  }

  return (
    <div className={card + " space-y-3"}>
      <div className="text-sm font-semibold text-foreground">Project report</div>
      <input className={input} placeholder="Stage (e.g. Design phase)" value={stage} onChange={(e) => setStage(e.target.value)} />
      <div>
        <label className="text-xs text-muted-foreground">Progress: {progress}%</label>
        <input type="range" min={0} max={100} value={progress} onChange={(e) => setProgress(Number(e.target.value))} className="w-full" />
      </div>
      <textarea className={input} rows={4} placeholder="Notes / update for client" value={notes} onChange={(e) => setNotes(e.target.value)} />
      <div className="space-y-1.5">
        <div className="text-xs font-medium text-muted-foreground">Milestones</div>
        {milestones.map((m, i) => (
          <div key={i} className="flex items-center gap-2">
            <input type="checkbox" checked={m.done} onChange={(e) => setMilestones((arr) => arr.map((x, j) => j === i ? { ...x, done: e.target.checked } : x))} />
            <input className={input + " flex-1 py-1 text-xs"} value={m.title} onChange={(e) => setMilestones((arr) => arr.map((x, j) => j === i ? { ...x, title: e.target.value } : x))} />
            <button onClick={() => setMilestones((arr) => arr.filter((_, j) => j !== i))} className={btnDanger}>×</button>
          </div>
        ))}
        <div className="flex gap-2">
          <input className={input + " flex-1 py-1 text-xs"} placeholder="Add milestone" value={milestoneTitle} onChange={(e) => setMilestoneTitle(e.target.value)} />
          <button onClick={() => { if (milestoneTitle.trim()) { setMilestones((m) => [...m, { title: milestoneTitle, done: false }]); setMilestoneTitle(""); } }} className={btnSec}>+ Add</button>
        </div>
      </div>
      <div className="flex gap-2 pt-2">
        <button onClick={save} className={btnPri}>Save</button>
        {r && <button onClick={delReport} className={btnDanger}>Delete</button>}
      </div>
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
export function DashboardModule({ clientId, role, onJump }: { clientId: string; role: Role; onJump?: (tab: string) => void }) {
  const [stats, setStats] = useState({
    tasksTotal: 0, tasksDone: 0, tasksInProgress: 0, tasksTodo: 0,
    messages: 0, unreadFromClient: 0, unreadFromAdmin: 0,
    files: 0,
    onboardingTotal: 0, onboardingPending: 0,
    progress: 0, stage: "", milestonesDone: 0, milestonesTotal: 0,
  });
  const [recentMessages, setRecentMessages] = useState<PortalMessage[]>([]);
  const [recentTasks, setRecentTasks] = useState<PortalTask[]>([]);

  async function load() {
    const [tasksRes, msgsRes, filesRes, onbRes, repRes] = await Promise.all([
      supabase.from("portal_tasks").select("*").eq("client_id", clientId),
      supabase.from("portal_messages").select("*").eq("client_id", clientId).order("created_at", { ascending: false }),
      supabase.from("portal_files").select("id").eq("client_id", clientId),
      supabase.from("portal_onboarding_docs").select("id,status").eq("client_id", clientId),
      supabase.from("portal_reports").select("*").eq("client_id", clientId).maybeSingle(),
    ]);
    const tasks = (tasksRes.data ?? []) as PortalTask[];
    const msgs = (msgsRes.data ?? []) as PortalMessage[];
    const files = filesRes.data ?? [];
    const onb = (onbRes.data ?? []) as { id: string; status: OnboardingStatus }[];
    const rep = repRes.data as PortalReport | null;
    const milestones = (rep?.milestones ?? []) as { title: string; done: boolean }[];

    setStats({
      tasksTotal: tasks.length,
      tasksDone: tasks.filter((t) => t.status === "done").length,
      tasksInProgress: tasks.filter((t) => t.status === "in_progress").length,
      tasksTodo: tasks.filter((t) => t.status === "todo").length,
      messages: msgs.length,
      unreadFromClient: msgs.filter((m) => m.sender === "client" && !m.read_at).length,
      unreadFromAdmin: msgs.filter((m) => m.sender === "admin" && !m.read_at).length,
      files: files.length,
      onboardingTotal: onb.length,
      onboardingPending: onb.filter((o) => o.status === "pending").length,
      progress: rep?.progress_pct ?? 0,
      stage: rep?.stage ?? "",
      milestonesDone: milestones.filter((m) => m.done).length,
      milestonesTotal: milestones.length,
    });
    setRecentMessages(msgs.slice(0, 4));
    setRecentTasks(tasks.slice(0, 5));
  }

  useEffect(() => { load(); }, [clientId]);
  useEffect(() => {
    const ch = supabase.channel(`dash:${clientId}`)
      .on("postgres_changes", { event: "*", schema: "public", filter: `client_id=eq.${clientId}` }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [clientId]);

  const unread = role === "admin" ? stats.unreadFromClient : stats.unreadFromAdmin;
  const Tile = ({ label, value, hint, tab, accent }: { label: string; value: string | number; hint?: string; tab?: string; accent?: string }) => (
    <button
      onClick={() => tab && onJump?.(tab)}
      className={`text-left ${card} hover:border-primary/40 transition-colors`}
    >
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold">{label}</div>
      <div className={`text-2xl font-bold mt-1 ${accent ?? "text-foreground"}`}>{value}</div>
      {hint && <div className="text-xs text-muted-foreground mt-1">{hint}</div>}
    </button>
  );

  return (
    <div className="space-y-5">
      {/* Progress hero */}
      <div className={card}>
        <div className="flex items-center justify-between mb-2">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Project progress</div>
            <div className="text-lg font-bold text-foreground mt-0.5">{stats.stage || "Not set"}</div>
          </div>
          <div className="text-3xl font-bold text-primary">{stats.progress}%</div>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-primary transition-all" style={{ width: `${Math.min(100, Math.max(0, stats.progress))}%` }} />
        </div>
        {stats.milestonesTotal > 0 && (
          <div className="text-xs text-muted-foreground mt-2">
            {stats.milestonesDone} of {stats.milestonesTotal} milestones completed
          </div>
        )}
      </div>

      {/* Stat grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Tile label="Tasks" value={`${stats.tasksDone}/${stats.tasksTotal}`} hint={`${stats.tasksInProgress} in progress · ${stats.tasksTodo} to-do`} tab="tasks" />
        <Tile label="Messages" value={stats.messages} hint={unread > 0 ? `${unread} new` : "All caught up"} tab="messages" accent={unread > 0 ? "text-primary" : undefined} />
        <Tile label="Files" value={stats.files} hint="Shared documents" tab="files" />
        <Tile label="Onboarding" value={`${stats.onboardingTotal - stats.onboardingPending}/${stats.onboardingTotal}`} hint={stats.onboardingPending > 0 ? `${stats.onboardingPending} pending` : "Complete"} tab="onboarding" />
      </div>

      {/* Two-column lists */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className={card}>
          <div className="flex items-center justify-between mb-3">
            <div className="text-sm font-semibold text-foreground">Recent tasks</div>
            <button onClick={() => onJump?.("tasks")} className="text-xs text-primary hover:underline">View all</button>
          </div>
          {recentTasks.length === 0 ? (
            <div className="text-xs text-muted-foreground py-6 text-center">No tasks yet.</div>
          ) : (
            <ul className="space-y-2">
              {recentTasks.map((t) => (
                <li key={t.id} className="flex items-center gap-2 text-sm">
                  <span className={`inline-block w-1.5 h-1.5 rounded-full ${t.status === "done" ? "bg-green-500" : t.status === "in_progress" ? "bg-yellow-500" : "bg-muted-foreground"}`} />
                  <span className="flex-1 truncate text-foreground">{t.title}</span>
                  <span className="text-[10px] uppercase text-muted-foreground">{t.status.replace("_", " ")}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className={card}>
          <div className="flex items-center justify-between mb-3">
            <div className="text-sm font-semibold text-foreground">Recent messages</div>
            <button onClick={() => onJump?.("messages")} className="text-xs text-primary hover:underline">Open chat</button>
          </div>
          {recentMessages.length === 0 ? (
            <div className="text-xs text-muted-foreground py-6 text-center">No messages yet.</div>
          ) : (
            <ul className="space-y-2">
              {recentMessages.map((m) => (
                <li key={m.id} className="text-sm border-b border-border last:border-0 pb-2 last:pb-0">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] uppercase font-semibold ${m.sender === "admin" ? "text-primary" : "text-muted-foreground"}`}>{m.sender}</span>
                    <span className="text-[10px] text-muted-foreground ml-auto">{fmtTime(m.created_at)}</span>
                  </div>
                  <div className="text-foreground truncate">{m.body}</div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
