// ═════════════════════════════════════════════════════════════════════════════
// Real PDF generation with jsPDF.
// - Produces a true binary PDF (not HTML).
// - Embeds a "Pay with Razorpay" button (link annotation) when a link is present.
// - Uploads to the Supabase `documents` bucket and returns a public URL.
// ═════════════════════════════════════════════════════════════════════════════

import { jsPDF } from "jspdf";
import { supabase, type Quotation, type Invoice } from "./supabase";

const BRAND = {
  red: "#e63a3a",
  ink: "#1a1a1a",
  muted: "#6b7280",
  light: "#f9fafb",
  border: "#e5e7eb",
};

function fmtMoney(n: number, currency: "INR" | "USD" = "INR") {
  const sym = currency === "INR" ? "Rs. " : "$";
  return `${sym}${n.toLocaleString(currency === "INR" ? "en-IN" : "en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function setColor(pdf: jsPDF, hex: string, kind: "draw" | "fill" | "text") {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  if (kind === "draw") pdf.setDrawColor(r, g, b);
  if (kind === "fill") pdf.setFillColor(r, g, b);
  if (kind === "text") pdf.setTextColor(r, g, b);
}

function drawHeader(pdf: jsPDF, docType: string, meta: string[]) {
  // Brand
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(22);
  setColor(pdf, BRAND.red, "text");
  pdf.text("eassets", 40, 60);
  setColor(pdf, BRAND.ink, "text");
  pdf.text(".studio", 40 + pdf.getTextWidth("eassets"), 60);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  setColor(pdf, BRAND.muted, "text");
  pdf.text("hreassets@gmail.com", 40, 76);

  // Doc type (right)
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(24);
  setColor(pdf, BRAND.ink, "text");
  pdf.text(docType, 555, 60, { align: "right" });
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  setColor(pdf, BRAND.muted, "text");
  meta.forEach((line, i) => pdf.text(line, 555, 76 + i * 12, { align: "right" }));

  // Divider
  setColor(pdf, BRAND.red, "draw");
  pdf.setLineWidth(1.5);
  pdf.line(40, 100, 555, 100);
}

function drawFooter(pdf: jsPDF, msg: string, docLabel: "invoice" | "quotation" = "invoice") {
  const pageH = pdf.internal.pageSize.getHeight();
  setColor(pdf, BRAND.border, "draw");
  pdf.setLineWidth(0.5);
  pdf.line(40, pageH - 78, 555, pageH - 78);
  setColor(pdf, BRAND.muted, "text");
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(8);
  pdf.text(msg, 297.5, pageH - 60, { align: "center" });
  // Website link (clickable)
  setColor(pdf, "#1d4ed8", "text");
  const siteUrl = "https://eassets-studio.vercel.app";
  pdf.textWithLink("eassets-studio.vercel.app", 297.5, pageH - 46, {
    url: siteUrl,
    align: "center",
  });
  // E-signature notice
  setColor(pdf, BRAND.muted, "text");
  pdf.setFontSize(7.5);
  pdf.text(
    `This is an electronically generated ${docLabel} & does not require a physical signature.`,
    297.5,
    pageH - 32,
    { align: "center" }
  );
}

function drawSectionLabel(pdf: jsPDF, label: string, y: number) {
  setColor(pdf, BRAND.muted, "text");
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(8);
  pdf.text(label.toUpperCase(), 40, y);
}

function drawItemsTable(
  pdf: jsPDF,
  startY: number,
  items: { description: string; quantity: number; rate: number }[],
  currency: "INR" | "USD"
): number {
  const cols = { desc: 40, qty: 340, rate: 410, amt: 480 };
  const rowH = 22;

  // Header bar
  setColor(pdf, BRAND.ink, "fill");
  pdf.rect(40, startY, 515, rowH, "F");
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(9);
  setColor(pdf, "#ffffff", "text");
  pdf.text("DESCRIPTION", cols.desc + 8, startY + 14);
  pdf.text("QTY", cols.qty + 25, startY + 14, { align: "center" });
  pdf.text("RATE", cols.rate + 60, startY + 14, { align: "right" });
  pdf.text("AMOUNT", cols.amt + 70, startY + 14, { align: "right" });

  let y = startY + rowH;
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  items.forEach((it, i) => {
    if (i % 2 === 1) {
      setColor(pdf, BRAND.light, "fill");
      pdf.rect(40, y, 515, rowH, "F");
    }
    setColor(pdf, BRAND.ink, "text");
    const desc = pdf.splitTextToSize(it.description || "—", cols.qty - cols.desc - 16);
    pdf.text(desc[0] ?? "—", cols.desc + 8, y + 14);
    pdf.text(String(it.quantity), cols.qty + 25, y + 14, { align: "center" });
    pdf.text(fmtMoney(it.rate, currency), cols.rate + 60, y + 14, { align: "right" });
    pdf.text(fmtMoney(it.quantity * it.rate, currency), cols.amt + 70, y + 14, {
      align: "right",
    });
    y += rowH;
  });

  // Bottom border
  setColor(pdf, BRAND.border, "draw");
  pdf.setLineWidth(0.5);
  pdf.line(40, y, 555, y);
  return y + 8;
}

function drawTotals(
  pdf: jsPDF,
  y: number,
  rows: { label: string; value: string; bold?: boolean }[]
): number {
  const xLabel = 380;
  const xValue = 555;
  rows.forEach((r) => {
    pdf.setFont("helvetica", r.bold ? "bold" : "normal");
    pdf.setFontSize(r.bold ? 12 : 10);
    setColor(pdf, r.bold ? BRAND.ink : BRAND.muted, "text");
    if (r.bold) {
      setColor(pdf, BRAND.ink, "draw");
      pdf.setLineWidth(1);
      pdf.line(xLabel, y - 4, xValue, y - 4);
      y += 6;
    }
    pdf.text(r.label, xLabel, y + 12);
    setColor(pdf, BRAND.ink, "text");
    pdf.text(r.value, xValue, y + 12, { align: "right" });
    y += 18;
  });
  return y;
}

function drawPayButton(pdf: jsPDF, link: string, y: number): number {
  // Pay with Razorpay button — link annotation makes it clickable in PDF readers
  const x = 40;
  const w = 200;
  const h = 38;
  setColor(pdf, "#072654", "fill"); // Razorpay navy
  pdf.roundedRect(x, y, w, h, 6, 6, "F");
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(11);
  setColor(pdf, "#ffffff", "text");
  pdf.text("Pay with Razorpay  →", x + w / 2, y + 24, { align: "center" });
  pdf.link(x, y, w, h, { url: link });

  // Helper text + raw link for fallback
  setColor(pdf, BRAND.muted, "text");
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(8);
  pdf.text("Click the button above to pay securely. Or open this link:", x, y + h + 14);
  setColor(pdf, "#1d4ed8", "text");
  pdf.textWithLink(link, x, y + h + 26, { url: link });
  return y + h + 40;
}

// ───────────────────────────────────────────────────────────────────── Quotation

export function buildQuotationPDF(q: Quotation): jsPDF {
  const pdf = new jsPDF({ unit: "pt", format: "a4" });
  const date = new Date(q.created_at).toLocaleDateString("en-IN", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  drawHeader(pdf, "QUOTATION", [
    `ID: ${q.id.slice(0, 8).toUpperCase()}`,
    `Date: ${date}`,
  ]);

  let y = 130;
  drawSectionLabel(pdf, "Prepared for", y);
  y += 14;
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(12);
  setColor(pdf, BRAND.ink, "text");
  pdf.text(q.client_name || "Client", 40, y + 4);
  if (q.client_email) {
    y += 16;
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    setColor(pdf, BRAND.muted, "text");
    pdf.text(q.client_email, 40, y + 4);
  }

  y += 32;
  y = drawItemsTable(pdf, y, q.items, q.currency ?? "INR");

  y = drawTotals(pdf, y + 6, [
    { label: "Total", value: fmtMoney(q.total, q.currency ?? "INR"), bold: true },
  ]);

  if (q.budget_min || q.budget_max) {
    y += 14;
    drawSectionLabel(pdf, "Indicated budget", y);
    y += 14;
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(10);
    setColor(pdf, BRAND.ink, "text");
    pdf.text(
      `${fmtMoney(q.budget_min ?? 0, q.currency ?? "INR")} – ${fmtMoney(
        q.budget_max ?? 0,
        q.currency ?? "INR"
      )}`,
      40,
      y + 4
    );
  }

  drawFooter(pdf, "This quotation is valid for 30 days from the date of issue.", "quotation");
  return pdf;
}

// ───────────────────────────────────────────────────────────────────── Invoice

export function buildInvoicePDF(inv: Invoice): jsPDF {
  const pdf = new jsPDF({ unit: "pt", format: "a4" });
  const date = new Date(inv.created_at).toLocaleDateString("en-IN", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  drawHeader(pdf, "INVOICE", [
    inv.invoice_number,
    `Date: ${date}`,
    inv.payment_terms ? `Terms: ${inv.payment_terms}` : "",
  ].filter(Boolean));

  let y = 130;
  drawSectionLabel(pdf, "Bill to", y);
  y += 14;
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(12);
  setColor(pdf, BRAND.ink, "text");
  pdf.text(inv.client_name || "Client", 40, y + 4);
  if (inv.client_email) {
    y += 16;
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    setColor(pdf, BRAND.muted, "text");
    pdf.text(inv.client_email, 40, y + 4);
  }

  y += 32;
  y = drawItemsTable(pdf, y, inv.items, inv.currency);

  const totals: { label: string; value: string; bold?: boolean }[] = [
    { label: "Subtotal", value: fmtMoney(inv.subtotal, inv.currency) },
  ];
  if (inv.tax_enabled) {
    totals.push({ label: "GST (18%)", value: fmtMoney(inv.tax_amount, inv.currency) });
  }
  totals.push({ label: "Total", value: fmtMoney(inv.total, inv.currency), bold: true });
  y = drawTotals(pdf, y + 6, totals);

  // Payment section
  if (inv.upi_id || inv.razorpay_link) {
    y += 18;
    drawSectionLabel(pdf, "Payment", y);
    y += 16;
    if (inv.upi_id) {
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(10);
      setColor(pdf, BRAND.ink, "text");
      pdf.text(`UPI: ${inv.upi_id}`, 40, y);
      y += 18;
    }
    if (inv.razorpay_link) {
      y = drawPayButton(pdf, inv.razorpay_link, y);
    }
  }

  if (inv.notes) {
    y += 12;
    drawSectionLabel(pdf, "Notes", y);
    y += 14;
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    setColor(pdf, BRAND.ink, "text");
    const lines = pdf.splitTextToSize(inv.notes, 515);
    pdf.text(lines, 40, y + 4);
  }

  drawFooter(pdf, "Thank you for your business.", "invoice");
  return pdf;
}

// ───────────────────────────────────────────────────── Browser download helpers

export function downloadQuotationPDF(q: Quotation) {
  buildQuotationPDF(q).save(`quotation-${q.id.slice(0, 8)}.pdf`);
}

export function downloadInvoicePDF(inv: Invoice) {
  buildInvoicePDF(inv).save(`invoice-${inv.invoice_number}.pdf`);
}

// ─────────────────────────────────────────── Upload to Storage + return URL

async function uploadPdf(
  pdf: jsPDF,
  bucket: "documents",
  path: string
): Promise<string> {
  const blob = pdf.output("blob");
  const { error } = await supabase.storage
    .from(bucket)
    .upload(path, blob, { contentType: "application/pdf", upsert: true });
  if (error) throw new Error(`PDF upload failed: ${error.message}`);
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
}

/** Generate quotation PDF, upload to Storage, persist `pdf_url`, return the URL. */
export async function generateAndUploadQuotationPDF(q: Quotation): Promise<string> {
  const pdf = buildQuotationPDF(q);
  const path = `quotations/${q.id}.pdf`;
  const url = await uploadPdf(pdf, "documents", path);
  await supabase
    .from("quotations")
    .update({ pdf_url: url, pdf_uploaded_at: new Date().toISOString() })
    .eq("id", q.id);
  return url;
}

/** Generate invoice PDF, upload to Storage, persist `pdf_url`, return the URL. */
export async function generateAndUploadInvoicePDF(inv: Invoice): Promise<string> {
  const pdf = buildInvoicePDF(inv);
  const path = `invoices/${inv.id}.pdf`;
  const url = await uploadPdf(pdf, "documents", path);
  await supabase
    .from("invoices")
    .update({ pdf_url: url, pdf_uploaded_at: new Date().toISOString() })
    .eq("id", inv.id);
  return url;
}

// ─────────────────────────────────────────────── PDF as base64 (email attach)

export function pdfToBase64(pdf: jsPDF): string {
  // jsPDF returns a data URI like "data:application/pdf;base64,JVBERi0..."
  // Strip the prefix so we send raw base64 to Brevo.
  const dataUri = pdf.output("datauristring");
  const idx = dataUri.indexOf("base64,");
  return idx >= 0 ? dataUri.slice(idx + 7) : dataUri;
}
