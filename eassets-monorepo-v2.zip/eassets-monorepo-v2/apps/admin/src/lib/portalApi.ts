import { supabase } from "@/lib/supabase";

export type TaskStatus = "todo" | "in_progress" | "done";
export type Sender = "admin" | "client";
export type OnboardingStatus = "pending" | "esigned" | "accepted" | "rejected" | "changes";

export interface PortalTask {
  id: string;
  client_id: string;
  title: string;
  description?: string;
  status: TaskStatus;
  due_date?: string;
  created_at: string;
  updated_at: string;
}

export interface PortalMessage {
  id: string;
  client_id: string;
  sender: Sender;
  body: string;
  read_at?: string;
  created_at: string;
}

export interface PortalFile {
  id: string;
  client_id: string;
  uploader: Sender;
  name: string;
  mime?: string;
  size?: number;
  storage_path: string;
  created_at: string;
}

export interface PortalOnboardingDoc {
  id: string;
  client_id: string;
  title: string;
  description?: string;
  doc_storage_path?: string;
  doc_name?: string;
  doc_mime?: string;
  status: OnboardingStatus;
  client_comment?: string;
  signature_name?: string;
  signed_at?: string;
  created_at: string;
  updated_at: string;
}

export interface PortalReport {
  client_id: string;
  stage?: string;
  progress_pct?: number;
  notes?: string;
  milestones?: { title: string; done: boolean }[];
  updated_at: string;
}

const BUCKET = "portal-files";

export function publicUrl(path: string): string {
  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
  return data.publicUrl;
}

export async function uploadPortalFile(clientId: string, file: File, uploader: Sender): Promise<PortalFile | null> {
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const path = `${clientId}/${Date.now()}_${safeName}`;
  const { error: upErr } = await supabase.storage.from(BUCKET).upload(path, file, {
    contentType: file.type || undefined,
    upsert: false,
  });
  if (upErr) return null;
  const { data, error } = await supabase.from("portal_files").insert({
    client_id: clientId,
    uploader,
    name: file.name,
    mime: file.type,
    size: file.size,
    storage_path: path,
  }).select().single();
  if (error) return null;
  return data as PortalFile;
}

export async function uploadOnboardingFile(clientId: string, file: File): Promise<{ path: string; name: string; mime: string } | null> {
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const path = `${clientId}/onboarding/${Date.now()}_${safeName}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    contentType: file.type || undefined,
    upsert: false,
  });
  if (error) return null;
  return { path, name: file.name, mime: file.type };
}

export async function deletePortalFile(file: PortalFile) {
  await supabase.storage.from(BUCKET).remove([file.storage_path]);
  await supabase.from("portal_files").delete().eq("id", file.id);
}

export function fmtBytes(b?: number) {
  if (!b) return "—";
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1024 / 1024).toFixed(1)} MB`;
}

export function fmtDate(d?: string) {
  if (!d) return "";
  return new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

export function fmtTime(d: string) {
  return new Date(d).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
}
