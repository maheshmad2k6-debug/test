import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = "https://jbqgjqyeopolflojihtq.supabase.co";
const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpicWdqcXllb3BvbGZsb2ppaHRxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzcxODI0MTgsImV4cCI6MjA5Mjc1ODQxOH0.5EMw2BoBKyUE_2O5MtNSgI1KWZlxGmKl7xslrTSi09I";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ─── Types ────────────────────────────────────────────────────────────────────

export interface Client {
  id: string;
  name: string;
  email: string;
  phone?: string;
  company?: string;
  notes?: string;
  created_at: string;
}

export interface Project {
  id: string;
  client_id?: string;
  title: string;
  status?: string;
  description?: string;
  sector?: string;
  url?: string;
  cover_url?: string;
  cover_type?: "image" | "video";
  sort_order?: number;
  published?: boolean;
  created_at: string;
}

export type MediaLayout = "hero" | "full" | "left" | "right" | "mockup";

export interface ProjectMedia {
  id: string;
  project_id: string;
  url: string;
  storage_path?: string;
  type: "image" | "video";
  layout?: MediaLayout;
  sort_order: number;
  created_at: string;
}

export interface Payment {
  id: string;
  client_id?: string;
  invoice_id?: string;
  amount: number;
  status: "paid" | "pending" | "overdue";
  type?: string;
  created_at: string;
}

export interface Message {
  id: string;
  name: string;
  email: string;
  subject?: string;
  message: string;
  created_at: string;
}

export interface Booking {
  id: string;
  name: string;
  email: string;
  phone?: string;
  date: string;
  time_slot?: string;
  /** ISO timestamp (UTC). Preferred over `date` + `time_slot` — preserves timezone correctly. */
  scheduled_at?: string;
  message?: string;
  status: "pending" | "confirmed" | "cancelled";
  created_at: string;
}

export interface QuotationItem {
  description: string;
  quantity: number;
  rate: number;
}

export interface Quotation {
  id: string;
  client_id?: string;
  client_name?: string;
  client_email?: string;
  items: QuotationItem[];
  total: number;
  currency?: "INR" | "USD";
  budget_min?: number;
  budget_max?: number;
  notes?: string;
  payment_terms?: string;
  razorpay_button_html?: string;
  status: "draft" | "sent" | "accepted" | "rejected";
  pdf_url?: string;
  pdf_uploaded_at?: string;
  created_at: string;
}

export interface InvoiceItem {
  description: string;
  quantity: number;
  rate: number;
}

export interface Invoice {
  id: string;
  invoice_number: string;
  client_id?: string;
  client_name?: string;
  client_email?: string;
  items: InvoiceItem[];
  subtotal: number;
  tax_enabled: boolean;
  tax_amount: number;
  total: number;
  currency: "INR" | "USD";
  upi_id?: string;
  razorpay_link?: string;
  razorpay_key_id?: string;
  /** Raw HTML snippet from Razorpay Payment Button dashboard. Rendered as-is in invoice preview. */
  razorpay_button_html?: string;
  payment_terms?: string;
  notes?: string;
  status: "pending" | "sent" | "paid" | "overdue";
  pdf_url?: string;
  pdf_uploaded_at?: string;
  created_at: string;
}

export interface ProjectInquiry {
  id: string;
  project_id?: string;
  project_title?: string;
  name: string;
  email: string;
  phone?: string;
  message?: string;
  status: "new" | "contacted" | "closed";
  created_at: string;
}

export interface Review {
  id: string;
  author: string;
  content: string;
  rating?: number;
  created_at: string;
}

export type DocType =
  | "nda"
  | "discovery"
  | "proposal"
  | "service_agreement"
  | "sow"
  | "quotation_invoice"
  | "project_brief"
  | "brand_checklist"
  | "timeline"
  | "ip_assignment"
  | "terms_privacy";

export interface StudioDocument {
  id: string;
  client_id?: string;
  client_name?: string;
  client_email?: string;
  doc_type: DocType;
  title: string;
  /** Markdown-ish body. Lines starting with "# " become H1, "## " H2, blank lines are paragraph breaks. */
  body: string;
  metadata: Record<string, string>;
  created_at: string;
  updated_at: string;
}
