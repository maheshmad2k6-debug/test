import type { Quotation, Invoice } from "./supabase";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatCurrency(amount: number, currency: "INR" | "USD" = "INR") {
  return currency === "INR"
    ? `₹${amount.toLocaleString("en-IN", { minimumFractionDigits: 2 })}`
    : `$${amount.toLocaleString("en-US", { minimumFractionDigits: 2 })}`;
}

function buildHTML(content: string): string {
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Arial, sans-serif; color: #1a1a1a; background: #fff; padding: 40px; font-size: 14px; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; border-bottom: 2px solid #e63a3a; padding-bottom: 24px; }
  .brand { font-size: 24px; font-weight: 700; color: #e63a3a; letter-spacing: -0.5px; }
  .brand span { color: #1a1a1a; }
  .doc-type { font-size: 28px; font-weight: 700; color: #1a1a1a; text-align: right; }
  .doc-meta { font-size: 12px; color: #666; margin-top: 4px; text-align: right; }
  .section { margin-bottom: 28px; }
  .section-title { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #999; margin-bottom: 8px; }
  .info { font-size: 14px; line-height: 1.6; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
  th { background: #1a1a1a; color: #fff; padding: 10px 12px; text-align: left; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
  td { padding: 10px 12px; border-bottom: 1px solid #f0f0f0; }
  tr:last-child td { border-bottom: none; }
  tr:nth-child(even) td { background: #fafafa; }
  .totals { margin-left: auto; width: 280px; }
  .total-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 14px; }
  .total-row.grand { border-top: 2px solid #1a1a1a; margin-top: 8px; padding-top: 12px; font-size: 18px; font-weight: 700; }
  .badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
  .badge-draft { background: #f3f4f6; color: #6b7280; }
  .badge-sent { background: #dbeafe; color: #1d4ed8; }
  .badge-accepted, .badge-paid { background: #dcfce7; color: #16a34a; }
  .badge-rejected, .badge-overdue { background: #fee2e2; color: #dc2626; }
  .badge-pending { background: #fef9c3; color: #ca8a04; }
  .footer { margin-top: 48px; border-top: 1px solid #e5e7eb; padding-top: 20px; font-size: 12px; color: #9ca3af; text-align: center; }
  .payment-box { background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; margin-top: 24px; }
  .payment-title { font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #666; margin-bottom: 10px; }
</style>
</head>
<body>${content}</body>
</html>`;
}

// ─── Content builders ─────────────────────────────────────────────────────────

function buildQuotationContent(q: Quotation): string {
  const date = new Date(q.created_at).toLocaleDateString("en-IN", {
    year: "numeric", month: "long", day: "numeric",
  });
  const rows = q.items.map((item) => `
    <tr>
      <td>${item.description}</td>
      <td style="text-align:center">${item.quantity}</td>
      <td style="text-align:right">${formatCurrency(item.rate)}</td>
      <td style="text-align:right">${formatCurrency(item.quantity * item.rate)}</td>
    </tr>`).join("");

  return `
    <div class="header">
      <div>
        <div class="brand">eassets<span>.studio</span></div>
        <div style="font-size:12px;color:#666;margin-top:6px">hreassets@gmail.com</div>
      </div>
      <div>
        <div class="doc-type">QUOTATION</div>
        <div class="doc-meta">ID: ${q.id.slice(0, 8).toUpperCase()}</div>
        <div class="doc-meta">Date: ${date}</div>
      </div>
    </div>
    <div class="section">
      <div class="section-title">Prepared for</div>
      <div class="info"><strong>${q.client_name || "Client"}</strong></div>
    </div>
    <table>
      <thead><tr>
        <th>Description</th>
        <th style="text-align:center;width:80px">Qty</th>
        <th style="text-align:right;width:120px">Rate</th>
        <th style="text-align:right;width:120px">Amount</th>
      </tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <div class="totals">
      <div class="total-row grand"><span>Total</span><span>${formatCurrency(q.total)}</span></div>
    </div>
    <div class="footer">
      This quotation is valid for 30 days from the date of issue.<br/>
      <a href="https://eassets-studio.vercel.app" style="color:#1d4ed8;text-decoration:none">eassets-studio.vercel.app</a><br/>
      <span style="font-size:10px">This is an electronically generated quotation &amp; does not require a physical signature.</span>
    </div>`;
}

function buildInvoiceContent(inv: Invoice): string {
  const date = new Date(inv.created_at).toLocaleDateString("en-IN", {
    year: "numeric", month: "long", day: "numeric",
  });
  const rows = inv.items.map((item) => `
    <tr>
      <td>${item.description}</td>
      <td style="text-align:center">${item.quantity}</td>
      <td style="text-align:right">${formatCurrency(item.rate, inv.currency)}</td>
      <td style="text-align:right">${formatCurrency(item.quantity * item.rate, inv.currency)}</td>
    </tr>`).join("");

  const paymentSection = inv.upi_id || inv.razorpay_link
    ? `<div class="payment-box">
        <div class="payment-title">Payment Details</div>
        ${inv.upi_id ? `<div>UPI ID: <strong>${inv.upi_id}</strong></div>` : ""}
        ${inv.razorpay_link ? `<div style="margin-top:6px">Razorpay: <a href="${inv.razorpay_link}">${inv.razorpay_link}</a></div>` : ""}
      </div>` : "";

  return `
    <div class="header">
      <div>
        <div class="brand">eassets<span>.studio</span></div>
        <div style="font-size:12px;color:#666;margin-top:6px">hreassets@gmail.com</div>
      </div>
      <div>
        <div class="doc-type">INVOICE</div>
        <div class="doc-meta">${inv.invoice_number}</div>
        <div class="doc-meta">Date: ${date}</div>
        ${inv.payment_terms ? `<div class="doc-meta">Terms: ${inv.payment_terms}</div>` : ""}
        
      </div>
    </div>
    <div class="section">
      <div class="section-title">Bill to</div>
      <div class="info"><strong>${inv.client_name || "Client"}</strong></div>
    </div>
    <table>
      <thead><tr>
        <th>Description</th>
        <th style="text-align:center;width:80px">Qty</th>
        <th style="text-align:right;width:140px">Rate</th>
        <th style="text-align:right;width:140px">Amount</th>
      </tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <div class="totals">
      <div class="total-row"><span>Subtotal</span><span>${formatCurrency(inv.subtotal, inv.currency)}</span></div>
      ${inv.tax_enabled ? `<div class="total-row"><span>GST (18%)</span><span>${formatCurrency(inv.tax_amount, inv.currency)}</span></div>` : ""}
      <div class="total-row grand"><span>Total</span><span>${formatCurrency(inv.total, inv.currency)}</span></div>
    </div>
    ${paymentSection}
    ${inv.notes ? `<div class="section" style="margin-top:24px"><div class="section-title">Notes</div><div class="info">${inv.notes}</div></div>` : ""}
    <div class="footer">
      Thank you for your business!<br/>
      <a href="https://eassets-studio.vercel.app" style="color:#1d4ed8;text-decoration:none">eassets-studio.vercel.app</a><br/>
      <span style="font-size:10px">This is an electronically generated invoice &amp; does not require a physical signature.</span>
    </div>`;
}

// ─── HTML → base64 (UTF-8 safe) ──────────────────────────────────────────────

export function htmlToBase64(html: string): string {
  const bytes = new TextEncoder().encode(html);
  let binary = "";
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// ─── Download (print dialog) ──────────────────────────────────────────────────

export async function generateQuotationPDF(q: Quotation): Promise<void> {
  printToPDF(buildHTML(buildQuotationContent(q)), `quotation-${q.id.slice(0, 8)}`);
}

export async function generateInvoicePDF(inv: Invoice): Promise<void> {
  printToPDF(buildHTML(buildInvoiceContent(inv)), `invoice-${inv.invoice_number}`);
}

// ─── Base64 for email attachment ──────────────────────────────────────────────

export function generateQuotationBase64(q: Quotation): string {
  return htmlToBase64(buildHTML(buildQuotationContent(q)));
}

export function generateInvoiceBase64(inv: Invoice): string {
  return htmlToBase64(buildHTML(buildInvoiceContent(inv)));
}

// ─── Print helper ─────────────────────────────────────────────────────────────

function printToPDF(html: string, filename: string): void {
  const win = window.open("", "_blank");
  if (!win) return;
  win.document.write(html);
  win.document.title = filename;
  win.document.close();
  win.focus();
  setTimeout(() => { win.print(); }, 500);
}
