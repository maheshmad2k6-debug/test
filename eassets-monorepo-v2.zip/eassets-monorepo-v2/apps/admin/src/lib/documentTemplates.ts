// ─────────────────────────────────────────────────────────────────────────────
// Default template content for the 11 studio documents.
// Body uses a tiny markdown subset:
//   # Heading 1
//   ## Heading 2
//   - bullet
//   plain paragraph (separated by blank lines)
//   {{placeholders}} are replaced live in the editor preview & docx export.
// ─────────────────────────────────────────────────────────────────────────────

import type { DocType } from "@/lib/supabase";

export interface DocTemplate {
  type: DocType;
  category: "Pre-Project" | "Agreement" | "Kickoff" | "Legal";
  emoji: string;
  title: string;
  description: string;
  defaultBody: string;
  fields: { key: string; label: string; placeholder?: string }[];
}

const STUDIO = {
  name: "EAssets Studio",
  email: "hreassets@gmail.com",
  site: "eassets-studio.vercel.app",
  jurisdiction: "Karnataka, India",
};

const COMMON_FIELDS = [
  { key: "client_name", label: "Client Name", placeholder: "Acme Pvt Ltd" },
  { key: "client_email", label: "Client Email", placeholder: "client@example.com" },
  { key: "project_name", label: "Project Name", placeholder: "Website Redesign" },
  { key: "effective_date", label: "Effective Date", placeholder: "9 May 2026" },
];

export const DOC_TEMPLATES: DocTemplate[] = [
  // ── Pre-Project ──────────────────────────────────────────────────────────
  {
    type: "nda",
    category: "Pre-Project",
    emoji: "🔒",
    title: "Non-Disclosure Agreement",
    description: "Protects both parties' confidential information before sharing sensitive business details.",
    fields: COMMON_FIELDS,
    defaultBody: `# Non-Disclosure Agreement

This Non-Disclosure Agreement ("Agreement") is entered into on {{effective_date}} between ${STUDIO.name} ("Studio"), having its principal place of business in ${STUDIO.jurisdiction}, and {{client_name}} ("Client") (each a "Party" and collectively the "Parties").

## 1. Definition of Confidential Information

"Confidential Information" means any non-public information disclosed by one Party to the other, whether orally, in writing, or in any other form, including but not limited to business plans, designs, source code, customer lists, pricing, marketing strategies, and technical data.

## 2. Obligations of the Receiving Party

The Receiving Party agrees to:
- Hold all Confidential Information in strict confidence.
- Not disclose Confidential Information to any third party without prior written consent.
- Use the Confidential Information solely for the purpose of evaluating or carrying out the proposed engagement.
- Take reasonable steps to protect the Confidential Information from unauthorized access.

## 3. Exclusions

Confidential Information does not include information that:
- Is or becomes publicly known through no fault of the Receiving Party.
- Was lawfully known to the Receiving Party prior to disclosure.
- Is independently developed without use of the Confidential Information.
- Is rightfully obtained from a third party without restriction.

## 4. Term

This Agreement remains in effect for a period of two (2) years from the Effective Date, after which the obligations of confidentiality shall continue indefinitely for trade secrets.

## 5. Return of Materials

Upon written request, the Receiving Party shall promptly return or destroy all materials containing Confidential Information.

## 6. Governing Law

This Agreement shall be governed by and construed in accordance with the laws of ${STUDIO.jurisdiction}.

## 7. Signatures

Signed for and on behalf of ${STUDIO.name}: ____________________

Signed for and on behalf of {{client_name}}: ____________________
`,
  },
  {
    type: "discovery",
    category: "Pre-Project",
    emoji: "🔍",
    title: "Project Discovery / Intake Form",
    description: "Captures the client's goals, audience, design preferences, competitors, and technical requirements.",
    fields: [
      ...COMMON_FIELDS,
      { key: "company", label: "Company", placeholder: "Acme Pvt Ltd" },
      { key: "industry", label: "Industry", placeholder: "SaaS / Fashion / etc." },
    ],
    defaultBody: `# Project Discovery Intake

# {{project_name}}

Date: {{effective_date}}
Client: {{client_name}} ({{company}})
Industry: {{industry}}
Email: {{client_email}}

## 1. Business Background
Briefly describe what your business does and what makes it different.

[Client to complete]

## 2. Project Goals
What are the top 3 outcomes this project must achieve?

1. ____________________
2. ____________________
3. ____________________

## 3. Target Audience
Who is your primary user? Demographics, behaviour, pain points.

[Client to complete]

## 4. Competitors & References
List 3–5 competitor or inspiration websites and what you like / dislike about each.

- ____________________
- ____________________
- ____________________

## 5. Brand & Design
- Brand assets ready? (logo, fonts, colours, guidelines)
- Preferred mood: minimal / bold / luxurious / playful / corporate
- Any colours / styles to avoid

## 6. Functional Requirements
- Pages / screens needed
- Integrations (CRM, payments, analytics, email)
- CMS / admin requirements
- Languages / regions

## 7. Technical Requirements
- Hosting / domain
- Performance expectations
- Accessibility level (WCAG AA / AAA)
- SEO priorities

## 8. Success Metrics
How will we measure success? (conversions, page speed, leads/month, etc.)

## 9. Budget & Timeline
- Indicative budget range
- Hard launch date (if any)
- Internal stakeholders & decision makers
`,
  },
  {
    type: "proposal",
    category: "Pre-Project",
    emoji: "📑",
    title: "Project Proposal",
    description: "Recommended solution, approach, timeline, and pricing — your sales document.",
    fields: [
      ...COMMON_FIELDS,
      { key: "total_value", label: "Total Value (₹)", placeholder: "2,50,000" },
      { key: "duration_weeks", label: "Duration (weeks)", placeholder: "8" },
    ],
    defaultBody: `# Project Proposal

# {{project_name}}

Date: {{effective_date}}
Prepared for: {{client_name}}
Prepared by: ${STUDIO.name}

## 1. Executive Summary

Thank you for the opportunity to collaborate on {{project_name}}. This proposal outlines our recommended approach, scope, timeline, and investment.

## 2. Understanding the Brief

[Summarise client problem, audience, and goals captured during discovery]

## 3. Our Approach

We propose a {{duration_weeks}}-week engagement structured into four phases:

1. **Discovery & Strategy** — research, audit, sitemap, content plan.
2. **Design** — wireframes, visual direction, hi-fi screens, prototype.
3. **Development** — front-end, integrations, CMS, QA.
4. **Launch & Handover** — deployment, training, post-launch support.

## 4. Deliverables

- Sitemap, user flows, wireframes
- Brand-aligned visual design system
- Fully responsive, performant website
- CMS / admin (if applicable)
- Launch + 30 days of support

## 5. Timeline

Estimated duration: {{duration_weeks}} weeks from kickoff. Detailed milestones provided in the Statement of Work.

## 6. Investment

Total project investment: ₹{{total_value}} (inclusive of design, development, project management; taxes extra as applicable).

Suggested payment schedule:
- 50% on signing
- 25% on design approval
- 25% on launch

## 7. Why ${STUDIO.name}

Premium digital craft, transparent process, senior team end-to-end. See work at ${STUDIO.site}.

## 8. Next Steps

To proceed: countersign the attached Service Agreement and remit the first invoice. We can kick off within 5 business days of signature.
`,
  },
  // ── Agreement ────────────────────────────────────────────────────────────
  {
    type: "service_agreement",
    category: "Agreement",
    emoji: "✍️",
    title: "Service Agreement / Master Contract",
    description: "Master document covering scope, payment terms, IP, confidentiality, and legal protections.",
    fields: COMMON_FIELDS,
    defaultBody: `# Master Service Agreement

This Master Service Agreement ("Agreement") is entered into on {{effective_date}} between ${STUDIO.name} ("Studio") and {{client_name}} ("Client").

## 1. Services
The Studio shall provide design, development, and related digital services as described in one or more Statements of Work ("SOW") executed by both Parties.

## 2. Fees & Payment
- All fees are payable in INR (Indian Rupees) unless otherwise agreed.
- Invoices are due within 7 days of issue unless stated otherwise on the SOW.
- Late payments accrue interest at 1.5% per month.
- Work is paused on accounts more than 14 days overdue.

## 3. Intellectual Property
- Upon receipt of full payment, all custom deliverables created specifically for the Client transfer to the Client.
- The Studio retains rights to its pre-existing tools, frameworks, and methodologies.
- The Studio may display non-confidential portions of the work in its portfolio and case studies.

## 4. Confidentiality
Each Party agrees to keep the other's Confidential Information secret, as defined in any executed NDA or in this Agreement.

## 5. Revisions & Change Requests
Each SOW specifies the number of included revision rounds. Additional changes are billed at the Studio's then-current hourly rate.

## 6. Client Responsibilities
The Client shall provide timely feedback, content, approvals, and access required for the Studio to perform the Services. Delays caused by the Client may shift the timeline accordingly.

## 7. Warranties & Liability
- The Studio warrants that the Services will be performed in a professional manner.
- The Studio's total liability under this Agreement shall not exceed the fees paid by the Client in the preceding three (3) months.
- Neither Party is liable for indirect, incidental, or consequential damages.

## 8. Termination
Either Party may terminate this Agreement with 14 days' written notice. The Client shall pay for all Services rendered up to the date of termination.

## 9. Governing Law
This Agreement is governed by the laws of ${STUDIO.jurisdiction}. Disputes shall be resolved in the courts of ${STUDIO.jurisdiction}.

## 10. Signatures

For ${STUDIO.name}: ____________________   Date: __________

For {{client_name}}: ____________________   Date: __________
`,
  },
  {
    type: "sow",
    category: "Agreement",
    emoji: "📋",
    title: "Statement of Work (SOW)",
    description: "Detailed breakdown of deliverables — pages, features, integrations, revisions, and out-of-scope items.",
    fields: [
      ...COMMON_FIELDS,
      { key: "total_value", label: "Total Value (₹)", placeholder: "2,50,000" },
      { key: "revisions", label: "Revision Rounds", placeholder: "2" },
    ],
    defaultBody: `# Statement of Work

# {{project_name}}

Reference SOW under the Master Service Agreement dated {{effective_date}} between ${STUDIO.name} and {{client_name}}.

## 1. Project Overview
[1–2 paragraph summary of what is being built and why]

## 2. In Scope

### Pages & Screens
- Home
- About
- Services / Products
- Contact
- [Add as needed]

### Features & Integrations
- CMS-managed content
- Contact form with email notifications
- Google Analytics 4
- Basic SEO (meta, sitemap, robots.txt)
- [Add as needed]

### Design
- 1 visual direction round
- Hi-fi designs for all in-scope pages
- Component library / design tokens

### Development
- Responsive (mobile, tablet, desktop)
- Cross-browser tested (latest 2 versions of Chrome, Safari, Firefox, Edge)
- Performance target: Lighthouse ≥ 90 on mobile

## 3. Out of Scope
The following are explicitly NOT included and would be quoted separately:
- Copywriting & content creation
- Photography & videography
- Translations
- Ongoing maintenance after the included support period
- Third-party paid plugins / subscriptions

## 4. Revisions
{{revisions}} rounds of revisions are included per major phase (design, development). Additional revisions billed at ₹2,500/hr.

## 5. Timeline
| Milestone | Target |
|---|---|
| Kickoff | Day 0 |
| Design approval | Week 3 |
| Development complete | Week 6 |
| QA & launch | Week 8 |

## 6. Investment
Total: ₹{{total_value}} (excluding GST). Payment per the master agreement.

## 7. Acceptance
Each phase is deemed accepted 5 business days after delivery if no written feedback is received.

For ${STUDIO.name}: ____________________

For {{client_name}}: ____________________
`,
  },
  {
    type: "quotation_invoice",
    category: "Agreement",
    emoji: "💰",
    title: "Quotation / Invoice (Reference)",
    description: "Use the dedicated Quotations and Invoices modules in admin for live PDFs. This is a reference template only.",
    fields: COMMON_FIELDS,
    defaultBody: `# Quotation / Invoice

Use the dedicated **Quotations** and **Invoices** modules in this admin for live, signed PDFs with Razorpay integration.

This document only exists as a reference for the agreed payment schedule.

## Agreed Payment Schedule for {{project_name}}

| # | Milestone | % | Due |
|---|---|---|---|
| 1 | On signing | 50% | {{effective_date}} |
| 2 | On design approval | 25% | TBD |
| 3 | On launch | 25% | TBD |

Currency: INR.
`,
  },
  // ── Kickoff ──────────────────────────────────────────────────────────────
  {
    type: "project_brief",
    category: "Kickoff",
    emoji: "🚀",
    title: "Project Brief",
    description: "Shared reference summarizing goals, stakeholders, timelines, and success metrics.",
    fields: COMMON_FIELDS,
    defaultBody: `# Project Brief

# {{project_name}}

Date: {{effective_date}}
Client: {{client_name}}
Studio: ${STUDIO.name}

## Goal
[Single-sentence north star for this project]

## Audience
[Primary user, what they need, where they encounter the product]

## Success Metrics
- ____________________
- ____________________
- ____________________

## Stakeholders
| Role | Name | Email |
|---|---|---|
| Client lead | {{client_name}} | {{client_email}} |
| Studio lead | [Name] | ${STUDIO.email} |

## Timeline Snapshot
- Kickoff: {{effective_date}}
- Design approval: TBD
- Launch: TBD

## Constraints & Risks
- ____________________

## Out of Scope
- ____________________
`,
  },
  {
    type: "brand_checklist",
    category: "Kickoff",
    emoji: "🎨",
    title: "Brand & Content Checklist",
    description: "List of assets the client must provide — logos, images, copy, credentials, domain access.",
    fields: COMMON_FIELDS,
    defaultBody: `# Brand & Content Checklist

# {{project_name}}

For: {{client_name}}
Please share the following so we can hit the ground running.

## Brand
- [ ] Logo files (SVG + PNG, primary + variants)
- [ ] Brand guidelines / style guide (PDF)
- [ ] Brand fonts (or licence info)
- [ ] Colour palette (hex / OKLCH)
- [ ] Photography / illustration assets

## Content
- [ ] Final copy for each page
- [ ] Image library (high-res, properly licensed)
- [ ] Video assets (if any)
- [ ] Testimonials & case studies
- [ ] Team bios & headshots

## Access & Credentials
- [ ] Domain registrar access
- [ ] Hosting / DNS access (if existing)
- [ ] Google Analytics / Search Console
- [ ] Social media accounts (if integrating)
- [ ] Email / newsletter platform
- [ ] Payment gateway credentials (if e-commerce)

## Legal
- [ ] Privacy policy (existing / required)
- [ ] Terms of service (existing / required)
- [ ] Cookie policy
- [ ] Any regulatory requirements (GDPR, DPDP, PCI, etc.)

Upload via the shared drive link we sent, or reply to ${STUDIO.email}.
`,
  },
  {
    type: "timeline",
    category: "Kickoff",
    emoji: "📅",
    title: "Project Timeline / Milestone Plan",
    description: "Dates for each deliverable, review cycles, and final launch.",
    fields: [
      ...COMMON_FIELDS,
      { key: "kickoff_date", label: "Kickoff Date", placeholder: "9 May 2026" },
      { key: "launch_date", label: "Target Launch", placeholder: "5 July 2026" },
    ],
    defaultBody: `# Timeline & Milestones

# {{project_name}}

Kickoff: {{kickoff_date}}
Target launch: {{launch_date}}

## Phase 1 — Discovery & Strategy (Week 1)
- Stakeholder interviews
- Competitor & content audit
- Sitemap & user flows
- **Deliverable:** Strategy document, sitemap

## Phase 2 — Design (Weeks 2–4)
- Visual direction round
- Wireframes
- Hi-fi designs
- Prototype
- **Deliverable:** Approved hi-fi designs

## Phase 3 — Development (Weeks 5–7)
- Front-end build
- CMS / integrations
- Internal QA
- **Deliverable:** Staging URL

## Phase 4 — QA, Launch & Handover (Week 8)
- Client QA round
- Performance & accessibility tuning
- Domain / DNS go-live
- Training & handover
- **Deliverable:** Live site + handover doc

## Review Cycles
Each phase includes one client review with 3 business days for feedback. Delays may shift downstream dates.
`,
  },
  // ── Legal ────────────────────────────────────────────────────────────────
  {
    type: "ip_assignment",
    category: "Legal",
    emoji: "©️",
    title: "Intellectual Property (IP) Assignment",
    description: "Clarifies that ownership of final deliverables transfers to the client upon full payment.",
    fields: COMMON_FIELDS,
    defaultBody: `# Intellectual Property Assignment

This IP Assignment ("Assignment") is made on {{effective_date}} between ${STUDIO.name} ("Assignor") and {{client_name}} ("Assignee") in connection with the project {{project_name}}.

## 1. Assignment
Subject to the receipt of full payment of all fees due under the related Service Agreement and Statement of Work, the Assignor hereby assigns to the Assignee, on a worldwide, perpetual, irrevocable, royalty-free basis, all right, title, and interest in and to the Final Deliverables created specifically for the Assignee.

## 2. Definition of Final Deliverables
"Final Deliverables" means the bespoke design files, source code, copy, and digital assets explicitly listed in the Statement of Work as deliverables for {{project_name}}.

## 3. Excluded Materials
The following are NOT assigned and remain the exclusive property of the Assignor or its licensors:
- Pre-existing tools, frameworks, libraries, and methodologies.
- Open-source or third-party components, governed by their respective licences.
- Unused concepts, drafts, and working files.

## 4. Portfolio Rights
The Assignor retains the right to display non-confidential portions of the Final Deliverables in its portfolio, case studies, and marketing materials.

## 5. Effective Date of Transfer
This Assignment is effective only upon receipt of full payment. Until such payment, the Assignor retains all IP rights.

## 6. Signatures

For ${STUDIO.name}: ____________________

For {{client_name}}: ____________________
`,
  },
  {
    type: "terms_privacy",
    category: "Legal",
    emoji: "🛡️",
    title: "Terms & Conditions + Privacy Policy",
    description: "Boilerplate T&Cs and Privacy Policy for the client's website. Customise per jurisdiction.",
    fields: [
      ...COMMON_FIELDS,
      { key: "site_url", label: "Client Site URL", placeholder: "https://client-site.com" },
    ],
    defaultBody: `# Terms & Conditions

These Terms & Conditions ("Terms") govern your use of {{site_url}} (the "Site") operated by {{client_name}} ("we", "us", "our").

## 1. Acceptance
By accessing or using the Site, you agree to be bound by these Terms.

## 2. Use of the Site
You agree to use the Site only for lawful purposes and not to misuse it in any way.

## 3. Intellectual Property
All content on the Site — text, graphics, logos, images — is the property of {{client_name}} or its licensors and is protected by applicable IP laws.

## 4. Limitation of Liability
The Site is provided "as is". To the maximum extent permitted by law, {{client_name}} disclaims all warranties and shall not be liable for any indirect or consequential damages.

## 5. Changes to These Terms
We may update these Terms from time to time. Continued use of the Site constitutes acceptance of the updated Terms.

## 6. Governing Law
These Terms are governed by the laws of ${STUDIO.jurisdiction}.

## 7. Contact
Questions? Email {{client_email}}.

---

# Privacy Policy

{{client_name}} ("we") respects your privacy. This Privacy Policy explains how we collect, use, and protect your personal information when you use site.

## 1. Information We Collect
- **Information you provide:** name, email, phone, and any other details you submit via forms.
- **Automatically collected:** IP address, browser type, device info, pages visited (via analytics).
- **Cookies:** small files used to remember preferences and measure usage.

## 2. How We Use Information
- To respond to enquiries and provide requested services.
- To improve the Site and our offerings.
- To send service updates and, with consent, marketing communications.
- To comply with legal obligations.

## 3. Sharing
We do not sell your personal information. We may share it with:
- Service providers acting on our behalf (e.g., hosting, email).
- Authorities when required by law.

## 4. Your Rights
Depending on your jurisdiction (GDPR, India DPDP, etc.) you may have the right to access, correct, delete, or port your data. Contact {{client_email}} to exercise these rights.

## 5. Security
We use reasonable technical and organisational measures to protect your data, but no method is 100% secure.

## 6. Retention
We retain personal information only as long as necessary for the purposes outlined or as required by law.

## 7. Changes to This Policy
We may update this Privacy Policy from time to time. The "Last updated" date will reflect the most recent revision.

## 8. Contact
Questions about this Privacy Policy? Email {{client_email}}.
`,
  },
];

export function getTemplate(type: DocType): DocTemplate | undefined {
  return DOC_TEMPLATES.find((t) => t.type === type);
}

/** Replace {{placeholders}} in body using metadata + client info. */
export function fillTemplate(body: string, metadata: Record<string, string>): string {
  return body.replace(/\{\{(\w+)\}\}/g, (_, key) => {
    const v = metadata[key];
    return v && v.trim() ? v : `{{${key}}}`;
  });
}
