// Convert a markdown-ish body (see documentTemplates.ts) into a downloadable .docx
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
  LevelFormat,
} from "docx";
import { fillTemplate } from "./documentTemplates";

const FONT = "Calibri";

function lineToParagraph(line: string): Paragraph {
  if (line.startsWith("# ")) {
    return new Paragraph({
      heading: HeadingLevel.HEADING_1,
      alignment: AlignmentType.CENTER,
      spacing: { before: 240, after: 160 },
      children: [new TextRun({ text: line.slice(2), bold: true, size: 36, font: FONT, color: "111111" })],
    });
  }
  if (line.startsWith("## ")) {
    return new Paragraph({
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 200, after: 100 },
      children: [new TextRun({ text: line.slice(3), bold: true, size: 26, font: FONT, color: "1a1a1a" })],
    });
  }
  if (line.startsWith("### ")) {
    return new Paragraph({
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 160, after: 80 },
      children: [new TextRun({ text: line.slice(4), bold: true, size: 22, font: FONT })],
    });
  }
  if (line.startsWith("- ") || line.startsWith("* ")) {
    return new Paragraph({
      numbering: { reference: "bullets", level: 0 },
      children: [new TextRun({ text: line.slice(2), size: 22, font: FONT })],
    });
  }
  if (line.startsWith("|")) {
    const cells = line.split("|").map((c) => c.trim()).filter((c) => c.length > 0);
    const isDivider = cells.every((c) => /^:?-+:?$/.test(c));
    if (isDivider) return new Paragraph({ children: [new TextRun({ text: "", size: 18 })] });
    return new Paragraph({
      spacing: { after: 60 },
      children: [new TextRun({ text: cells.join("    \u2003"), size: 22, font: FONT })],
    });
  }
  if (line === "---") {
    return new Paragraph({
      border: { bottom: { color: "CCCCCC", style: "single", size: 6, space: 1 } },
      spacing: { before: 160, after: 160 },
      children: [],
    });
  }
  if (line.startsWith("Date:")) {
    return new Paragraph({
      alignment: AlignmentType.RIGHT,
      spacing: { after: 120, line: 320 },
      children: [new TextRun({ text: line, size: 22, font: FONT })],
    });
  }
  return new Paragraph({
    spacing: { after: 120, line: 320 },
    children: [new TextRun({ text: line, size: 22, font: FONT })],
  });
}

const NUMBERING_CONFIG = {
  config: [{
    reference: "bullets",
    levels: [{
      level: 0,
      format: LevelFormat.BULLET,
      text: "\u2022",
      alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 720, hanging: 360 } } },
    }],
  }],
};

const PAGE_PROPS = {
  page: {
    size: { width: 12240, height: 15840 },
    margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 },
  },
};

function bodyToParagraphs(filled: string): Paragraph[] {
  const children: Paragraph[] = [];
  for (const raw of filled.split("\n")) {
    const line = raw.trimEnd();
    if (line === "") {
      children.push(new Paragraph({ children: [new TextRun({ text: "", size: 22, font: FONT })] }));
    } else {
      children.push(lineToParagraph(line));
    }
  }
  return children;
}

export async function downloadDocxFromBody(opts: {
  title: string;
  body: string;
  metadata: Record<string, string>;
  filename: string;
}) {
  const filled = fillTemplate(opts.body, opts.metadata);
  const doc = new Document({
    creator: "EAssets Studio",
    title: opts.title,
    numbering: NUMBERING_CONFIG,
    styles: { default: { document: { run: { font: FONT, size: 22 } } } },
    sections: [{ properties: PAGE_PROPS, children: bodyToParagraphs(filled) }],
  });

  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = opts.filename.endsWith(".docx") ? opts.filename : `${opts.filename}.docx`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/** Download all 11 documents as one .docx — page break between each. */
export async function downloadAllAsOneDocx(opts: {
  docs: { title: string; body: string }[];
  metadata: Record<string, string>;
  filename: string;
}) {
  const allChildren: Paragraph[] = [];

  opts.docs.forEach((d, i) => {
    if (i > 0) {
      // Insert a page-break paragraph before each doc after the first
      allChildren.push(
        new Paragraph({
          pageBreakBefore: true,
          children: [new TextRun({ text: "", size: 22, font: FONT })],
        })
      );
    }
    const filled = fillTemplate(d.body, opts.metadata);
    allChildren.push(...bodyToParagraphs(filled));
  });

  const doc = new Document({
    creator: "EAssets Studio",
    title: opts.filename,
    numbering: NUMBERING_CONFIG,
    styles: { default: { document: { run: { font: FONT, size: 22 } } } },
    sections: [{ properties: PAGE_PROPS, children: allChildren }],
  });

  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = opts.filename.endsWith(".docx") ? opts.filename : `${opts.filename}.docx`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
