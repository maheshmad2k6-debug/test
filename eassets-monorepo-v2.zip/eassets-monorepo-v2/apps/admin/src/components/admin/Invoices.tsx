import { useEffect, useState, useCallback, useRef } from "react";
import { supabase, type Client, type Invoice, type InvoiceItem } from "@/lib/supabase";
import { downloadInvoicePDF, buildInvoicePDF, pdfToBase64 } from "@/lib/pdfGenerator";
import { sendInvoiceEmail } from "@/lib/brevo";

// ─── Razorpay ─────────────────────────────────────────────────────────────────

declare global {
  interface Window {
    Razorpay: new (options: RazorpayOptions) => { open(): void };
  }
}

interface RazorpayOptions {
  key: string;
  amount: number;       // paise
  currency: string;
  name: string;
  description: string;
  order_id?: string;
  prefill?: { name?: string; email?: string };
  theme?: { color?: string };
  handler?: (response: { razorpay_payment_id: string }) => void;
}

/** Dynamically loads Razorpay checkout.js once, returns promise */
function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

/**
 * Razorpay Pay Now button.
 * Requires: razorpayKeyId (your rzp_live_/rzp_test_ key), amount in INR, invoice details.
 * Opens Razorpay hosted checkout modal directly — no backend order needed for basic flow.
 */
function RazorpayButton({
  keyId,
  amountINR,
  invoiceNumber,
  clientName,
  clientEmail,
}: {
  keyId: string;
  amountINR: number;
  invoiceNumber: string;
  clientName?: string;
  clientEmail?: string;
}) {
  const [loading, setLoading] = useState(false);
  const [paid, setPaid] = useState(false);

  async function handlePay() {
    if (!keyId.trim()) {
      alert("Razorpay Key ID is not set on this invoice. Edit the invoice and add your Key ID.");
      return;
    }
    setLoading(true);
    const ok = await loadRazorpayScript();
    setLoading(false);
    if (!ok) {
      alert("Failed to load Razorpay. Check your internet connection.");
      return;
    }
    const rzp = new window.Razorpay({
      key: keyId,
      amount: Math.round(amountINR * 100), // convert ₹ → paise
      currency: "INR",
      name: "EAssets Studio",
      description: `Invoice ${invoiceNumber}`,
      prefill: { name: clientName, email: clientEmail },
      theme: { color: "#ef4444" },
      handler(response) {
        setPaid(true);
        alert(`Payment successful! Payment ID: ${response.razorpay_payment_id}`);
      },
    });
    rzp.open();
  }

  if (paid) {
    return (
      <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-green-600/10 border border-green-500/30 text-green-600 text-sm font-medium">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
          <polyline points="20 6 9 17 4 12" />
        </svg>
        Payment received
      </div>
    );
  }

  return (
    <button
      onClick={handlePay}
      disabled={loading}
      className="flex items-center gap-2.5 px-5 py-2.5 rounded-xl font-semibold text-sm text-white transition-all disabled:opacity-60 disabled:cursor-not-allowed"
      style={{
        background: loading
          ? "#555"
          : "linear-gradient(135deg, #072654 0%, #1a6fd4 50%, #072654 100%)",
        boxShadow: loading ? "none" : "0 4px 18px rgba(26,111,212,0.35)",
      }}
    >
      {/* Razorpay "R" logo mark */}
      <svg width="18" height="18" viewBox="0 0 40 40" fill="none">
        <path d="M20 0C8.954 0 0 8.954 0 20s8.954 20 20 20 20-8.954 20-20S31.046 0 20 0z" fill="#072654"/>
        <path d="M14 10h8.5c2.485 0 4.5 2.015 4.5 4.5 0 1.8-1.06 3.36-2.6 4.1L28 30h-5l-3.2-10H18v10h-4V10z" fill="#3395FF"/>
        <path d="M18 14v6h3.5c1.38 0 2.5-1.12 2.5-2.5v-1c0-1.38-1.12-2.5-2.5-2.5H18z" fill="#fff"/>
      </svg>
      {loading ? "Loading…" : "Pay with Razorpay"}
    </button>
  );
}

/**
 * Razorpay Payment Button embed — accepts the full HTML snippet from
 * Razorpay dashboard ("<form><script src=...payment-button.js data-payment_button_id=..."></script></form>")
 * and injects it so the script executes (innerHTML alone doesn't run scripts).
 */
function RazorpayEmbed({ html }: { html: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const host = ref.current;
    if (!host || !html.trim()) return;
    host.innerHTML = "";
    const tpl = document.createElement("template");
    tpl.innerHTML = html.trim();
    const frag = tpl.content;
    frag.querySelectorAll("script").forEach((old) => {
      const s = document.createElement("script");
      for (const a of Array.from(old.attributes)) s.setAttribute(a.name, a.value);
      if (old.textContent) s.textContent = old.textContent;
      old.parentNode?.replaceChild(s, old);
    });
    host.appendChild(frag);
  }, [html]);
  return <div ref={ref} />;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmt(n: number, currency: "INR" | "USD" = "INR") {
  return currency === "INR"
    ? `₹${n.toLocaleString("en-IN", { minimumFractionDigits: 2 })}`
    : `$${n.toLocaleString("en-US", { minimumFractionDigits: 2 })}`;
}

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400",
  sent: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  paid: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
  overdue: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
};

const STATUS_FLOW: Invoice["status"][] = ["pending", "sent", "paid", "overdue"];

const TAX_RATE = 0.18;


function generateInvoiceNumber(existing: Invoice[]): string {
  const year = new Date().getFullYear();
  const nums = existing
    .map((inv) => {
      const m = inv.invoice_number?.match(/INV-\d{4}-(\d+)/);
      return m ? parseInt(m[1]) : 0;
    })
    .filter(Boolean);
  const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
  return `INV-${year}-${String(next).padStart(3, "0")}`;
}

// ─── Field ────────────────────────────────────────────────────────────────────

function Field({
  label, value, onChange, type = "text", placeholder,
}: {
  label: string; value: string | number; onChange: (v: string) => void;
  type?: string; placeholder?: string;
}) {
  return (
    <div>
      <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">{label}</label>
      <input
        type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
        className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
      />
    </div>
  );
}

// ─── Line Items Editor ────────────────────────────────────────────────────────

function LineItemsEditor({ items, currency, onChange }: {
  items: InvoiceItem[]; currency: "INR" | "USD"; onChange: (items: InvoiceItem[]) => void;
}) {
  function update(i: number, key: keyof InvoiceItem, val: string) {
    const next = items.map((item, idx) =>
      idx === i ? { ...item, [key]: key === "description" ? val : parseFloat(val) || 0 } : item
    );
    onChange(next);
  }

  function addRow() { onChange([...items, { description: "", quantity: 1, rate: 0 }]); }
  function removeRow(i: number) { onChange(items.filter((_, idx) => idx !== i)); }

  const subtotal = items.reduce((s, it) => s + it.quantity * it.rate, 0);

  return (
    <div className="space-y-3">
      <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground">Line Items</label>
      <div className="border border-border rounded-xl overflow-hidden">
        <div className="grid grid-cols-12 gap-2 px-4 py-2 bg-muted text-xs font-mono uppercase tracking-widest text-muted-foreground">
          <div className="col-span-6">Description</div>
          <div className="col-span-2 text-center">Qty</div>
          <div className="col-span-2 text-right">Rate</div>
          <div className="col-span-1 text-right">Amt</div>
          <div className="col-span-1" />
        </div>
        {items.map((item, i) => (
          <div key={i} className="grid grid-cols-12 gap-2 px-4 py-2 border-t border-border items-center">
            <div className="col-span-6">
              <input type="text" value={item.description} onChange={(e) => update(i, "description", e.target.value)}
                placeholder="Description"
                className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            <div className="col-span-2">
              <input type="number" value={item.quantity} onChange={(e) => update(i, "quantity", e.target.value)}
                min="1"
                className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-center focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            <div className="col-span-2">
              <input type="number" value={item.rate} onChange={(e) => update(i, "rate", e.target.value)}
                min="0"
                className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-right focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            <div className="col-span-1 text-right text-sm font-medium text-foreground">
              {fmt(item.quantity * item.rate, currency)}
            </div>
            <div className="col-span-1 flex justify-end">
              <button onClick={() => removeRow(i)}
                className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
          </div>
        ))}
        <div className="px-4 py-2 border-t border-border">
          <button onClick={addRow} className="text-xs text-primary hover:underline font-medium">+ Add line item</button>
        </div>
        <div className="flex justify-end gap-4 px-4 py-3 bg-muted border-t border-border">
          <span className="text-sm font-mono text-muted-foreground uppercase tracking-widest">Subtotal</span>
          <span className="text-sm font-bold text-foreground">{fmt(subtotal, currency)}</span>
        </div>
      </div>
    </div>
  );
}

// ─── Invoice Form ─────────────────────────────────────────────────────────────

interface InvoiceFormProps {
  initial?: Partial<Invoice>;
  clients: Client[];
  invoiceNumber: string;
  onSave: (data: Omit<Invoice, "id" | "created_at">) => void;
  onCancel: () => void;
}

function InvoiceForm({ initial = {}, clients, invoiceNumber, onSave, onCancel }: InvoiceFormProps) {
  const [clientId, setClientId] = useState(initial.client_id ?? "");
  const [clientName, setClientName] = useState(initial.client_name ?? "");
  const [clientEmail, setClientEmail] = useState(initial.client_email ?? "");
  const [items, setItems] = useState<InvoiceItem[]>(initial.items ?? [{ description: "", quantity: 1, rate: 0 }]);
  const [taxEnabled, setTaxEnabled] = useState(initial.tax_enabled ?? false);
  const [currency] = useState<"INR" | "USD">("INR");
  const [upiId, setUpiId] = useState(initial.upi_id ?? "");
  const [razorpayLink, setRazorpayLink] = useState(initial.razorpay_link ?? "");
  const [razorpayKeyId, setRazorpayKeyId] = useState(initial.razorpay_key_id ?? "");
  const [razorpayButtonHtml, setRazorpayButtonHtml] = useState(initial.razorpay_button_html ?? "");
  const [paymentTerms, setPaymentTerms] = useState(initial.payment_terms ?? "");
  const [notes, setNotes] = useState(initial.notes ?? "");
  const [status, setStatus] = useState<Invoice["status"]>(initial.status ?? "pending");

  const subtotal = items.reduce((s, it) => s + it.quantity * it.rate, 0);
  const taxAmount = taxEnabled ? subtotal * TAX_RATE : 0;
  const total = subtotal + taxAmount;

  function handleClientChange(id: string) {
    setClientId(id);
    if (id) {
      const c = clients.find((c) => c.id === id);
      setClientName(c?.name ?? "");
      setClientEmail(c?.email ?? "");
    }
  }

  function handleSave() {
    onSave({
      invoice_number: initial.invoice_number ?? invoiceNumber,
      client_id: clientId || undefined,
      client_name: clientName || undefined,
      client_email: clientEmail || undefined,
      items, subtotal, tax_enabled: taxEnabled,
      tax_amount: taxAmount, total, currency,
      upi_id: upiId || undefined,
      razorpay_link: razorpayLink || undefined,
      razorpay_key_id: razorpayKeyId || undefined,
      razorpay_button_html: razorpayButtonHtml || undefined,
      payment_terms: paymentTerms || undefined,
      notes: notes || undefined,
      status,
    });
  }

  return (
    <div className="space-y-6">
      {/* Invoice number */}
      <div className="flex items-center gap-3 p-3 bg-primary/5 border border-primary/20 rounded-xl">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-primary shrink-0">
          <path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2" /><rect x="9" y="3" width="6" height="4" rx="1" />
        </svg>
        <span className="text-sm text-muted-foreground">Invoice Number:</span>
        <span className="font-mono font-bold text-primary">{initial.invoice_number ?? invoiceNumber}</span>
      </div>

      {/* Client */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Link to Client</label>
          <select value={clientId} onChange={(e) => handleClientChange(e.target.value)}
            className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary">
            <option value="">— Select client —</option>
            {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <Field label="Or Enter Name Manually" value={clientName} onChange={setClientName} placeholder="Client / company name" />
      </div>

      {/* Client email */}
      <Field label="Client Email (for sending invoice)" value={clientEmail} onChange={setClientEmail} type="email" placeholder="client@example.com" />

      {/* Status */}
      <div>
        <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Status</label>
        <div className="flex gap-2 flex-wrap">
          {STATUS_FLOW.map((s) => (
            <button key={s} onClick={() => setStatus(s)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold capitalize border transition-all ${status === s ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:border-primary"}`}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Line items */}
      <LineItemsEditor items={items} currency={currency} onChange={setItems} />

      {/* Tax toggle */}
      <div className="flex items-center justify-between p-4 bg-muted/50 border border-border rounded-xl">
        <div>
          <div className="text-sm font-medium text-foreground">GST (18%)</div>
          <div className="text-xs text-muted-foreground">Apply 18% Goods & Services Tax</div>
        </div>
        <button onClick={() => setTaxEnabled(!taxEnabled)}
          className={`relative w-12 h-6 rounded-full transition-colors ${taxEnabled ? "bg-primary" : "bg-muted-foreground/30"}`}>
          <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${taxEnabled ? "translate-x-6" : "translate-x-0.5"}`} />
        </button>
      </div>

      {/* Totals summary */}
      <div className="bg-card border border-border rounded-xl p-4 space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Subtotal</span>
          <span className="font-medium">{fmt(subtotal, currency)}</span>
        </div>
        {taxEnabled && (
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">GST (18%)</span>
            <span className="font-medium">{fmt(taxAmount, currency)}</span>
          </div>
        )}
        <div className="flex justify-between text-base font-bold border-t border-border pt-2 mt-2">
          <span>Total</span>
          <span className="text-primary">{fmt(total, currency)}</span>
        </div>
      </div>

      {/* Payment details */}
      <div className="space-y-3">
        <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground">Payment Details</label>
        <div className="grid grid-cols-2 gap-4">
          <Field label="UPI ID" value={upiId} onChange={setUpiId} placeholder="yourname@bank" />
          <Field label="Razorpay Payment Link (optional)" value={razorpayLink} onChange={setRazorpayLink} placeholder="https://rzp.io/..." />
        </div>
        {/* Razorpay checkout integration */}
        <div className="p-4 border border-border rounded-xl bg-muted/30 space-y-3">
          <div className="flex items-center gap-2">
            {/* Razorpay logo */}
            <svg width="20" height="20" viewBox="0 0 40 40" fill="none">
              <path d="M20 0C8.954 0 0 8.954 0 20s8.954 20 20 20 20-8.954 20-20S31.046 0 20 0z" fill="#072654"/>
              <path d="M14 10h8.5c2.485 0 4.5 2.015 4.5 4.5 0 1.8-1.06 3.36-2.6 4.1L28 30h-5l-3.2-10H18v10h-4V10z" fill="#3395FF"/>
              <path d="M18 14v6h3.5c1.38 0 2.5-1.12 2.5-2.5v-1c0-1.38-1.12-2.5-2.5-2.5H18z" fill="#fff"/>
            </svg>
            <span className="text-sm font-semibold text-foreground">Razorpay Checkout</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-500 border border-blue-500/20 font-mono uppercase">Embedded</span>
          </div>
          <Field
            label="Razorpay Key ID (rzp_live_… or rzp_test_…)"
            value={razorpayKeyId}
            onChange={setRazorpayKeyId}
            placeholder="rzp_test_XXXXXXXXXXXXXXXX"
          />
          <p className="text-[11px] text-muted-foreground">
            Stored on invoice only. The Pay button in the preview will open Razorpay checkout modal using this key.
          </p>
          {razorpayKeyId && currency === "INR" && (
            <div className="flex items-center gap-3">
              <span className="text-xs text-muted-foreground">Preview button:</span>
              <RazorpayButton
                keyId={razorpayKeyId}
                amountINR={total}
                invoiceNumber={initial.invoice_number ?? invoiceNumber}
                clientName={clientName}
                clientEmail={clientEmail}
              />
            </div>
          )}
          {/* Razorpay Payment Button — paste raw HTML snippet from Razorpay dashboard */}
          <div className="pt-3 border-t border-border space-y-2">
            <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground">
              Razorpay Payment Button HTML (optional)
            </label>
            <textarea
              value={razorpayButtonHtml}
              onChange={(e) => setRazorpayButtonHtml(e.target.value)}
              rows={4}
              placeholder='<form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_XXXXXXXX" async></script></form>'
              className="w-full bg-background border border-border rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-primary resize-none"
            />
            <p className="text-[11px] text-muted-foreground">
              Paste the full HTML snippet from your Razorpay dashboard → Payment Button. It will render and execute live in the invoice preview.
            </p>
            {razorpayButtonHtml.trim() && (
              <div className="p-3 rounded-lg border border-border bg-background">
                <p className="text-[10px] font-mono uppercase text-muted-foreground mb-2">Preview</p>
                <RazorpayEmbed html={razorpayButtonHtml} />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Terms & Notes */}
      <div className="grid grid-cols-2 gap-4">
        <Field label="Payment Terms" value={paymentTerms} onChange={setPaymentTerms} placeholder="e.g. Net 30" />
        <div>
          <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Notes</label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3}
            className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary resize-none" />
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3 justify-end pt-2">
        <button onClick={onCancel}
          className="px-5 py-2.5 rounded-xl text-sm font-medium border border-border text-muted-foreground hover:bg-muted transition-colors">
          Cancel
        </button>
        <button onClick={handleSave} disabled={!clientName && !clientId}
          className="px-5 py-2.5 rounded-xl text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
          Save Invoice
        </button>
      </div>
    </div>
  );
}

// ─── Invoice Preview ──────────────────────────────────────────────────────────

function InvoicePreview({ inv }: { inv: Invoice }) {
  const date = new Date(inv.created_at).toLocaleDateString("en-IN", {
    year: "numeric", month: "long", day: "numeric",
  });

  return (
    <div className="bg-white text-gray-900 rounded-xl p-8 border border-border shadow-sm text-sm font-sans">
      {/* Header */}
      <div className="flex justify-between items-start mb-8 pb-6 border-b-2 border-red-500">
        <div>
          <div className="text-2xl font-bold text-red-500">eassets<span className="text-gray-900">.studio</span></div>
          <div className="text-xs text-gray-400 mt-1">hreassets@gmail.com</div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-gray-900">INVOICE</div>
          <div className="text-xs text-gray-400 mt-1">{inv.invoice_number}</div>
          <div className="text-xs text-gray-400">Date: {date}</div>
          {inv.payment_terms && <div className="text-xs text-gray-400">Terms: {inv.payment_terms}</div>}
        </div>
      </div>
      {/* Client */}
      <div className="mb-6">
        <div className="text-[10px] uppercase tracking-widest text-gray-400 mb-1">Bill to</div>
        <div className="font-semibold">{inv.client_name || "Client"}</div>
      </div>
      {/* Items */}
      <table className="w-full mb-6 text-sm">
        <thead>
          <tr className="bg-gray-900 text-white">
            <th className="text-left px-3 py-2 rounded-tl">Description</th>
            <th className="text-center px-3 py-2 w-16">Qty</th>
            <th className="text-right px-3 py-2 w-28">Rate</th>
            <th className="text-right px-3 py-2 rounded-tr w-28">Amount</th>
          </tr>
        </thead>
        <tbody>
          {inv.items.map((it, i) => (
            <tr key={i} className={i % 2 === 1 ? "bg-gray-50" : ""}>
              <td className="px-3 py-2">{it.description}</td>
              <td className="px-3 py-2 text-center">{it.quantity}</td>
              <td className="px-3 py-2 text-right">{fmt(it.rate, inv.currency)}</td>
              <td className="px-3 py-2 text-right">{fmt(it.quantity * it.rate, inv.currency)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* Totals */}
      <div className="flex justify-end mb-6">
        <div className="w-64 space-y-1">
          <div className="flex justify-between text-sm">
            <span>Subtotal</span><span>{fmt(inv.subtotal, inv.currency)}</span>
          </div>
          {inv.tax_enabled && (
            <div className="flex justify-between text-sm text-gray-500">
              <span>GST (18%)</span><span>{fmt(inv.tax_amount, inv.currency)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-base border-t-2 border-gray-900 pt-2 mt-1">
            <span>Total</span><span>{fmt(inv.total, inv.currency)}</span>
          </div>
        </div>
      </div>
      {/* Payment details */}
      {(inv.upi_id || inv.razorpay_link || inv.razorpay_key_id || inv.razorpay_button_html) && (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4">
          <div className="text-[10px] uppercase tracking-widest text-gray-400 mb-2">Payment Details</div>
          {inv.upi_id && <div className="text-sm">UPI ID: <strong>{inv.upi_id}</strong></div>}
          {inv.razorpay_link && <div className="text-sm mt-1 text-blue-600 break-all">{inv.razorpay_link}</div>}
          {inv.razorpay_key_id && inv.currency === "INR" && (
            <div className="mt-3 pt-3 border-t border-gray-200">
              <RazorpayButton
                keyId={inv.razorpay_key_id!}
                amountINR={inv.total}
                invoiceNumber={inv.invoice_number}
                clientName={inv.client_name}
                clientEmail={inv.client_email}
              />
            </div>
          )}
          {inv.razorpay_button_html && (
            <div className="mt-3 pt-3 border-t border-gray-200">
              <RazorpayEmbed html={inv.razorpay_button_html} />
            </div>
          )}
        </div>
      )}
      {/* Notes */}
      {inv.notes && (
        <div className="mb-4">
          <div className="text-[10px] uppercase tracking-widest text-gray-400 mb-1">Notes</div>
          <div className="text-sm text-gray-700">{inv.notes}</div>
        </div>
      )}
      <div className="mt-8 pt-4 border-t border-gray-200 text-[11px] text-gray-400 text-center">
        Thank you for your business!<br />
        <a href="https://eassets-studio.vercel.app" target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">eassets-studio.vercel.app</a><br />
        <span className="text-[10px]">This is an electronically generated invoice &amp; does not require a physical signature.</span>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export function Invoices() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Invoice | null>(null);
  const [previewing, setPreviewing] = useState<Invoice | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [sendingEmail, setSendingEmail] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: inv }, { data: c }] = await Promise.all([
      supabase.from("invoices").select("*").order("created_at", { ascending: false }),
      supabase.from("clients").select("*").order("name"),
    ]);
    setInvoices(inv ?? []);
    setClients(c ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  // Real-time subscription
  useEffect(() => {
    const sub = supabase
      .channel("invoices-channel")
      .on("postgres_changes", { event: "*", schema: "public", table: "invoices" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(sub); };
  }, [load]);

  async function handleSave(data: Omit<Invoice, "id" | "created_at">) {
    setSaving(true);
    if (editing) {
      await supabase.from("invoices").update(data).eq("id", editing.id);
    } else {
      await supabase.from("invoices").insert([data]);
    }
    setSaving(false);
    setShowForm(false);
    setEditing(null);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this invoice?")) return;
    setDeleting(id);
    await supabase.from("invoices").delete().eq("id", id);
    setDeleting(null);
    load();
  }

  async function handleSendEmail(inv: Invoice) {
    if (!inv.client_email) {
      alert("No client email found on this invoice. Please edit the invoice and add a client email first.");
      return;
    }
    if (!confirm(`Send invoice ${inv.invoice_number} to ${inv.client_email}?`)) return;
    setSendingEmail(inv.id);
    try {
      const pdfBase64 = pdfToBase64(buildInvoicePDF(inv));
      await sendInvoiceEmail({
        clientEmail: inv.client_email,
        clientName: inv.client_name ?? "Client",
        invoiceNumber: inv.invoice_number,
        total: `₹${inv.total.toLocaleString("en-IN", { minimumFractionDigits: 2 })}`,
        currency: "INR",
        pdfBase64,
      });
      // Update status to "sent" automatically
      await supabase.from("invoices").update({ status: "sent" }).eq("id", inv.id);
      load();
      alert(`Invoice sent to ${inv.client_email} successfully!`);
    } catch (e) {
      alert(`Failed to send email: ${(e as Error).message}`);
    } finally {
      setSendingEmail(null);
    }
  }

  async function cycleStatus(inv: Invoice) {
    const next = STATUS_FLOW[(STATUS_FLOW.indexOf(inv.status) + 1) % STATUS_FLOW.length];
    await supabase.from("invoices").update({ status: next }).eq("id", inv.id);
    load();
  }

  if (loading) {
    return <div className="flex items-center justify-center h-48 text-muted-foreground text-sm">Loading invoices…</div>;
  }

  if (previewing) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <button onClick={() => setPreviewing(null)}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" />
            </svg>
            Back
          </button>
        <div className="flex items-center gap-2">
          <button onClick={() => downloadInvoicePDF(previewing)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            Download PDF
          </button>
          <button
            onClick={() => handleSendEmail(previewing)}
            disabled={sendingEmail === previewing.id}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-60"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
            </svg>
            {sendingEmail === previewing.id ? "Sending…" : "Send to Client"}
          </button>
        </div>
        </div>
        <InvoicePreview inv={previewing} />
      </div>
    );
  }

  if (showForm || editing) {
    return (
      <div className="space-y-6">
        <h2 className="text-lg font-bold text-foreground">{editing ? "Edit Invoice" : "New Invoice"}</h2>
        <div className="bg-card border border-border rounded-2xl p-6">
          <InvoiceForm
            initial={editing ?? {}}
            clients={clients}
            invoiceNumber={generateInvoiceNumber(invoices)}
            onSave={handleSave}
            onCancel={() => { setShowForm(false); setEditing(null); }}
          />
          {saving && <p className="text-xs text-muted-foreground mt-3">Saving…</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-foreground">Invoices</h2>
          <p className="text-sm text-muted-foreground">{invoices.length} total</p>
        </div>
        <button onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
          </svg>
          New Invoice
        </button>
      </div>

      {/* List */}
      {invoices.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-center">
          <div className="text-4xl mb-3">🧾</div>
          <p className="text-muted-foreground text-sm">No invoices yet. Create your first one!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {invoices.map((inv) => {
            const date = new Date(inv.created_at).toLocaleDateString("en-IN", {
              year: "numeric", month: "short", day: "numeric",
            });
            return (
              <div key={inv.id}
                className="bg-card border border-border rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center gap-4">
                {/* Left */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="font-mono text-xs text-primary font-bold">{inv.invoice_number}</span>
                    <span className="font-semibold text-foreground truncate">{inv.client_name || "Unknown Client"}</span>
                    <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide ${STATUS_COLORS[inv.status]}`}>
                      {inv.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 mt-1 flex-wrap">
                    <span className="text-xs text-muted-foreground">{date}</span>
                    <span className="text-sm font-bold text-foreground">{fmt(inv.total, inv.currency)}</span>
                    {inv.tax_enabled && <span className="text-xs text-muted-foreground">incl. GST</span>}
                    <span className="text-xs text-muted-foreground">{inv.currency}</span>
                    {inv.upi_id && <span className="text-xs text-muted-foreground">UPI</span>}
                    {inv.razorpay_link && <span className="text-xs text-muted-foreground">Razorpay</span>}
                  </div>
                </div>
                {/* Actions */}
                <div className="flex items-center gap-2 flex-wrap">
                  <button onClick={() => cycleStatus(inv)}
                    className="px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary transition-colors">
                    {STATUS_FLOW[(STATUS_FLOW.indexOf(inv.status) + 1) % STATUS_FLOW.length]} →
                  </button>
                  <button
                    onClick={() => handleSendEmail(inv)}
                    disabled={sendingEmail === inv.id}
                    title="Send to client via email"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-blue-500/40 text-xs font-medium text-blue-500 hover:bg-blue-500/10 transition-colors disabled:opacity-50"
                  >
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
                    </svg>
                    {sendingEmail === inv.id ? "Sending…" : "Send Email"}
                  </button>
                  <button onClick={() => setPreviewing(inv)}
                    className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors" title="Preview">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
                    </svg>
                  </button>
                  <button onClick={() => downloadInvoicePDF(inv)}
                    className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors" title="Download PDF">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
                    </svg>
                  </button>
                  <button onClick={() => setEditing(inv)}
                    className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors" title="Edit">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                    </svg>
                  </button>
                  <button onClick={() => handleDelete(inv.id)} disabled={deleting === inv.id}
                    className="p-2 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors" title="Delete">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" /><path d="M10 11v6" /><path d="M14 11v6" /><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                    </svg>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
