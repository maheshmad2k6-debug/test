import { useEffect, useRef, useState } from "react";
import { supabase, type Client, type Quotation, type QuotationItem } from "@/lib/supabase";
import { downloadQuotationPDF, buildQuotationPDF, pdfToBase64 } from "@/lib/pdfGenerator";
import { sendQuotationEmail } from "@/lib/brevo";

/** Inject a Razorpay Payment Button (or any) HTML snippet so its <script> actually executes. */
function RazorpayEmbed({ html }: { html: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const host = ref.current;
    if (!host || !html.trim()) return;
    host.innerHTML = "";
    const tpl = document.createElement("template");
    tpl.innerHTML = html.trim();
    const frag = tpl.content;
    frag.querySelectorAll("script").forEach((old) => {
      const s = document.createElement("script");
      for (const a of Array.from(old.attributes)) s.setAttribute(a.name, a.value);
      if (old.textContent) s.textContent = old.textContent;
      old.parentNode?.replaceChild(s, old);
    });
    host.appendChild(frag);
  }, [html]);
  return <div ref={ref} />;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmt(n: number) {
  return `₹${n.toLocaleString("en-IN", { minimumFractionDigits: 2 })}`;
}

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  sent: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  accepted: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
  rejected: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
};

const STATUS_FLOW: Quotation["status"][] = ["draft", "sent", "accepted", "rejected"];

// ─── Field ────────────────────────────────────────────────────────────────────

function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
}: {
  label: string;
  value: string | number;
  onChange: (v: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
      />
    </div>
  );
}

// ─── Line Items Editor ────────────────────────────────────────────────────────

function LineItemsEditor({
  items,
  onChange,
}: {
  items: QuotationItem[];
  onChange: (items: QuotationItem[]) => void;
}) {
  function update(i: number, key: keyof QuotationItem, val: string) {
    const next = items.map((item, idx) =>
      idx === i
        ? { ...item, [key]: key === "description" ? val : parseFloat(val) || 0 }
        : item
    );
    onChange(next);
  }

  function addRow() {
    onChange([...items, { description: "", quantity: 1, rate: 0 }]);
  }

  function removeRow(i: number) {
    onChange(items.filter((_, idx) => idx !== i));
  }

  const total = items.reduce((s, it) => s + it.quantity * it.rate, 0);

  return (
    <div className="space-y-3">
      <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground">
        Line Items
      </label>
      <div className="border border-border rounded-xl overflow-hidden">
        {/* Header */}
        <div className="grid grid-cols-12 gap-2 px-4 py-2 bg-muted text-xs font-mono uppercase tracking-widest text-muted-foreground">
          <div className="col-span-6">Description</div>
          <div className="col-span-2 text-center">Qty</div>
          <div className="col-span-2 text-right">Rate (₹)</div>
          <div className="col-span-1 text-right">Amt</div>
          <div className="col-span-1" />
        </div>
        {/* Rows */}
        {items.map((item, i) => (
          <div
            key={i}
            className="grid grid-cols-12 gap-2 px-4 py-2 border-t border-border items-center"
          >
            <div className="col-span-6">
              <input
                type="text"
                value={item.description}
                onChange={(e) => update(i, "description", e.target.value)}
                placeholder="Description"
                className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <div className="col-span-2">
              <input
                type="number"
                value={item.quantity}
                onChange={(e) => update(i, "quantity", e.target.value)}
                min="1"
                className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-center focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <div className="col-span-2">
              <input
                type="number"
                value={item.rate}
                onChange={(e) => update(i, "rate", e.target.value)}
                min="0"
                className="w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-right focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <div className="col-span-1 text-right text-sm font-medium text-foreground">
              {fmt(item.quantity * item.rate)}
            </div>
            <div className="col-span-1 flex justify-end">
              <button
                onClick={() => removeRow(i)}
                className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
          </div>
        ))}
        {/* Add row */}
        <div className="px-4 py-2 border-t border-border">
          <button
            onClick={addRow}
            className="text-xs text-primary hover:underline font-medium"
          >
            + Add line item
          </button>
        </div>
        {/* Total */}
        <div className="flex justify-end gap-4 px-4 py-3 bg-muted border-t border-border">
          <span className="text-sm font-mono text-muted-foreground uppercase tracking-widest">Total</span>
          <span className="text-sm font-bold text-foreground">{fmt(total)}</span>
        </div>
      </div>
    </div>
  );
}

// ─── Quotation Form ───────────────────────────────────────────────────────────

interface QuotationFormProps {
  initial?: Partial<Quotation>;
  clients: Client[];
  onSave: (data: Omit<Quotation, "id" | "created_at">) => void;
  onCancel: () => void;
}

function QuotationForm({ initial = {}, clients, onSave, onCancel }: QuotationFormProps) {
  const [clientId, setClientId] = useState(initial.client_id ?? "");
  const [clientName, setClientName] = useState(initial.client_name ?? "");
  const [clientEmail, setClientEmail] = useState(initial.client_email ?? "");
  const [items, setItems] = useState<QuotationItem[]>(
    initial.items ?? [{ description: "", quantity: 1, rate: 0 }]
  );
  const [status, setStatus] = useState<Quotation["status"]>(initial.status ?? "draft");
  const [notes, setNotes] = useState(initial.notes ?? "");
  const [paymentTerms, setPaymentTerms] = useState(initial.payment_terms ?? "");
  const [razorpayButtonHtml, setRazorpayButtonHtml] = useState(initial.razorpay_button_html ?? "");

  const total = items.reduce((s, it) => s + it.quantity * it.rate, 0);

  function handleClientChange(id: string) {
    setClientId(id);
    if (id) {
      const c = clients.find((c) => c.id === id);
      setClientName(c?.name ?? "");
      setClientEmail(c?.email ?? "");
    }
  }

  function handleSave() {
    onSave({
      client_id: clientId || undefined,
      client_name: clientName || undefined,
      client_email: clientEmail || undefined,
      items, total, status,
      notes: notes || undefined,
      payment_terms: paymentTerms || undefined,
      razorpay_button_html: razorpayButtonHtml || undefined,
    });
  }

  return (
    <div className="space-y-6">
      {/* Client */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
            Link to Client
          </label>
          <select
            value={clientId}
            onChange={(e) => handleClientChange(e.target.value)}
            className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
          >
            <option value="">— Select client —</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <Field
          label="Or Enter Name Manually"
          value={clientName}
          onChange={setClientName}
          placeholder="Client / company name"
        />
      </div>

      {/* Client email */}
      <Field
        label="Client Email (for sending quotation)"
        value={clientEmail}
        onChange={setClientEmail}
        type="email"
        placeholder="client@example.com"
      />

      {/* Status */}
      <div>
        <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Status</label>
        <div className="flex gap-2 flex-wrap">
          {STATUS_FLOW.map((s) => (
            <button
              key={s}
              onClick={() => setStatus(s)}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold capitalize transition-all border ${
                status === s
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border text-muted-foreground hover:border-primary hover:text-primary"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Line items */}
      <LineItemsEditor items={items} onChange={setItems} />

      {/* Terms & Notes */}
      <div className="grid grid-cols-2 gap-4">
        <Field label="Payment Terms" value={paymentTerms} onChange={setPaymentTerms} placeholder="e.g. 50% advance" />
        <div>
          <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Notes</label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3}
            className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary resize-none" />
        </div>
      </div>

      {/* Razorpay Payment Button HTML */}
      <div className="space-y-2">
        <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground">
          Razorpay Payment Button HTML (optional)
        </label>
        <textarea
          value={razorpayButtonHtml}
          onChange={(e) => setRazorpayButtonHtml(e.target.value)}
          rows={4}
          placeholder='<form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_XXXXXXXX" async></script></form>'
          className="w-full bg-background border border-border rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-primary resize-none"
        />
        {razorpayButtonHtml.trim() && (
          <div className="p-3 rounded-lg border border-border bg-background">
            <p className="text-[10px] font-mono uppercase text-muted-foreground mb-2">Preview</p>
            <RazorpayEmbed html={razorpayButtonHtml} />
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex gap-3 justify-end pt-2">
        <button
          onClick={onCancel}
          className="px-5 py-2.5 rounded-xl text-sm font-medium border border-border text-muted-foreground hover:bg-muted transition-colors"
        >
          Cancel
        </button>
        <button
          onClick={handleSave}
          disabled={!clientName && !clientId}
          className="px-5 py-2.5 rounded-xl text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Save Quotation
        </button>
      </div>
    </div>
  );
}

// ─── Quotation Preview ────────────────────────────────────────────────────────

function QuotationPreview({ q }: { q: Quotation }) {
  const total = q.items.reduce((s, it) => s + it.quantity * it.rate, 0);
  const date = new Date(q.created_at).toLocaleDateString("en-IN", {
    year: "numeric", month: "long", day: "numeric",
  });

  return (
    <div className="bg-white text-gray-900 rounded-xl p-8 border border-border shadow-sm text-sm font-sans">
      {/* Header */}
      <div className="flex justify-between items-start mb-8 pb-6 border-b-2 border-red-500">
        <div>
          <div className="text-2xl font-bold text-red-500">
            eassets<span className="text-gray-900">.studio</span>
          </div>
          <div className="text-xs text-gray-400 mt-1">hreassets@gmail.com</div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-gray-900">QUOTATION</div>
          <div className="text-xs text-gray-400 mt-1">ID: {q.id.slice(0, 8).toUpperCase()}</div>
          <div className="text-xs text-gray-400">Date: {date}</div>
        </div>
      </div>
      {/* Client */}
      <div className="mb-6">
        <div className="text-[10px] uppercase tracking-widest text-gray-400 mb-1">Prepared for</div>
        <div className="font-semibold">{q.client_name || "Client"}</div>
      </div>
      {/* Items table */}
      <table className="w-full mb-6 text-sm">
        <thead>
          <tr className="bg-gray-900 text-white">
            <th className="text-left px-3 py-2 rounded-tl">Description</th>
            <th className="text-center px-3 py-2 w-16">Qty</th>
            <th className="text-right px-3 py-2 w-28">Rate</th>
            <th className="text-right px-3 py-2 rounded-tr w-28">Amount</th>
          </tr>
        </thead>
        <tbody>
          {q.items.map((it, i) => (
            <tr key={i} className={i % 2 === 1 ? "bg-gray-50" : ""}>
              <td className="px-3 py-2">{it.description}</td>
              <td className="px-3 py-2 text-center">{it.quantity}</td>
              <td className="px-3 py-2 text-right">{fmt(it.rate)}</td>
              <td className="px-3 py-2 text-right">{fmt(it.quantity * it.rate)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* Total */}
      <div className="flex justify-end">
        <div className="w-56">
          <div className="flex justify-between border-t-2 border-gray-900 pt-3 mt-2 font-bold text-base">
            <span>Total</span>
            <span>{fmt(total)}</span>
          </div>
        </div>
      </div>
      {/* Payment / Notes */}
      {(q.payment_terms || q.notes || q.razorpay_button_html) && (
        <div className="mt-6 bg-gray-50 border border-gray-200 rounded-lg p-4 space-y-2">
          {q.payment_terms && (
            <div className="text-sm"><span className="text-gray-400 text-[10px] uppercase tracking-widest mr-2">Terms</span>{q.payment_terms}</div>
          )}
          {q.notes && (
            <div className="text-sm"><span className="text-gray-400 text-[10px] uppercase tracking-widest mr-2">Notes</span>{q.notes}</div>
          )}
          {q.razorpay_button_html && (
            <div className="pt-3 border-t border-gray-200">
              <RazorpayEmbed html={q.razorpay_button_html} />
            </div>
          )}
        </div>
      )}
      {/* Footer */}
      <div className="mt-10 pt-4 border-t border-gray-200 text-[11px] text-gray-400 text-center">
        This quotation is valid for 30 days from the date of issue.<br />
        <a href="https://eassets-studio.vercel.app" target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">eassets-studio.vercel.app</a><br />
        <span className="text-[10px]">This is an electronically generated quotation &amp; does not require a physical signature.</span>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export function Quotations() {
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Quotation | null>(null);
  const [previewing, setPreviewing] = useState<Quotation | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [sendingEmail, setSendingEmail] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    const [{ data: q }, { data: c }] = await Promise.all([
      supabase.from("quotations").select("*").order("created_at", { ascending: false }),
      supabase.from("clients").select("*").order("name"),
    ]);
    setQuotations(q ?? []);
    setClients(c ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleSave(data: Omit<Quotation, "id" | "created_at">) {
    setSaving(true);
    if (editing) {
      await supabase.from("quotations").update(data).eq("id", editing.id);
    } else {
      await supabase.from("quotations").insert([data]);
    }
    setSaving(false);
    setShowForm(false);
    setEditing(null);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this quotation?")) return;
    setDeleting(id);
    await supabase.from("quotations").delete().eq("id", id);
    setDeleting(null);
    load();
  }

  async function handleSendEmail(q: Quotation) {
    if (!q.client_email) {
      alert("No client email found on this quotation. Please edit it and add a client email first.");
      return;
    }
    if (!confirm(`Send quotation to ${q.client_email}?`)) return;
    setSendingEmail(q.id);
    try {
      const pdfBase64 = pdfToBase64(buildQuotationPDF(q));
      await sendQuotationEmail({
        clientEmail: q.client_email,
        clientName: q.client_name ?? "Client",
        quotationId: q.id.slice(0, 8).toUpperCase(),
        total: `₹${q.total.toLocaleString("en-IN", { minimumFractionDigits: 2 })}`,
        pdfBase64,
      });
      await supabase.from("quotations").update({ status: "sent" }).eq("id", q.id);
      load();
      alert(`Quotation sent to ${q.client_email} successfully!`);
    } catch (e) {
      alert(`Failed to send email: ${(e as Error).message}`);
    } finally {
      setSendingEmail(null);
    }
  }

  async function cycleStatus(q: Quotation) {
    const next = STATUS_FLOW[(STATUS_FLOW.indexOf(q.status) + 1) % STATUS_FLOW.length];
    await supabase.from("quotations").update({ status: next }).eq("id", q.id);
    load();
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48 text-muted-foreground text-sm">
        Loading quotations…
      </div>
    );
  }

  // If previewing
  if (previewing) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setPreviewing(null)}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" />
            </svg>
            Back
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={() => downloadQuotationPDF(previewing)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
              </svg>
              Download PDF
            </button>
            <button
              onClick={() => handleSendEmail(previewing)}
              disabled={sendingEmail === previewing.id}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-60"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
              </svg>
              {sendingEmail === previewing.id ? "Sending…" : "Send to Client"}
            </button>
          </div>
        </div>
        <QuotationPreview q={previewing} />
      </div>
    );
  }

  // If form open
  if (showForm || editing) {
    return (
      <div className="space-y-6">
        <h2 className="text-lg font-bold text-foreground">
          {editing ? "Edit Quotation" : "New Quotation"}
        </h2>
        <div className="bg-card border border-border rounded-2xl p-6">
          <QuotationForm
            initial={editing ?? {}}
            clients={clients}
            onSave={handleSave}
            onCancel={() => { setShowForm(false); setEditing(null); }}
          />
          {saving && <p className="text-xs text-muted-foreground mt-3">Saving…</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-foreground">Quotations</h2>
          <p className="text-sm text-muted-foreground">{quotations.length} total</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
          </svg>
          New Quotation
        </button>
      </div>

      {/* List */}
      {quotations.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-center">
          <div className="text-4xl mb-3">📄</div>
          <p className="text-muted-foreground text-sm">No quotations yet. Create your first one!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {quotations.map((q) => {
            const date = new Date(q.created_at).toLocaleDateString("en-IN", {
              year: "numeric", month: "short", day: "numeric",
            });
            return (
              <div
                key={q.id}
                className="bg-card border border-border rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center gap-4"
              >
                {/* Left */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="font-semibold text-foreground truncate">
                      {q.client_name || "Unknown Client"}
                    </span>
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide ${STATUS_COLORS[q.status]}`}
                    >
                      {q.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 mt-1">
                    <span className="text-xs text-muted-foreground">{date}</span>
                    <span className="text-sm font-bold text-foreground">{fmt(q.total)}</span>
                    <span className="text-xs text-muted-foreground">{q.items.length} item{q.items.length !== 1 ? "s" : ""}</span>
                  </div>
                </div>
                {/* Actions */}
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() => cycleStatus(q)}
                    title="Cycle status"
                    className="px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary transition-colors"
                  >
                    {STATUS_FLOW[(STATUS_FLOW.indexOf(q.status) + 1) % STATUS_FLOW.length]} →
                  </button>
                  <button
                    onClick={() => handleSendEmail(q)}
                    disabled={sendingEmail === q.id}
                    title="Send to client via email"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-blue-500/40 text-xs font-medium text-blue-500 hover:bg-blue-500/10 transition-colors disabled:opacity-50"
                  >
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
                    </svg>
                    {sendingEmail === q.id ? "Sending…" : "Send Email"}
                  </button>
                  <button
                    onClick={() => setPreviewing(q)}
                    className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                    title="Preview"
                  >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
                    </svg>
                  </button>
                  <button
                    onClick={() => downloadQuotationPDF(q)}
                    className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                    title="Download PDF"
                  >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
                    </svg>
                  </button>
                  <button
                    onClick={() => setEditing(q)}
                    className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                    title="Edit"
                  >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                    </svg>
                  </button>
                  <button
                    onClick={() => handleDelete(q.id)}
                    disabled={deleting === q.id}
                    className="p-2 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                    title="Delete"
                  >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" /><path d="M10 11v6" /><path d="M14 11v6" /><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                    </svg>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
