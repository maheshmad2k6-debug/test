import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/lib/supabase";

interface Stats {
  clients: number;
  messages: number;
  quotations: number;
  invoices: number;
  receivedPayments: number;
  pendingPayments: number;
  paidCount: number;
  pendingCount: number;
}

const initial: Stats = {
  clients: 0,
  messages: 0,
  quotations: 0,
  invoices: 0,
  receivedPayments: 0,
  pendingPayments: 0,
  paidCount: 0,
  pendingCount: 0,
};

function fmt(n: number) {
  return `₹${n.toLocaleString("en-IN", { minimumFractionDigits: 0 })}`;
}

export function Dashboard() {
  const [stats, setStats] = useState<Stats>(initial);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const [
        { count: clients },
        { count: messages },
        { count: quotations },
        { count: invoices },
        { data: paidInvoices },
        { data: pendingInvoices },
        { data: paidPayments },
        { data: pendingPaymentsData },
      ] = await Promise.all([
        supabase.from("clients").select("*", { count: "exact", head: true }),
        supabase.from("messages").select("*", { count: "exact", head: true }),
        supabase.from("quotations").select("*", { count: "exact", head: true }),
        supabase.from("invoices").select("*", { count: "exact", head: true }),
        supabase.from("invoices").select("total").eq("status", "paid"),
        supabase.from("invoices").select("total").in("status", ["pending", "overdue", "sent"]),
        supabase.from("payments").select("amount").eq("status", "paid"),
        supabase.from("payments").select("amount").in("status", ["pending", "overdue"]),
      ]);

      const receivedFromInvoices = (paidInvoices ?? []).reduce(
        (s: number, inv: { total: number }) => s + (inv.total ?? 0), 0
      );
      const receivedFromPayments = (paidPayments ?? []).reduce(
        (s: number, p: { amount: number }) => s + (p.amount ?? 0), 0
      );
      const receivedPayments = receivedFromInvoices + receivedFromPayments;

      const pendingFromInvoices = (pendingInvoices ?? []).reduce(
        (s: number, inv: { total: number }) => s + (inv.total ?? 0), 0
      );
      const pendingFromPayments = (pendingPaymentsData ?? []).reduce(
        (s: number, p: { amount: number }) => s + (p.amount ?? 0), 0
      );
      const pendingPayments = pendingFromInvoices + pendingFromPayments;

      setStats({
        clients: clients ?? 0,
        messages: messages ?? 0,
        quotations: quotations ?? 0,
        invoices: invoices ?? 0,
        receivedPayments,
        pendingPayments,
        paidCount: (paidInvoices ?? []).length,
        pendingCount: (pendingInvoices ?? []).length,
      });
    } catch (e) {
      setError("Failed to load stats. Check Supabase tables & RLS.");
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Real-time: reload whenever any relevant table changes
  useEffect(() => {
    const channels = [
      supabase
        .channel("dashboard-invoices")
        .on("postgres_changes", { event: "*", schema: "public", table: "invoices" }, load)
        .subscribe(),
      supabase
        .channel("dashboard-payments")
        .on("postgres_changes", { event: "*", schema: "public", table: "payments" }, load)
        .subscribe(),
      supabase
        .channel("dashboard-quotations")
        .on("postgres_changes", { event: "*", schema: "public", table: "quotations" }, load)
        .subscribe(),
      supabase
        .channel("dashboard-clients")
        .on("postgres_changes", { event: "*", schema: "public", table: "clients" }, load)
        .subscribe(),
      supabase
        .channel("dashboard-messages")
        .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, load)
        .subscribe(),
    ];
    return () => { channels.forEach((c) => supabase.removeChannel(c)); };
  }, [load]);

  const Skeleton = () => <div className="h-8 w-20 bg-muted rounded animate-pulse" />;

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">Live overview of your studio</p>
      </div>

      {error && (
        <div className="mb-6 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-sm text-destructive">
          {error}
        </div>
      )}

      {/* Primary financial cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
                Total Received
              </div>
              <div className="text-3xl font-bold text-green-600">
                {loading ? <Skeleton /> : fmt(stats.receivedPayments)}
              </div>
              {!loading && (
                <div className="text-xs text-muted-foreground mt-1">
                  {stats.paidCount} paid invoice{stats.paidCount !== 1 ? "s" : ""}
                </div>
              )}
            </div>
            <div className="h-12 w-12 rounded-xl bg-green-500/10 text-green-500 flex items-center justify-center text-2xl">
              💰
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
                Pending / Overdue
              </div>
              <div className="text-3xl font-bold text-red-500">
                {loading ? <Skeleton /> : fmt(stats.pendingPayments)}
              </div>
              {!loading && (
                <div className="text-xs text-muted-foreground mt-1">
                  {stats.pendingCount} unpaid invoice{stats.pendingCount !== 1 ? "s" : ""}
                </div>
              )}
            </div>
            <div className="h-12 w-12 rounded-xl bg-red-500/10 text-red-500 flex items-center justify-center text-2xl">
              ⏳
            </div>
          </div>
        </div>
      </div>

      {/* Secondary stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Clients", value: stats.clients, icon: "👥", color: "bg-blue-500/10 text-blue-500" },
          { label: "Quotations", value: stats.quotations, icon: "📄", color: "bg-teal-500/10 text-teal-500" },
          { label: "Invoices", value: stats.invoices, icon: "🧾", color: "bg-purple-500/10 text-purple-500" },
          { label: "Messages", value: stats.messages, icon: "💬", color: "bg-indigo-500/10 text-indigo-500" },
        ].map((c) => (
          <div key={c.label} className="bg-card border border-border rounded-2xl p-5">
            <div className={`inline-flex h-10 w-10 items-center justify-center rounded-xl text-xl ${c.color} mb-3`}>
              {c.icon}
            </div>
            <div className="text-3xl font-bold text-foreground">
              {loading ? <Skeleton /> : c.value}
            </div>
            <div className="text-xs text-muted-foreground mt-1 font-medium">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="mt-8 p-5 bg-card border border-border rounded-2xl">
        <h2 className="font-semibold text-foreground mb-1">Quick actions</h2>
        <p className="text-sm text-muted-foreground">
          Use the sidebar to navigate to Clients, Messages, Quotations, Invoices, and Payments.
        </p>
      </div>
    </div>
  );
}
