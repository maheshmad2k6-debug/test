import { useEffect, useState, useCallback } from "react";
import { supabase, type Payment, type Invoice } from "@/lib/supabase";
import { generateInvoicePDF } from "@/lib/pdfUtils";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmt(n: number) {
  return `₹${n.toLocaleString("en-IN", { minimumFractionDigits: 2 })}`;
}

const CATEGORY_COLORS: string[] = [
  "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-400",
  "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400",
  "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400",
  "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400",
  "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
];

// ─── Payment Detail Modal ─────────────────────────────────────────────────────

function PaymentModal({ payment, invoice, onClose }: {
  payment: Payment; invoice?: Invoice; onClose: () => void;
}) {
  const date = new Date(payment.created_at).toLocaleDateString("en-IN", {
    year: "numeric", month: "long", day: "numeric",
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div>
            <h3 className="font-bold text-foreground">Payment Details</h3>
            <p className="text-xs text-muted-foreground mt-0.5">{date}</p>
          </div>
          <button onClick={onClose}
            className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-5 space-y-4">
          {/* Amount */}
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600">{fmt(payment.amount)}</div>
            <div className="text-xs text-muted-foreground mt-1 uppercase tracking-widest">Amount Received</div>
          </div>

          {/* Details */}
          <div className="space-y-3 text-sm">
            {payment.type && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Category</span>
                <span className="font-medium">{payment.type}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-muted-foreground">Status</span>
              <span className="inline-flex items-center gap-1.5 text-green-600 font-medium">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
                Paid
              </span>
            </div>
            {payment.invoice_id && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Invoice ID</span>
                <span className="font-mono text-xs">{payment.invoice_id.slice(0, 8).toUpperCase()}</span>
              </div>
            )}
            {invoice && (
              <>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Invoice #</span>
                  <span className="font-mono font-bold text-primary">{invoice.invoice_number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Client</span>
                  <span className="font-medium">{invoice.client_name}</span>
                </div>
              </>
            )}
          </div>

          {/* Download invoice PDF */}
          {invoice && (
            <button onClick={() => generateInvoicePDF(invoice)}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors mt-2">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
              </svg>
              Download Invoice PDF
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export function ReceivedPayments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [invoicesMap, setInvoicesMap] = useState<Record<string, Invoice>>({});
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: allPayments }, { data: allInvoices }] = await Promise.all([
      supabase.from("payments").select("*").eq("status", "paid").order("created_at", { ascending: false }),
      supabase.from("invoices").select("*"),
    ]);

    const paid = allPayments ?? [];
    setPayments(paid);

    const inv: Record<string, Invoice> = {};
    for (const invoice of allInvoices ?? []) {
      inv[invoice.id] = invoice;
    }
    setInvoicesMap(inv);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  // Real-time subscription
  useEffect(() => {
    const sub = supabase
      .channel("payments-received-channel")
      .on("postgres_changes", { event: "*", schema: "public", table: "payments" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(sub); };
  }, [load]);

  // ─ Derived data ───────────────────────────────────────────────────────────

  const categories = Array.from(new Set(payments.map((p) => p.type ?? "Uncategorized")));

  const categoryColorMap = Object.fromEntries(
    categories.map((cat, i) => [cat, CATEGORY_COLORS[i % CATEGORY_COLORS.length]])
  );

  const grouped: Record<string, Payment[]> = {};
  for (const p of payments) {
    const key = p.type ?? "Uncategorized";
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(p);
  }

  const categoryTotals: Record<string, number> = {};
  for (const [cat, pmts] of Object.entries(grouped)) {
    categoryTotals[cat] = pmts.reduce((s, p) => s + p.amount, 0);
  }

  const filtered = selectedCategory
    ? payments.filter((p) => (p.type ?? "Uncategorized") === selectedCategory)
    : payments;

  const totalReceived = payments.reduce((s, p) => s + p.amount, 0);

  if (loading) {
    return <div className="flex items-center justify-center h-48 text-muted-foreground text-sm">Loading payments…</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-foreground">Received Payments</h2>
        <p className="text-sm text-muted-foreground">Only paid transactions</p>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">Total Received</div>
          <div className="text-2xl font-bold text-green-600">{fmt(totalReceived)}</div>
        </div>
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">Payments</div>
          <div className="text-2xl font-bold text-foreground">{payments.length}</div>
        </div>
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">Categories</div>
          <div className="text-2xl font-bold text-foreground">{categories.length}</div>
        </div>
      </div>

      {/* Category filter chips */}
      {categories.length > 0 && (
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedCategory(null)}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold border transition-all ${
              selectedCategory === null
                ? "bg-primary text-primary-foreground border-primary"
                : "border-border text-muted-foreground hover:border-primary"
            }`}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(selectedCategory === cat ? null : cat)}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                selectedCategory === cat
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border text-muted-foreground hover:border-primary"
              }`}
            >
              {cat} · {fmt(categoryTotals[cat])}
            </button>
          ))}
        </div>
      )}

      {/* Grouped list */}
      {payments.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-center">
          <div className="text-4xl mb-3">💰</div>
          <p className="text-muted-foreground text-sm">No received payments yet.</p>
        </div>
      ) : selectedCategory ? (
        // Flat list for filtered category
        <div className="space-y-3">
          {filtered.map((p) => {
            const date = new Date(p.created_at).toLocaleDateString("en-IN", {
              year: "numeric", month: "short", day: "numeric",
            });
            const invoice = p.invoice_id ? invoicesMap[p.invoice_id] : undefined;
            return (
              <button
                key={p.id}
                onClick={() => setSelectedPayment(p)}
                className="w-full bg-card border border-border rounded-2xl p-4 flex items-center gap-4 hover:border-primary/50 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-full bg-green-100 text-green-600 flex items-center justify-center shrink-0">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    {invoice && <span className="font-mono text-xs text-primary font-bold">{invoice.invoice_number}</span>}
                    {invoice?.client_name && <span className="text-sm font-medium text-foreground">{invoice.client_name}</span>}
                    {p.type && (
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold ${categoryColorMap[p.type ?? "Uncategorized"]}`}>
                        {p.type}
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">{date}</div>
                </div>
                <div className="text-sm font-bold text-green-600">{fmt(p.amount)}</div>
              </button>
            );
          })}
        </div>
      ) : (
        // Grouped by category
        <div className="space-y-6">
          {Object.entries(grouped).map(([cat, pmts]) => (
            <div key={cat}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${categoryColorMap[cat]}`}>
                    {cat}
                  </span>
                  <span className="text-xs text-muted-foreground">{pmts.length} payment{pmts.length !== 1 ? "s" : ""}</span>
                </div>
                <span className="text-sm font-bold text-foreground">{fmt(categoryTotals[cat])}</span>
              </div>
              <div className="space-y-2">
                {pmts.map((p) => {
                  const date = new Date(p.created_at).toLocaleDateString("en-IN", {
                    year: "numeric", month: "short", day: "numeric",
                  });
                  const invoice = p.invoice_id ? invoicesMap[p.invoice_id] : undefined;
                  return (
                    <button
                      key={p.id}
                      onClick={() => setSelectedPayment(p)}
                      className="w-full bg-card border border-border rounded-xl p-4 flex items-center gap-4 hover:border-primary/50 transition-colors text-left"
                    >
                      <div className="w-8 h-8 rounded-full bg-green-100 text-green-600 flex items-center justify-center shrink-0">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <polyline points="20 6 9 17 4 12" />
                        </svg>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          {invoice && <span className="font-mono text-xs text-primary font-bold">{invoice.invoice_number}</span>}
                          {invoice?.client_name && <span className="text-sm font-medium text-foreground truncate">{invoice.client_name}</span>}
                        </div>
                        <div className="text-xs text-muted-foreground mt-0.5">{date}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-green-600">{fmt(p.amount)}</span>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-muted-foreground">
                          <polyline points="9 18 15 12 9 6" />
                        </svg>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Detail modal */}
      {selectedPayment && (
        <PaymentModal
          payment={selectedPayment}
          invoice={selectedPayment.invoice_id ? invoicesMap[selectedPayment.invoice_id] : undefined}
          onClose={() => setSelectedPayment(null)}
        />
      )}
    </div>
  );
}
