import { useState } from "react";
import { Dashboard } from "./Dashboard";
import { Clients } from "./Clients";
import { Messages } from "./Messages";
import { Bookings } from "./Bookings";
import { Quotations } from "./Quotations";
import { Invoices } from "./Invoices";
import { ReceivedPayments } from "./ReceivedPayments";
import { Projects } from "./Projects";
import { Inquiries } from "./Inquiries";
import { Documents } from "./Documents";
import { PortalManager } from "./PortalManager";
import { useRealtimeNotifications } from "@/hooks/useRealtimeNotifications";

type Tab = "dashboard" | "clients" | "portal" | "projects" | "inquiries" | "messages" | "bookings" | "documents" | "quotations" | "invoices" | "payments";

const NAV: { id: Tab; label: string; icon: React.ReactNode; comingSoon?: boolean }[] = [
  {
    id: "dashboard",
    label: "Dashboard",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>,
  },
  {
    id: "clients",
    label: "Clients",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
  },
  {
    id: "portal",
    label: "Portal",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>,
  },
  {
    id: "projects",
    label: "Projects",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>,
  },
  {
    id: "inquiries",
    label: "Enquiries",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>,
  },
  {
    id: "messages",
    label: "Messages",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
  },
  {
    id: "bookings",
    label: "Bookings",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
    comingSoon: false,
  },
  {
    id: "documents",
    label: "Documents",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
  },
  {
    id: "quotations",
    label: "Quotations",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>,
  },
  {
    id: "invoices",
    label: "Invoices",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="16" x2="12" y2="16"/></svg>,
  },
  {
    id: "payments",
    label: "Payments",
    icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>,
  },
];

function ComingSoon({ label }: { label: string }) {
  return (
    <div className="flex flex-col items-center justify-center h-64 text-center">
      <div className="text-4xl mb-4">🚧</div>
      <h2 className="text-xl font-bold text-foreground">{label}</h2>
      <p className="text-sm text-muted-foreground mt-2">Coming in the next session. Stay tuned!</p>
    </div>
  );
}

export function AdminLayout() {
  const [tab, setTab] = useState<Tab>("dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [desktopCollapsed, setDesktopCollapsed] = useState(false);

  // Push/toast notifications for everything happening across the system
  useRealtimeNotifications({ global: true });

  function logout() {
    sessionStorage.removeItem("admin_auth");
    window.location.reload();
  }

  const active = NAV.find((n) => n.id === tab)!;

  return (
    <div className="min-h-screen bg-background flex">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-20 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed lg:sticky top-0 h-screen bg-card border-r border-border flex flex-col z-30
          transition-all duration-200
          ${mobileOpen ? "translate-x-0" : "-translate-x-full"}
          lg:translate-x-0
          ${desktopCollapsed ? "lg:w-[60px]" : "lg:w-64"}
          w-64
        `}
      >
        {/* Brand + desktop collapse toggle */}
        <div className={`border-b border-border flex items-center gap-2 ${desktopCollapsed ? "px-3 py-4 justify-center" : "px-5 py-5"}`}>
          {!desktopCollapsed && (
            <div className="flex-1 min-w-0">
              <div className="font-bold text-lg text-foreground">
                eassets<span className="text-primary">.studio</span>
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">Admin Panel</div>
            </div>
          )}
          {/* Desktop collapse button */}
          <button
            onClick={() => setDesktopCollapsed((c) => !c)}
            className="hidden lg:flex items-center justify-center w-7 h-7 rounded-lg hover:bg-muted text-muted-foreground transition-colors flex-shrink-0"
            title={desktopCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {desktopCollapsed ? (
                <polyline points="9 18 15 12 9 6" />
              ) : (
                <polyline points="15 18 9 12 15 6" />
              )}
            </svg>
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto p-2 space-y-0.5">
          {NAV.map((item) => (
            <button
              key={item.id}
              onClick={() => { setTab(item.id); setMobileOpen(false); }}
              title={desktopCollapsed ? item.label : undefined}
              className={`w-full flex items-center gap-3 rounded-xl text-sm font-medium transition-colors
                ${desktopCollapsed ? "px-0 py-2.5 justify-center" : "px-3 py-2.5"}
                ${tab === item.id
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
            >
              <span className="flex-shrink-0">{item.icon}</span>
              {!desktopCollapsed && (
                <>
                  <span className="flex-1 text-left">{item.label}</span>
                  {item.comingSoon && (
                    <span className="ml-auto text-[10px] bg-muted text-muted-foreground px-1.5 py-0.5 rounded-full">Soon</span>
                  )}
                </>
              )}
            </button>
          ))}
        </nav>

        {/* Logout */}
        <div className={`border-t border-border ${desktopCollapsed ? "p-2" : "p-3"}`}>
          <button
            onClick={logout}
            title={desktopCollapsed ? "Log out" : undefined}
            className={`w-full flex items-center gap-3 rounded-xl text-sm font-medium text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors
              ${desktopCollapsed ? "px-0 py-2.5 justify-center" : "px-3 py-2.5"}`}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            {!desktopCollapsed && <span>Log out</span>}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur border-b border-border px-6 py-4 flex items-center gap-4">
          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileOpen(true)}
            className="lg:hidden p-2 rounded-lg hover:bg-muted text-muted-foreground"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>
            </svg>
          </button>
          <span className="text-sm font-medium text-foreground">{active.label}</span>
          <a href="/" className="ml-auto text-xs text-muted-foreground hover:text-foreground transition-colors">
            ← View site
          </a>
        </header>

        {/* Page content */}
        <main className="flex-1 p-6 overflow-y-auto">
          {tab === "dashboard" && <Dashboard />}
          {tab === "clients" && <Clients />}
          {tab === "portal" && <PortalManager />}
          {tab === "projects" && <Projects />}
          {tab === "inquiries" && <Inquiries />}
          {tab === "messages" && <Messages />}
          {tab === "bookings" && <Bookings />}
          {tab === "documents" && <Documents />}
          {tab === "quotations" && <Quotations />}
          {tab === "invoices" && <Invoices />}
          {tab === "payments" && <ReceivedPayments />}
        </main>
      </div>
    </div>
  );
}
