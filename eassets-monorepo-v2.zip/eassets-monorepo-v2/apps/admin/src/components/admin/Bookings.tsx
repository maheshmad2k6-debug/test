import { useEffect, useState } from "react";
import { supabase, type Booking } from "@/lib/supabase";
import { sendBookingConfirmationEmail } from "@/lib/brevo";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400",
  confirmed: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
  cancelled: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
};

const STATUS_FLOW: Booking["status"][] = ["pending", "confirmed", "cancelled"];

export function Bookings() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Booking | null>(null);
  const [filter, setFilter] = useState<"all" | Booking["status"]>("all");
  const [confirmingId, setConfirmingId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("bookings")
      .select("*")
      .order("created_at", { ascending: false });
    setBookings(data ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function cycleStatus(b: Booking) {
    const next = STATUS_FLOW[(STATUS_FLOW.indexOf(b.status) + 1) % STATUS_FLOW.length];
    await supabase.from("bookings").update({ status: next }).eq("id", b.id);

    // If this is a discovery call being confirmed, send the confirmation email to the client
    if (next === "confirmed" && b.time_slot) {
      setConfirmingId(b.id);
      try {
        const date = b.date
          ? new Date(b.date + "T00:00:00").toLocaleDateString("en-IN", {
              weekday: "long", day: "numeric", month: "long", year: "numeric",
            })
          : "";
        await sendBookingConfirmationEmail({
          name: b.name,
          email: b.email,
          date,
          time: b.time_slot,
        });
      } catch (e) {
        console.error("Failed to send confirmation email:", e);
      } finally {
        setConfirmingId(null);
      }
    }

    load();
    if (selected?.id === b.id) setSelected({ ...b, status: next });
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this booking?")) return;
    await supabase.from("bookings").delete().eq("id", id);
    if (selected?.id === id) setSelected(null);
    load();
  }

  const filtered = filter === "all" ? bookings : bookings.filter(b => b.status === filter);

  const counts = {
    all: bookings.length,
    pending: bookings.filter(b => b.status === "pending").length,
    confirmed: bookings.filter(b => b.status === "confirmed").length,
    cancelled: bookings.filter(b => b.status === "cancelled").length,
  };

  if (loading) {
    return <div className="flex items-center justify-center h-48 text-muted-foreground text-sm">Loading bookings…</div>;
  }

  return (
    <div className="flex h-[calc(100vh-140px)] gap-4">
      {/* ── Left list ── */}
      <div className="w-80 flex-shrink-0 flex flex-col">
        <div className="mb-4">
          <h1 className="text-xl font-bold text-foreground">Bookings</h1>
          <p className="text-xs text-muted-foreground mt-0.5">{bookings.length} total</p>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-1 mb-3 bg-muted p-1 rounded-xl">
          {(["all", "pending", "confirmed", "cancelled"] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`flex-1 text-[10px] font-mono uppercase tracking-wider py-1.5 rounded-lg transition-colors ${
                filter === f ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {f} {counts[f] > 0 && <span className="opacity-60">({counts[f]})</span>}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-center">
              <div className="text-3xl mb-2">📅</div>
              <p className="text-sm text-muted-foreground">No {filter === "all" ? "" : filter} bookings</p>
            </div>
          ) : (
            filtered.map((b) => {
              const isCall = !!b.time_slot;
              const date = b.date
                ? new Date(b.date + "T00:00:00").toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
                : "—";
              return (
                <button
                  key={b.id}
                  onClick={() => setSelected(b)}
                  className={`w-full text-left p-3 rounded-xl border transition-all ${
                    selected?.id === b.id
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/40 bg-card"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold text-sm text-foreground truncate">{b.name}</p>
                      <p className="text-xs text-muted-foreground truncate mt-0.5">{b.email}</p>
                    </div>
                    <span className={`flex-shrink-0 px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${STATUS_COLORS[b.status]}`}>
                      {b.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${isCall ? "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400" : "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"}`}>
                      {isCall ? "📅 Call" : "📄 Quote"}
                    </span>
                    {isCall && <span className="text-xs text-muted-foreground">{date}</span>}
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* ── Right detail ── */}
      <div className="flex-1 min-w-0">
        {!selected ? (
          <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
            <div className="text-4xl mb-3">📅</div>
            <p className="text-sm">Select a booking to view details</p>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-2xl h-full flex flex-col overflow-hidden">
            {/* Header */}
            <div className="p-6 border-b border-border flex items-start justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-foreground">{selected.name}</h2>
                <p className="text-sm text-muted-foreground mt-0.5">{selected.email}</p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => cycleStatus(selected)}
                  disabled={confirmingId === selected.id}
                  className="px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  {confirmingId === selected.id
                    ? "Sending confirmation…"
                    : `Mark ${STATUS_FLOW[(STATUS_FLOW.indexOf(selected.status) + 1) % STATUS_FLOW.length]} →`}
                </button>
                <button
                  onClick={() => handleDelete(selected.id)}
                  className="p-2 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                  title="Delete"
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
                  </svg>
                </button>
              </div>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {/* Type & status */}
              <div className="flex gap-2 flex-wrap">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold uppercase ${STATUS_COLORS[selected.status]}`}>
                  {selected.status}
                </span>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  selected.time_slot
                    ? "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400"
                    : "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
                }`}>
                  {selected.time_slot ? "Discovery Call" : "Quote Request"}
                </span>
              </div>

              {/* Approval notice for pending discovery calls */}
              {selected.status === "pending" && selected.time_slot && (
                <div className="flex items-start gap-3 bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-yellow-500 flex-shrink-0 mt-0.5">
                    <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
                  </svg>
                  <div>
                    <p className="text-xs font-semibold text-yellow-600 dark:text-yellow-400">Waiting for Approval</p>
                    <p className="text-xs text-yellow-600/80 dark:text-yellow-400/80 mt-0.5">
                      Client is awaiting your approval. Clicking <strong>"Mark confirmed"</strong> will send them a confirmation email.
                    </p>
                  </div>
                </div>
              )}

              {/* Details grid */}
              <div className="grid grid-cols-2 gap-3">
                {selected.phone && (
                  <DetailCell label="Phone" value={selected.phone} />
                )}
                {selected.date && (
                  <DetailCell
                    label="Date"
                    value={new Date(selected.date + "T00:00:00").toLocaleDateString("en-IN", {
                      weekday: "long", day: "numeric", month: "long", year: "numeric",
                    })}
                  />
                )}
                {selected.time_slot && (
                  <DetailCell label="Time (IST)" value={selected.time_slot} />
                )}
                <DetailCell
                  label="Received"
                  value={new Date(selected.created_at).toLocaleDateString("en-IN", {
                    day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
                  })}
                />
              </div>

              {/* Message / requirements */}
              {selected.message && (
                <div className="bg-muted/50 rounded-xl p-4">
                  <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Requirements</p>
                  <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">{selected.message}</p>
                </div>
              )}

              {/* Quick reply */}
              <a
                href={`mailto:${selected.email}?subject=${encodeURIComponent(
                  selected.time_slot
                    ? `Re: Your discovery call booking`
                    : `Re: Your quote request`
                )}`}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
                </svg>
                Reply to {selected.name.split(" ")[0]}
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function DetailCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-muted/50 rounded-xl p-3">
      <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-1">{label}</p>
      <p className="text-sm font-medium text-foreground">{value}</p>
    </div>
  );
}
