import { useState, useEffect, useCallback } from "react";
import { supabase, type Client } from "@/lib/supabase";

interface PortalUser {
  id: string;
  user_id: string;
  password_hash: string;
  client_id: string;
  client_name: string;
  client_email: string;
  company?: string;
  is_active: boolean;
  created_at: string;
  last_login?: string;
}

function generateUserId(name: string, index: number): string {
  const year = new Date().getFullYear();
  const initials = name
    .split(" ")
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("")
    .slice(0, 3)
    .padEnd(3, "X");
  const num = String(index).padStart(3, "0");
  return `${initials}-${year}-${num}`;
}

function generatePassword(length = 10): string {
  const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789!@#$";
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text).catch(() => {
    const el = document.createElement("textarea");
    el.value = text;
    document.body.appendChild(el);
    el.select();
    document.execCommand("copy");
    document.body.removeChild(el);
  });
}

// ─── Credential Card ──────────────────────────────────────────────────────────

function CredentialCard({ user, onToggle, onDelete, onCopy }: {
  user: PortalUser;
  onToggle: (id: string, active: boolean) => void;
  onDelete: (id: string) => void;
  onCopy: (user: PortalUser) => void;
}) {
  const [revealed, setRevealed] = useState(false);

  return (
    <div className={`bg-card border rounded-2xl p-5 transition-colors ${user.is_active ? "border-border" : "border-dashed border-border opacity-60"}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-foreground text-sm">{user.client_name}</span>
            {user.company && <span className="text-xs text-muted-foreground">· {user.company}</span>}
            {!user.is_active && (
              <span className="text-xs bg-muted text-muted-foreground rounded-full px-2 py-0.5">Disabled</span>
            )}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">{user.client_email}</div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => onCopy(user)}
            title="Copy credentials"
            className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
            </svg>
          </button>
          <button
            onClick={() => onToggle(user.id, !user.is_active)}
            title={user.is_active ? "Disable access" : "Enable access"}
            className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {user.is_active
                ? <><path d="M18.364 18.364A9 9 0 0 0 5.636 5.636m12.728 12.728A9 9 0 0 1 5.636 5.636m12.728 12.728L5.636 5.636"/></>
                : <><circle cx="12" cy="12" r="9"/><path d="M12 8v4l3 3"/></>
              }
            </svg>
          </button>
          <button
            onClick={() => { if (confirm(`Delete portal access for ${user.client_name}?`)) onDelete(user.id); }}
            title="Delete"
            className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/>
            </svg>
          </button>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="bg-background border border-border rounded-xl px-3 py-2">
          <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-0.5">User ID</div>
          <div className="text-sm font-mono font-semibold text-foreground">{user.user_id}</div>
        </div>
        <div className="bg-background border border-border rounded-xl px-3 py-2">
          <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-0.5 flex items-center justify-between">
            Password
            <button onClick={() => setRevealed(r => !r)} className="text-primary text-xs hover:underline">
              {revealed ? "hide" : "show"}
            </button>
          </div>
          <div className="text-sm font-mono font-semibold text-foreground">
            {revealed ? user.password_hash : "••••••••••"}
          </div>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
        <span>Created {new Date(user.created_at).toLocaleDateString()}</span>
        {user.last_login ? (
          <span>Last login: {new Date(user.last_login).toLocaleDateString()}</span>
        ) : (
          <span className="text-yellow-600">Never logged in</span>
        )}
      </div>
    </div>
  );
}

// ─── Create Portal User Form ──────────────────────────────────────────────────

function CreatePortalUser({ clients, onCreated }: {
  clients: Client[];
  onCreated: () => void;
}) {
  const [mode, setMode] = useState<"select" | "manual">("select");
  const [selectedClientId, setSelectedClientId] = useState("");
  const [customName, setCustomName] = useState("");
  const [customEmail, setCustomEmail] = useState("");
  const [customCompany, setCustomCompany] = useState("");
  const [password, setPassword] = useState(() => generatePassword());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState<{ user_id: string; password: string } | null>(null);

  const selectedClient = clients.find(c => c.id === selectedClientId);
  const nameForId = mode === "select" ? (selectedClient?.name ?? "") : customName;

  async function handleCreate() {
    const clientName = mode === "select" ? selectedClient?.name : customName;
    const clientEmail = mode === "select" ? selectedClient?.email : customEmail;
    const clientId = mode === "select" ? selectedClientId : null;
    const company = mode === "select" ? selectedClient?.company : customCompany;

    if (!clientName || !clientEmail) return;

    setSaving(true);
    setError(null);

    // Always fetch a fresh count so the generated user_id is unique
    const { count } = await supabase
      .from("client_portal_users")
      .select("*", { count: "exact", head: true });

    const freshUserId = generateUserId(nameForId, (count ?? 0) + 1);

    const { error: insertError } = await supabase.from("client_portal_users").insert({
      user_id: freshUserId,
      password_hash: password,
      client_id: clientId || null,
      client_name: clientName,
      client_email: clientEmail,
      company: company || null,
      is_active: true,
    });

    setSaving(false);
    if (insertError) {
      setError(insertError.message || "Failed to create portal access. Please try again.");
      return;
    }

    setCreated({ user_id: freshUserId, password });
    onCreated();
  }

  if (created) {
    const creds = `Client Portal Access — eassets.studio\n\nURL: ${window.location.origin}/client\nUser ID: ${created.user_id}\nPassword: ${created.password}\n\nPlease save these credentials safely.`;
    return (
      <div className="bg-green-500/5 border border-green-500/20 rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-green-600">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span className="font-semibold text-foreground">Portal access created!</span>
        </div>
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-background border border-border rounded-xl px-3 py-2">
            <div className="text-xs text-muted-foreground mb-0.5">User ID</div>
            <div className="font-mono font-bold text-foreground">{created.user_id}</div>
          </div>
          <div className="bg-background border border-border rounded-xl px-3 py-2">
            <div className="text-xs text-muted-foreground mb-0.5">Password</div>
            <div className="font-mono font-bold text-foreground">{created.password}</div>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => { copyToClipboard(creds); }}
            className="flex items-center gap-2 bg-primary text-primary-foreground rounded-xl px-4 py-2 text-xs font-medium hover:bg-primary/90 transition-colors"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
            </svg>
            Copy credentials
          </button>
          <button
            onClick={() => { setCreated(null); setSelectedClientId(""); setCustomName(""); setCustomEmail(""); setPassword(generatePassword()); setError(null); }}
            className="bg-muted text-muted-foreground rounded-xl px-4 py-2 text-xs font-medium hover:bg-muted/80 transition-colors"
          >
            Create another
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <h3 className="font-semibold text-foreground">Create Portal Access</h3>

      {/* Mode tabs */}
      <div className="flex gap-1 bg-muted p-1 rounded-xl w-fit text-xs">
        <button onClick={() => setMode("select")} className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${mode === "select" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}>
          Pick existing client
        </button>
        <button onClick={() => setMode("manual")} className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${mode === "manual" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}>
          Enter manually
        </button>
      </div>

      {mode === "select" ? (
        <div>
          <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Select Client</label>
          <select
            value={selectedClientId}
            onChange={(e) => setSelectedClientId(e.target.value)}
            className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
          >
            <option value="">— choose a client —</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>{c.name} {c.company ? `(${c.company})` : ""}</option>
            ))}
          </select>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: "Name *", val: customName, set: setCustomName, ph: "Full name" },
            { label: "Email *", val: customEmail, set: setCustomEmail, ph: "email@company.com" },
            { label: "Company", val: customCompany, set: setCustomCompany, ph: "Company name" },
          ].map((f) => (
            <div key={f.label} className="col-span-2 sm:col-span-1">
              <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1.5">{f.label}</label>
              <input
                type="text"
                value={f.val}
                onChange={(e) => f.set(e.target.value)}
                placeholder={f.ph}
                className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          ))}
        </div>
      )}

      {/* Preview + password */}
      {(selectedClientId || (customName && customEmail)) && (
        <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 space-y-3">
          <div className="text-xs font-mono text-muted-foreground uppercase tracking-widest">Credentials Preview</div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="text-xs text-muted-foreground mb-0.5">User ID (auto-generated)</div>
              <div className="font-mono font-bold text-foreground text-sm text-muted-foreground italic">assigned on create</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-0.5 flex items-center justify-between">
                Password
                <button onClick={() => setPassword(generatePassword())} className="text-primary hover:underline text-xs">↻ regenerate</button>
              </div>
              <input
                type="text"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-background border border-border rounded-lg px-3 py-1.5 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="flex items-center gap-2 text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-xl px-4 py-2.5">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
          {error}
        </div>
      )}

      <button
        onClick={handleCreate}
        disabled={saving || (!selectedClientId && (!customName || !customEmail))}
        className="w-full bg-primary text-primary-foreground rounded-xl py-2.5 text-sm font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
      >
        {saving ? (
          <><svg className="animate-spin" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>Creating…</>
        ) : (
          <><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14"/></svg>Generate Portal Access</>
        )}
      </button>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export function ClientPortalManager() {
  const [users, setUsers] = useState<PortalUser[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [copied, setCopied] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: u }, { data: c }] = await Promise.all([
      supabase.from("client_portal_users").select("*").order("created_at", { ascending: false }),
      supabase.from("clients").select("*").order("name"),
    ]);
    setUsers(u ?? []);
    setClients(c ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function toggleUser(id: string, active: boolean) {
    await supabase.from("client_portal_users").update({ is_active: active }).eq("id", id);
    load();
  }

  async function deleteUser(id: string) {
    await supabase.from("client_portal_users").delete().eq("id", id);
    load();
  }

  function handleCopy(user: PortalUser) {
    const text = `Client Portal — eassets.studio\n\nURL: ${window.location.origin}/client\nUser ID: ${user.user_id}\nPassword: ${user.password_hash}`;
    copyToClipboard(text);
    setCopied(user.id);
    setTimeout(() => setCopied(""), 2000);
  }

  const filtered = users.filter(u =>
    u.client_name.toLowerCase().includes(search.toLowerCase()) ||
    u.user_id.toLowerCase().includes(search.toLowerCase()) ||
    (u.company ?? "").toLowerCase().includes(search.toLowerCase())
  );

  const portalUrl = `${window.location.origin}/client`;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Client Portals</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {users.length} portal{users.length !== 1 ? "s" : ""} · each client gets isolated access
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => { copyToClipboard(portalUrl); setCopied("url"); setTimeout(() => setCopied(""), 2000); }}
            className="flex items-center gap-2 text-xs bg-muted text-muted-foreground rounded-xl px-3 py-2 hover:bg-muted/80 transition-colors"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
            </svg>
            {copied === "url" ? "Copied!" : portalUrl}
          </button>
        </div>
      </div>

      {/* Create new */}
      <CreatePortalUser clients={clients} onCreated={load} />

      {/* Search */}
      {users.length > 0 && (
        <div>
          <input
            type="text"
            placeholder="Search portals…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full max-w-sm bg-card border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
      )}

      {/* List */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => <div key={i} className="h-28 bg-card border border-border rounded-2xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">
          {search ? "No portals match your search." : "No portal users yet. Create one above."}
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((u) => (
            <div key={u.id} className="relative">
              {copied === u.id && (
                <div className="absolute top-2 right-2 z-10 text-xs bg-green-600 text-white rounded-lg px-2.5 py-1 font-medium">
                  Copied!
                </div>
              )}
              <CredentialCard user={u} onToggle={toggleUser} onDelete={deleteUser} onCopy={handleCopy} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
