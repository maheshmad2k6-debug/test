import { useEffect, useState, useCallback, type ChangeEvent } from "react";
import { supabase, type Project, type ProjectMedia } from "@/lib/supabase";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function detectType(file: File): "image" | "video" | null {
  if (file.type.startsWith("image/")) return "image";
  if (file.type.startsWith("video/")) return "video";
  return null;
}

async function uploadToBucket(file: File, prefix: string): Promise<{ url: string; path: string }> {
  const ext = file.name.split(".").pop() || "bin";
  const path = `${prefix}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage
    .from("projects-media")
    .upload(path, file, { contentType: file.type, upsert: false });
  if (error) throw new Error(error.message);
  const { data } = supabase.storage.from("projects-media").getPublicUrl(path);
  return { url: data.publicUrl, path };
}

// ─── Project details (metadata editor) ───────────────────────────────────────

function ProjectDetailsForm({
  project,
  onSaved,
}: { project: Project; onSaved: () => void }) {
  const [title, setTitle] = useState(project.title);
  const [description, setDescription] = useState(project.description ?? "");
  const [sector, setSector] = useState(project.sector ?? "");
  const [url, setUrl] = useState(project.url ?? "");
  const [published, setPublished] = useState(project.published ?? true);
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    if (!title.trim()) { alert("Title required"); return; }
    setSaving(true);
    await supabase.from("projects").update({
      title: title.trim(),
      description: description || null,
      sector: sector || null,
      url: url || null,
      published,
    }).eq("id", project.id);
    setSaving(false);
    onSaved();
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Title *" value={title} onChange={setTitle} />
        <Field label="Sector" value={sector} onChange={setSector} placeholder="Industrial · 2026" />
      </div>
      <Field label="External URL" value={url} onChange={setUrl} placeholder="https://example.com" />
      <div>
        <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Description</label>
        <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3}
          className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary resize-none" />
      </div>
      <div className="flex items-center justify-between p-3 bg-muted/50 border border-border rounded-xl">
        <div>
          <div className="text-sm font-medium text-foreground">Published</div>
          <div className="text-xs text-muted-foreground">Show on the public site</div>
        </div>
        <button onClick={() => setPublished(!published)}
          className={`relative w-12 h-6 rounded-full transition-colors ${published ? "bg-primary" : "bg-muted-foreground/30"}`}>
          <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${published ? "translate-x-6" : "translate-x-0.5"}`} />
        </button>
      </div>
      <div className="flex justify-end">
        <button onClick={handleSave} disabled={saving}
          className="px-4 py-2 rounded-xl text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50">
          {saving ? "Saving…" : "Save details"}
        </button>
      </div>
    </div>
  );
}

// ─── Per-project media manager ───────────────────────────────────────────────

function ProjectMediaManager({
  project,
  onChanged,
}: { project: Project; onChanged: () => void }) {
  const [media, setMedia] = useState<ProjectMedia[]>([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState("");

  const load = useCallback(async () => {
    const { data } = await supabase
      .from("project_media")
      .select("*")
      .eq("project_id", project.id)
      .order("sort_order");
    setMedia(data ?? []);
  }, [project.id]);

  useEffect(() => { load(); }, [load]);

  async function handleFiles(e: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    setUploading(true);
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const type = detectType(file);
        if (!type) continue;
        setProgress(`Uploading ${i + 1}/${files.length}: ${file.name}`);
        const { url: pubUrl, path } = await uploadToBucket(file, project.id);
        const sortOrder = media.length + i;
        const ins = await supabase.from("project_media").insert([{
          project_id: project.id, url: pubUrl, storage_path: path, type, sort_order: sortOrder,
        }]).select().single();
        if (i === 0 && media.length === 0 && !project.cover_url) {
          await supabase.from("projects").update({ cover_url: pubUrl, cover_type: type }).eq("id", project.id);
          onChanged();
        }
        if (ins.data) setMedia(prev => [...prev, ins.data as ProjectMedia]);
      }
      setProgress("");
      e.target.value = "";
    } catch (err) {
      alert(`Upload failed: ${(err as Error).message}`);
    } finally {
      setUploading(false);
    }
  }

  async function deleteMediaItem(m: ProjectMedia) {
    if (!confirm("Delete this media item?")) return;
    if (m.storage_path) await supabase.storage.from("projects-media").remove([m.storage_path]);
    await supabase.from("project_media").delete().eq("id", m.id);
    setMedia(prev => prev.filter(x => x.id !== m.id));
  }

  async function setAsCover(m: ProjectMedia) {
    await supabase.from("projects").update({ cover_url: m.url, cover_type: m.type }).eq("id", project.id);
    onChanged();
  }

  async function updateSort(m: ProjectMedia, sort: number) {
    setMedia(prev => prev.map(x => x.id === m.id ? { ...x, sort_order: sort } : x).sort((a, b) => a.sort_order - b.sort_order));
    await supabase.from("project_media").update({ sort_order: sort }).eq("id", m.id);
  }

  async function updateLayout(m: ProjectMedia, layout: ProjectMedia["layout"]) {
    setMedia(prev => prev.map(x => x.id === m.id ? { ...x, layout } : x));
    await supabase.from("project_media").update({ layout }).eq("id", m.id);
  }

  return (
    <div className="space-y-3">
      <label className="flex flex-col items-center justify-center gap-2 p-5 border-2 border-dashed border-border rounded-xl cursor-pointer hover:border-primary hover:bg-primary/5 transition-all">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-muted-foreground">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
        </svg>
        <span className="text-sm font-medium">{uploading ? progress || "Uploading…" : "Add images or videos to this project"}</span>
        <span className="text-xs text-muted-foreground">No size limit · multiple files</span>
        <input type="file" accept="image/*,video/*" multiple disabled={uploading} onChange={handleFiles} className="hidden" />
      </label>

      {media.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {media.map(m => {
            const isCover = m.url === project.cover_url;
            return (
              <div key={m.id} className="relative group rounded-xl overflow-hidden border border-border bg-muted aspect-[4/3]">
                {m.type === "image" ? (
                  <img src={m.url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <video src={m.url} className="w-full h-full object-cover" muted playsInline />
                )}
                <div className="absolute top-1 left-1 px-2 py-0.5 rounded-full bg-background/80 text-[10px] font-mono uppercase">
                  {m.type}{isCover && " · cover"}
                </div>
                <div className="absolute top-1 right-1 flex items-center gap-1 bg-background/80 backdrop-blur rounded-full pl-2 pr-1 py-0.5">
                  <span className="text-[9px] font-mono uppercase text-muted-foreground">#</span>
                  <input type="number" value={m.sort_order}
                    onChange={e => updateSort(m, parseInt(e.target.value) || 0)}
                    onClick={e => e.stopPropagation()}
                    className="w-10 bg-transparent text-xs font-mono text-foreground focus:outline-none text-center" />
                </div>
                <div className="absolute bottom-1 left-1 right-1 flex flex-wrap gap-0.5 bg-background/85 backdrop-blur rounded-md p-0.5">
                  {(["hero","full","left","right","mockup"] as const).map(opt => (
                    <button
                      key={opt}
                      onClick={() => updateLayout(m, opt)}
                      className={`flex-1 min-w-[36px] px-1 py-0.5 rounded text-[9px] font-mono uppercase tracking-wider transition-colors ${
                        (m.layout ?? "full") === opt
                          ? "bg-foreground text-background"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                      title={
                        opt === "hero" ? "Full-screen hero" :
                        opt === "full" ? "Full width" :
                        opt === "left" ? "Half · left" :
                        opt === "right" ? "Half · right" :
                        "Laptop mockup (uses project URL)"
                      }
                    >
                      {opt}
                    </button>
                  ))}
                </div>
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 pointer-events-none">
                  <div className="flex gap-2 pointer-events-auto">
                    {!isCover && (
                      <button onClick={() => setAsCover(m)} className="px-2 py-1 rounded-md bg-white/20 text-white text-xs">Set cover</button>
                    )}
                    <button onClick={() => deleteMediaItem(m)} className="px-2 py-1 rounded-md bg-destructive text-destructive-foreground text-xs">Delete</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── Create new project (lightweight) ────────────────────────────────────────

function NewProjectForm({ onCreated, onCancel }: { onCreated: () => void; onCancel: () => void }) {
  const [title, setTitle] = useState("");
  const [sector, setSector] = useState("");
  const [saving, setSaving] = useState(false);

  async function create() {
    if (!title.trim()) { alert("Title required"); return; }
    setSaving(true);
    const { error } = await supabase.from("projects").insert([{
      title: title.trim(), sector: sector || null, published: true,
    }]);
    setSaving(false);
    if (error) { alert(error.message); return; }
    setTitle(""); setSector("");
    onCreated();
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <h3 className="font-semibold text-foreground">New project</h3>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Title *" value={title} onChange={setTitle} placeholder="Aurora Robotics" />
        <Field label="Sector" value={sector} onChange={setSector} placeholder="Industrial · 2026" />
      </div>
      <div className="flex justify-end gap-2">
        <button onClick={onCancel} className="px-4 py-2 rounded-xl text-sm font-medium border border-border text-muted-foreground hover:bg-muted">Cancel</button>
        <button onClick={create} disabled={saving} className="px-4 py-2 rounded-xl text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
          {saving ? "Creating…" : "Create project"}
        </button>
      </div>
      <p className="text-xs text-muted-foreground">After creating, expand the project below to upload media.</p>
    </div>
  );
}

function Field({ label, value, onChange, placeholder }: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string;
}) {
  return (
    <div>
      <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">{label}</label>
      <input type="text" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
    </div>
  );
}

// ─── Project row (collapsible) ───────────────────────────────────────────────

function ProjectRow({
  project,
  expanded,
  onToggle,
  onChanged,
  onDelete,
}: {
  project: Project;
  expanded: boolean;
  onToggle: () => void;
  onChanged: () => void;
  onDelete: () => void;
}) {
  const [mediaCount, setMediaCount] = useState<number | null>(null);

  useEffect(() => {
    supabase.from("project_media").select("id", { count: "exact", head: true }).eq("project_id", project.id)
      .then(({ count }) => setMediaCount(count ?? 0));
  }, [project.id, expanded]);

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      {/* Header — always visible */}
      <button onClick={onToggle}
        className="w-full flex items-center gap-4 p-3 text-left hover:bg-muted/40 transition-colors">
        <div className="w-20 h-14 rounded-lg overflow-hidden bg-muted flex-shrink-0">
          {project.cover_url ? (
            project.cover_type === "video" ? (
              <video src={project.cover_url} className="w-full h-full object-cover" muted playsInline />
            ) : (
              <img src={project.cover_url} alt={project.title} className="w-full h-full object-cover" />
            )
          ) : (
            <div className="grid place-items-center h-full text-[10px] text-muted-foreground">No cover</div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-foreground truncate">{project.title}</h3>
            {!project.published && (
              <span className="px-1.5 py-0.5 rounded bg-yellow-500/20 text-yellow-600 dark:text-yellow-400 text-[10px] font-bold uppercase">Hidden</span>
            )}
          </div>
          <div className="text-xs text-muted-foreground truncate">
            {project.sector || "—"} · {mediaCount ?? "…"} media
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={(e) => { e.stopPropagation(); onDelete(); }}
            className="px-3 py-1.5 rounded-lg border border-destructive/30 text-xs font-medium text-destructive hover:bg-destructive/10 transition-colors">
            Delete
          </button>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
            className={`text-muted-foreground transition-transform ${expanded ? "rotate-180" : ""}`}>
            <polyline points="6 9 12 15 18 9"/>
          </svg>
        </div>
      </button>

      {/* Expanded content */}
      {expanded && (
        <div className="border-t border-border p-5 space-y-6">
          <ProjectDetailsForm project={project} onSaved={onChanged} />
          <div>
            <h4 className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">
              Media for "{project.title}"
            </h4>
            <ProjectMediaManager project={project} onChanged={onChanged} />
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main ────────────────────────────────────────────────────────────────────

export function Projects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from("projects")
      .select("*")
      .order("sort_order")
      .order("created_at", { ascending: false });
    setProjects(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleDelete(p: Project) {
    if (!confirm(`Delete project "${p.title}" and all its media?`)) return;
    const { data: media } = await supabase.from("project_media").select("storage_path").eq("project_id", p.id);
    const paths = (media ?? []).map(m => m.storage_path).filter(Boolean) as string[];
    if (paths.length) await supabase.storage.from("projects-media").remove(paths);
    await supabase.from("projects").delete().eq("id", p.id);
    if (expandedId === p.id) setExpandedId(null);
    load();
  }

  if (loading) {
    return <div className="flex items-center justify-center h-48 text-muted-foreground text-sm">Loading projects…</div>;
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-foreground">Projects</h2>
          <p className="text-sm text-muted-foreground">{projects.length} total · click a project to manage its media</p>
        </div>
        <button onClick={() => setShowNew(v => !v)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
          {showNew ? "Close" : "+ New Project"}
        </button>
      </div>

      {showNew && (
        <NewProjectForm
          onCreated={() => { setShowNew(false); load(); }}
          onCancel={() => setShowNew(false)}
        />
      )}

      {projects.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-center">
          <div className="text-4xl mb-3">🎬</div>
          <p className="text-muted-foreground text-sm">No projects yet. Create your first one!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {projects.map(p => (
            <ProjectRow
              key={p.id}
              project={p}
              expanded={expandedId === p.id}
              onToggle={() => setExpandedId(expandedId === p.id ? null : p.id)}
              onChanged={load}
              onDelete={() => handleDelete(p)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
