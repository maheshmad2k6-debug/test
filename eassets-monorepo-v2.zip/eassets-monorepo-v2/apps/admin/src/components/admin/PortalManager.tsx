import { useState, useEffect, useCallback, type FormEvent } from "react";
import { supabase, type Client } from "@/lib/supabase";
import {
  DashboardModule,
  TasksModule,
  MessagesModule,
  FilesModule,
  FinanceModule,
  OnboardingModule,
  ReportModule,
} from "@/components/portal/modules";

// ─── Types ────────────────────────────────────────────────────────────────────

interface PortalUser {
  id: string;
  user_id: string;
  password_hash: string;
  client_id: string;
  client_name: string;
  client_email: string;
  company?: string;
  is_active: boolean;
  created_at: string;
  last_login?: string;
}

type ModuleTab =
  | "dashboard"
  | "tasks"
  | "messages"
  | "files"
  | "finance"
  | "onboarding"
  | "report"
  | "credentials";

const MODULES: { id: ModuleTab; label: string; icon: string }[] = [
  { id: "dashboard", label: "Dashboard", icon: "📊" },
  { id: "tasks", label: "Tasks", icon: "✓" },
  { id: "messages", label: "Messages", icon: "💬" },
  { id: "files", label: "Files", icon: "📁" },
  { id: "finance", label: "Finance", icon: "₹" },
  { id: "onboarding", label: "Onboarding", icon: "🚀" },
  { id: "report", label: "Report", icon: "📈" },
  { id: "credentials", label: "Credentials", icon: "🔑" },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function generateUserId(name: string, index: number): string {
  const year = new Date().getFullYear();
  const initials = name
    .split(" ")
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("")
    .slice(0, 3)
    .padEnd(3, "X");
  return `${initials}-${year}-${String(index).padStart(3, "0")}`;
}

function generatePassword(length = 10): string {
  const chars =
    "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789!@#$";
  return Array.from(
    { length },
    () => chars[Math.floor(Math.random() * chars.length)]
  ).join("");
}

function copy(text: string) {
  navigator.clipboard.writeText(text).catch(() => {});
}

function getInitials(name: string) {
  return name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

// ─── Field ────────────────────────────────────────────────────────────────────

function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder = "",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="block text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-colors"
      />
    </div>
  );
}

// ─── Add Client Sheet ─────────────────────────────────────────────────────────

interface AddClientSheetProps {
  open: boolean;
  onClose: () => void;
  onAdded: (client: Client) => void;
}

function AddClientSheet({ open, onClose, onAdded }: AddClientSheetProps) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    notes: "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  function update(k: string, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
    setError("");
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) { setError("Name is required."); return; }
    if (!form.email.trim()) { setError("Email is required."); return; }
    setBusy(true);
    const { data, error: dbErr } = await supabase
      .from("clients")
      .insert({
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim() || null,
        company: form.company.trim() || null,
        notes: form.notes.trim() || null,
      })
      .select()
      .single();
    setBusy(false);
    if (dbErr || !data) {
      setError("Failed to add client. Please try again.");
      return;
    }
    setForm({ name: "", email: "", phone: "", company: "", notes: "" });
    onAdded(data as Client);
    onClose();
  }

  if (!open) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 z-40 backdrop-blur-sm"
        onClick={onClose}
      />
      {/* Bottom sheet */}
      <div className="fixed inset-x-0 bottom-0 z-50 bg-card rounded-t-3xl border-t border-border shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-border" />
        </div>
        <div className="px-5 pb-8 pt-3 space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-foreground">Add New Client</h2>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-full bg-muted text-muted-foreground hover:bg-muted/80"
            >
              ✕
            </button>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Name *" value={form.name} onChange={(v) => update("name", v)} placeholder="Client full name" />
              <Field label="Email *" value={form.email} onChange={(v) => update("email", v)} type="email" placeholder="client@email.com" />
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Phone" value={form.phone} onChange={(v) => update("phone", v)} placeholder="+91 98765 43210" />
              <Field label="Company" value={form.company} onChange={(v) => update("company", v)} placeholder="Company name" />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
                Notes
              </label>
              <textarea
                value={form.notes}
                onChange={(e) => update("notes", e.target.value)}
                rows={3}
                placeholder="Any notes about this client…"
                className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary resize-none transition-colors"
              />
            </div>
            {error && (
              <p className="text-xs text-destructive flex items-center gap-1.5">
                <span>⚠</span> {error}
              </p>
            )}
            <div className="flex gap-3 pt-1">
              <button
                type="submit"
                disabled={busy}
                className="flex-1 bg-primary text-primary-foreground rounded-xl py-3.5 text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50"
              >
                {busy ? "Adding…" : "Add Client"}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-5 bg-muted text-muted-foreground rounded-xl py-3.5 text-sm font-medium hover:bg-muted/80 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}

// ─── Credentials Panel ────────────────────────────────────────────────────────

function CredentialsPanel({ client }: { client: Client }) {
  const [users, setUsers] = useState<PortalUser[]>([]);
  const [showPwd, setShowPwd] = useState<Record<string, boolean>>({});
  const [creating, setCreating] = useState(false);
  const [newPwd, setNewPwd] = useState(generatePassword());
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState("");

  const load = useCallback(async () => {
    const { data } = await supabase
      .from("client_portal_users")
      .select("*")
      .eq("client_id", client.id)
      .order("created_at", { ascending: false });
    setUsers((data ?? []) as PortalUser[]);
  }, [client.id]);

  useEffect(() => {
    load();
  }, [load]);

  async function create() {
    setBusy(true);
    const { count } = await supabase
      .from("client_portal_users")
      .select("*", { count: "exact", head: true });
    const userId = generateUserId(client.name, (count ?? 0) + 1);
    await supabase.from("client_portal_users").insert({
      user_id: userId,
      password_hash: newPwd,
      client_id: client.id,
      client_name: client.name,
      client_email: client.email,
      company: client.company || null,
      is_active: true,
    });
    setNewPwd(generatePassword());
    setCreating(false);
    setBusy(false);
    load();
  }

  async function toggle(id: string, active: boolean) {
    await supabase
      .from("client_portal_users")
      .update({ is_active: active })
      .eq("id", id);
    load();
  }

  async function remove(id: string) {
    if (!confirm("Delete this credential?")) return;
    await supabase.from("client_portal_users").delete().eq("id", id);
    load();
  }

  function copyCreds(u: PortalUser) {
    const text = `Portal — ${window.location.origin}/client\nUser ID: ${u.user_id}\nPassword: ${u.password_hash}`;
    copy(text);
    setCopied(u.id);
    setTimeout(() => setCopied(""), 1500);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-bold text-foreground">Portal Credentials</h2>
          <p className="text-sm text-muted-foreground">
            {users.length} login{users.length !== 1 && "s"} for this client
          </p>
        </div>
        <button
          onClick={() => setCreating((c) => !c)}
          className="bg-primary text-primary-foreground rounded-xl px-4 py-2.5 text-sm font-semibold hover:bg-primary/90 active:scale-95 transition-all"
        >
          {creating ? "Cancel" : "+ Generate access"}
        </button>
      </div>

      {creating && (
        <div className="bg-muted/50 border border-border rounded-2xl p-4 space-y-3">
          <p className="text-xs text-muted-foreground font-medium">
            A User ID will be auto-generated. Set or regenerate the password:
          </p>
          <div className="flex gap-2 items-stretch">
            <input
              type="text"
              value={newPwd}
              onChange={(e) => setNewPwd(e.target.value)}
              className="flex-1 bg-background border border-border rounded-xl px-4 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
            />
            <button
              onClick={() => setNewPwd(generatePassword())}
              className="text-xs bg-background border border-border text-foreground rounded-xl px-3 hover:bg-muted transition-colors"
            >
              ↻
            </button>
          </div>
          <button
            onClick={create}
            disabled={busy}
            className="w-full bg-primary text-primary-foreground rounded-xl py-3 text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 transition-colors"
          >
            {busy ? "Creating…" : "Create credentials"}
          </button>
        </div>
      )}

      {users.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground text-sm bg-muted/30 border border-dashed border-border rounded-2xl">
          <div className="text-3xl mb-3">🔑</div>
          <p className="font-medium">No credentials yet</p>
          <p className="text-xs mt-1 opacity-70">Generate access for this client above</p>
        </div>
      ) : (
        <div className="space-y-3">
          {users.map((u) => (
            <div
              key={u.id}
              className={`bg-card border rounded-2xl p-4 transition-opacity ${
                u.is_active ? "border-border" : "border-dashed border-border opacity-50"
              }`}
            >
              <div className="flex items-center gap-2 mb-3">
                <span
                  className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                    u.is_active
                      ? "bg-green-500/10 text-green-500"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {u.is_active ? "Active" : "Disabled"}
                </span>
                {u.last_login && (
                  <span className="text-[10px] text-muted-foreground ml-auto">
                    Last login: {new Date(u.last_login).toLocaleDateString()}
                  </span>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-1">
                    User ID
                  </div>
                  <div className="font-mono font-bold text-foreground text-sm">
                    {u.user_id}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-1 flex items-center justify-between">
                    Password
                    <button
                      onClick={() =>
                        setShowPwd((p) => ({ ...p, [u.id]: !p[u.id] }))
                      }
                      className="text-primary text-[10px] hover:underline normal-case tracking-normal font-normal"
                    >
                      {showPwd[u.id] ? "hide" : "show"}
                    </button>
                  </div>
                  <div className="font-mono font-bold text-foreground text-sm">
                    {showPwd[u.id] ? u.password_hash : "••••••••"}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 mt-4 pt-3 border-t border-border">
                <button
                  onClick={() => copyCreds(u)}
                  className="flex-1 text-xs bg-muted text-foreground rounded-lg py-2.5 font-medium hover:bg-muted/80 active:scale-95 transition-all"
                >
                  {copied === u.id ? "✓ Copied!" : "Copy credentials"}
                </button>
                <button
                  onClick={() => toggle(u.id, !u.is_active)}
                  className="flex-1 text-xs bg-muted text-foreground rounded-lg py-2.5 font-medium hover:bg-muted/80 active:scale-95 transition-all"
                >
                  {u.is_active ? "Disable" : "Enable"}
                </button>
                <button
                  onClick={() => remove(u.id)}
                  className="text-xs text-muted-foreground hover:text-destructive px-3 py-2.5 transition-colors"
                >
                  🗑
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────

export function PortalManager() {
  const [clients, setClients] = useState<Client[]>([]);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Client | null>(null);
  const [tab, setTab] = useState<ModuleTab>("tasks");
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);

  async function loadClients() {
    const { data } = await supabase.from("clients").select("*").order("name");
    setClients((data ?? []) as Client[]);
    setLoading(false);
  }

  useEffect(() => {
    loadClients();
  }, []);

  function handleClientAdded(client: Client) {
    setClients((prev) =>
      [...prev, client].sort((a, b) => a.name.localeCompare(b.name))
    );
    // Auto-select the newly added client
    setSelected(client);
    setTab("credentials");
  }

  const filtered = clients.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      (c.company ?? "").toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase())
  );

  // ── Client list ──────────────────────────────────────────────────────────

  if (loading) {
    return (
      <div className="h-64 flex flex-col items-center justify-center gap-3 text-muted-foreground">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        <p className="text-sm">Loading clients…</p>
      </div>
    );
  }

  if (!selected) {
    return (
      <>
        <AddClientSheet
          open={addOpen}
          onClose={() => setAddOpen(false)}
          onAdded={handleClientAdded}
        />

        <div className="space-y-5 pb-6">
          {/* Header */}
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Portal</h1>
              <p className="text-sm text-muted-foreground mt-0.5">
                {clients.length} client{clients.length !== 1 && "s"}
              </p>
            </div>
            <button
              onClick={() => setAddOpen(true)}
              className="flex items-center gap-2 bg-primary text-primary-foreground rounded-xl px-4 py-2.5 text-sm font-semibold hover:bg-primary/90 active:scale-95 transition-all shadow-sm"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
              </svg>
              Add Client
            </button>
          </div>

          {/* Search */}
          <div className="relative">
            <svg
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground"
              width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
            >
              <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              placeholder="Search clients…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-colors"
            />
          </div>

          {/* Client grid */}
          {filtered.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground bg-muted/30 border border-dashed border-border rounded-2xl">
              <div className="text-4xl mb-3">👤</div>
              <p className="font-medium text-sm">
                {search ? "No clients match your search" : "No clients yet"}
              </p>
              {!search && (
                <button
                  onClick={() => setAddOpen(true)}
                  className="mt-4 text-xs text-primary hover:underline"
                >
                  Add your first client →
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filtered.map((c) => (
                <button
                  key={c.id}
                  onClick={() => { setSelected(c); setTab("dashboard"); }}
                  className="group bg-card border border-border rounded-2xl p-4 text-left hover:border-primary/50 hover:shadow-md active:scale-[0.98] transition-all"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-bold text-sm flex-shrink-0">
                      {getInitials(c.name)}
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold text-foreground truncate">{c.name}</div>
                      {c.company && (
                        <div className="text-xs text-muted-foreground truncate">{c.company}</div>
                      )}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground truncate flex items-center gap-1.5">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
                    </svg>
                    {c.email}
                  </div>
                  {c.phone && (
                    <div className="text-xs text-muted-foreground mt-1 flex items-center gap-1.5">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.56 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                      </svg>
                      {c.phone}
                    </div>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
      </>
    );
  }

  // ── Client workspace ─────────────────────────────────────────────────────

  return (
    <>
      <AddClientSheet
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onAdded={handleClientAdded}
      />

      <div className="space-y-4 pb-6">
        {/* Back + header */}
        <div>
          <button
            onClick={() => setSelected(null)}
            className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-3 active:opacity-70 transition-colors"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="15 18 9 12 15 6" />
            </svg>
            All clients
          </button>

          <div className="flex items-start gap-3 flex-wrap justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary font-bold flex-shrink-0">
                {getInitials(selected.name)}
              </div>
              <div className="min-w-0">
                <h1 className="text-xl font-bold text-foreground truncate">{selected.name}</h1>
                <p className="text-sm text-muted-foreground truncate">
                  {selected.company ? `${selected.company} · ` : ""}
                  {selected.email}
                </p>
              </div>
            </div>
            <button
              onClick={() => setAddOpen(true)}
              className="flex items-center gap-2 bg-muted text-foreground rounded-xl px-3 py-2 text-xs font-medium hover:bg-muted/80 active:scale-95 transition-all"
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
              </svg>
              New Client
            </button>
          </div>
        </div>

        {/* Module tabs — horizontally scrollable on mobile */}
        <div className="overflow-x-auto -mx-1 px-1 pb-1">
          <div className="flex gap-1 w-max">
            {MODULES.map((m) => (
              <button
                key={m.id}
                onClick={() => setTab(m.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all active:scale-95 ${
                  tab === m.id
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground"
                }`}
              >
                <span>{m.icon}</span>
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Module content */}
        <div>
          {tab === "dashboard" && <DashboardModule clientId={selected.id} role="admin" onJump={(t) => setTab(t as ModuleTab)} />}
          {tab === "tasks" && <TasksModule clientId={selected.id} role="admin" />}
          {tab === "messages" && <MessagesModule clientId={selected.id} role="admin" />}
          {tab === "files" && <FilesModule clientId={selected.id} role="admin" />}
          {tab === "finance" && (
            <FinanceModule clientId={selected.id} clientEmail={selected.email} role="admin" />
          )}
          {tab === "onboarding" && <OnboardingModule clientId={selected.id} role="admin" />}
          {tab === "report" && <ReportModule clientId={selected.id} role="admin" />}
          {tab === "credentials" && <CredentialsPanel client={selected} />}
        </div>
      </div>
    </>
  );
}
