import { useEffect, useState, useCallback } from "react";
import { supabase, type Client, type StudioDocument, type DocType } from "@/lib/supabase";
import { DOC_TEMPLATES, getTemplate, fillTemplate } from "@/lib/documentTemplates";
import { downloadDocxFromBody, downloadAllAsOneDocx } from "@/lib/documentDocx";

const CATEGORY_ORDER = ["Pre-Project", "Agreement", "Kickoff", "Legal"] as const;

// ─── Markdown Preview ────────────────────────────────────────────────────────

function MarkdownPreview({ body, metadata }: { body: string; metadata: Record<string, string> }) {
  const filled = fillTemplate(body, metadata);
  return (
    <div className="prose prose-sm max-w-none bg-white text-gray-900 rounded-xl p-8 border border-border shadow-sm">
      {filled.split("\n").map((line, i) => {
        if (line.startsWith("# ")) return <h1 key={i} className="text-2xl font-bold mt-4 mb-3">{line.slice(2)}</h1>;
        if (line.startsWith("## ")) return <h2 key={i} className="text-lg font-bold mt-4 mb-2">{line.slice(3)}</h2>;
        if (line.startsWith("### ")) return <h3 key={i} className="text-base font-semibold mt-3 mb-1">{line.slice(4)}</h3>;
        if (line.startsWith("- ") || line.startsWith("* ")) return <div key={i} className="ml-4">• {line.slice(2)}</div>;
        if (line === "---") return <hr key={i} className="my-4 border-gray-200" />;
        if (line.startsWith("|")) return <div key={i} className="font-mono text-xs">{line}</div>;
        if (line.trim() === "") return <div key={i} className="h-3" />;
        return <p key={i} className="mb-2 leading-relaxed">{line}</p>;
      })}
      <div className="mt-8 pt-4 border-t border-gray-200 text-[11px] text-gray-400 text-center">
        <a href="https://eassets-studio.vercel.app" target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">eassets-studio.vercel.app</a><br />
        <span>This is an electronically generated document &amp; does not require a physical signature.</span>
      </div>
    </div>
  );
}

// ─── Document Editor ─────────────────────────────────────────────────────────

function DocumentEditor({
  doc,
  clients,
  onSave,
  onCancel,
}: {
  doc: Partial<StudioDocument> & { doc_type: DocType };
  clients: Client[];
  onSave: (d: Omit<StudioDocument, "id" | "created_at" | "updated_at">) => void;
  onCancel: () => void;
}) {
  const tpl = getTemplate(doc.doc_type)!;
  const [clientId, setClientId] = useState(doc.client_id ?? "");
  const [clientName, setClientName] = useState(doc.client_name ?? "");
  const [clientEmail, setClientEmail] = useState(doc.client_email ?? "");
  const [title, setTitle] = useState(doc.title ?? tpl.title);
  const [body, setBody] = useState(doc.body ?? tpl.defaultBody);
  const [metadata, setMetadata] = useState<Record<string, string>>(
    doc.metadata ?? {
      effective_date: new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }),
    }
  );
  const [showPreview, setShowPreview] = useState(false);

  function handleClientChange(id: string) {
    setClientId(id);
    if (id) {
      const c = clients.find((c) => c.id === id);
      setClientName(c?.name ?? "");
      setClientEmail(c?.email ?? "");
      setMetadata((m) => ({
        ...m,
        client_name: c?.name ?? m.client_name ?? "",
        client_email: c?.email ?? m.client_email ?? "",
        company: c?.company ?? m.company ?? "",
      }));
    }
  }

  function setMeta(key: string, val: string) {
    setMetadata((m) => ({ ...m, [key]: val }));
  }

  function handleSave() {
    onSave({
      client_id: clientId || undefined,
      client_name: clientName || undefined,
      client_email: clientEmail || undefined,
      doc_type: doc.doc_type,
      title,
      body,
      metadata: { ...metadata, client_name: clientName, client_email: clientEmail },
    });
  }

  async function handleDownload() {
    await downloadDocxFromBody({
      title,
      body,
      metadata: { ...metadata, client_name: clientName, client_email: clientEmail },
      filename: `${tpl.type}-${(clientName || "doc").toLowerCase().replace(/\s+/g, "-")}.docx`,
    });
  }

  return (
    <div className="space-y-6">
      {/* Header with back button */}
      <div className="flex items-center gap-3">
        <button
          onClick={onCancel}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:bg-muted transition-colors"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="15 18 9 12 15 6" />
          </svg>
          Back
        </button>
        <div className="flex-1">
          <div className="text-xs text-muted-foreground font-mono uppercase tracking-widest">{tpl.category} · {tpl.emoji}</div>
          <h2 className="text-lg font-bold text-foreground">{tpl.title}</h2>
          <p className="text-xs text-muted-foreground mt-0.5">{tpl.description}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowPreview((s) => !s)}
            className="px-4 py-2 rounded-xl text-sm font-medium border border-border text-muted-foreground hover:bg-muted"
          >
            {showPreview ? "Edit" : "Preview"}
          </button>
          <button
            onClick={handleDownload}
            className="px-4 py-2 rounded-xl text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90"
          >
            Download .docx
          </button>
        </div>
      </div>

      {showPreview ? (
        <MarkdownPreview body={body} metadata={{ ...metadata, client_name: clientName, client_email: clientEmail }} />
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Document Title</label>
              <input value={title} onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Link to Client</label>
              <select value={clientId} onChange={(e) => handleClientChange(e.target.value)}
                className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary">
                <option value="">— Select client —</option>
                {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Client Name</label>
              <input value={clientName} onChange={(e) => { setClientName(e.target.value); setMeta("client_name", e.target.value); }}
                className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Client Email</label>
              <input value={clientEmail} onChange={(e) => { setClientEmail(e.target.value); setMeta("client_email", e.target.value); }}
                className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {tpl.fields
              .filter((f) => !["client_name", "client_email"].includes(f.key))
              .map((f) => (
                <div key={f.key}>
                  <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">{f.label}</label>
                  <input value={metadata[f.key] ?? ""} onChange={(e) => setMeta(f.key, e.target.value)}
                    placeholder={f.placeholder}
                    className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
                </div>
              ))}
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Body (Markdown — # H1, ## H2, - bullets, {"{{placeholder}}"} interpolation)
            </label>
            <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={24}
              className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-primary resize-y" />
          </div>

          <div className="flex gap-3 justify-end">
            <button onClick={onCancel}
              className="px-5 py-2.5 rounded-xl text-sm font-medium border border-border text-muted-foreground hover:bg-muted">
              Cancel
            </button>
            <button onClick={handleSave}
              className="px-5 py-2.5 rounded-xl text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90">
              Save Document
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Full Combined Editor (all 11 docs in one form) ───────────────────────────

function FullDocumentEditor({
  clients,
  onBack,
}: {
  clients: Client[];
  onBack: () => void;
}) {
  const [clientId, setClientId] = useState("");
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [metadata, setMetadata] = useState<Record<string, string>>({
    effective_date: new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }),
  });
  const [bodies, setBodies] = useState<Record<string, string>>(
    Object.fromEntries(DOC_TEMPLATES.map((t) => [t.type, t.defaultBody]))
  );
  const [activeDoc, setActiveDoc] = useState<string>(DOC_TEMPLATES[0].type);
  const [showPreview, setShowPreview] = useState(false);

  function handleClientChange(id: string) {
    setClientId(id);
    if (id) {
      const c = clients.find((c) => c.id === id);
      setClientName(c?.name ?? "");
      setClientEmail(c?.email ?? "");
      setMetadata((m) => ({
        ...m,
        client_name: c?.name ?? m.client_name ?? "",
        client_email: c?.email ?? m.client_email ?? "",
        company: c?.company ?? m.company ?? "",
      }));
    }
  }

  function setMeta(key: string, val: string) {
    setMetadata((m) => ({ ...m, [key]: val }));
  }

  function setBody(type: string, val: string) {
    setBodies((b) => ({ ...b, [type]: val }));
  }

  const activeTpl = getTemplate(activeDoc as DocType)!;
  const mergedMeta = { ...metadata, client_name: clientName, client_email: clientEmail };

  async function downloadAll() {
    await downloadAllAsOneDocx({
      docs: DOC_TEMPLATES.map((t) => ({ title: t.title, body: bodies[t.type] })),
      metadata: mergedMeta,
      filename: `all-documents-${(clientName || "client").toLowerCase().replace(/\s+/g, "-")}.docx`,
    });
  }

  async function downloadCurrent() {
    await downloadDocxFromBody({
      title: activeTpl.title,
      body: bodies[activeDoc],
      metadata: mergedMeta,
      filename: `${activeDoc}-${(clientName || "doc").toLowerCase().replace(/\s+/g, "-")}.docx`,
    });
  }

  // Collect all unique fields from all templates
  const allExtraFields = Array.from(
    new Map(
      DOC_TEMPLATES.flatMap((t) =>
        t.fields.filter((f) => !["client_name", "client_email"].includes(f.key))
      ).map((f) => [f.key, f])
    ).values()
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:bg-muted transition-colors"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="15 18 9 12 15 6" />
          </svg>
          Back
        </button>
        <div className="flex-1">
          <h2 className="text-lg font-bold text-foreground">Full Document Suite</h2>
          <p className="text-xs text-muted-foreground mt-0.5">All 11 documents · shared client fields · download individually or all</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowPreview((s) => !s)}
            className="px-4 py-2 rounded-xl text-sm font-medium border border-border text-muted-foreground hover:bg-muted"
          >
            {showPreview ? "Edit" : "Preview"}
          </button>
          <button
            onClick={downloadCurrent}
            className="px-4 py-2 rounded-xl text-sm font-medium border border-border text-muted-foreground hover:bg-muted"
          >
            ↓ This Doc
          </button>
          <button
            onClick={downloadAll}
            className="px-4 py-2 rounded-xl text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90"
          >
            ↓ All 11 .docx
          </button>
        </div>
      </div>

      {/* Shared client fields */}
      <div className="bg-muted/30 rounded-2xl border border-border p-5 space-y-4">
        <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">Shared Fields — applied to all documents</div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Link to Client</label>
            <select value={clientId} onChange={(e) => handleClientChange(e.target.value)}
              className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary">
              <option value="">— Select client —</option>
              {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Effective Date</label>
            <input value={metadata.effective_date ?? ""} onChange={(e) => setMeta("effective_date", e.target.value)}
              className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
          </div>
          <div>
            <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Client Name</label>
            <input value={clientName} onChange={(e) => { setClientName(e.target.value); setMeta("client_name", e.target.value); }}
              className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
          </div>
          <div>
            <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Client Email</label>
            <input value={clientEmail} onChange={(e) => { setClientEmail(e.target.value); setMeta("client_email", e.target.value); }}
              className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
          </div>
          {allExtraFields.map((f) => (
            <div key={f.key}>
              <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">{f.label}</label>
              <input value={metadata[f.key] ?? ""} onChange={(e) => setMeta(f.key, e.target.value)}
                placeholder={f.placeholder}
                className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
          ))}
        </div>
      </div>

      {/* Doc tabs */}
      <div className="space-y-4">
        <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Documents</div>
        <div className="flex flex-wrap gap-2">
          {DOC_TEMPLATES.map((t) => (
            <button
              key={t.type}
              onClick={() => setActiveDoc(t.type)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
                activeDoc === t.type
                  ? "bg-primary/10 border-primary text-primary"
                  : "border-border text-muted-foreground hover:border-primary/50 hover:text-foreground"
              }`}
            >
              <span>{t.emoji}</span>
              <span className="hidden sm:inline">{t.title}</span>
            </button>
          ))}
        </div>

        {/* Active doc editor/preview */}
        <div className="rounded-2xl border border-border overflow-hidden">
          <div className="px-5 py-3 border-b border-border bg-muted/20 flex items-center gap-3">
            <span className="text-lg">{activeTpl.emoji}</span>
            <div className="flex-1">
              <div className="text-sm font-semibold text-foreground">{activeTpl.title}</div>
              <div className="text-xs text-muted-foreground">{activeTpl.category}</div>
            </div>
          </div>
          <div className="p-5">
            {showPreview ? (
              <MarkdownPreview body={bodies[activeDoc]} metadata={mergedMeta} />
            ) : (
              <div>
                <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
                  Body (Markdown)
                </label>
                <textarea
                  value={bodies[activeDoc]}
                  onChange={(e) => setBody(activeDoc, e.target.value)}
                  rows={20}
                  className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-primary resize-y"
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main Documents Component ────────────────────────────────────────────────

type ViewMode = "separate" | "full";

export function Documents() {
  const [docs, setDocs] = useState<StudioDocument[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState<DocType | null>(null);
  const [editing, setEditing] = useState<StudioDocument | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>("separate");
  const [showFullEditor, setShowFullEditor] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: d }, { data: c }] = await Promise.all([
      supabase.from("documents").select("*").order("created_at", { ascending: false }),
      supabase.from("clients").select("*").order("name"),
    ]);
    setDocs((d ?? []) as StudioDocument[]);
    setClients(c ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleSave(data: Omit<StudioDocument, "id" | "created_at" | "updated_at">) {
    const payload = { ...data, updated_at: new Date().toISOString() };
    if (editing) {
      await supabase.from("documents").update(payload).eq("id", editing.id);
    } else {
      await supabase.from("documents").insert([payload]);
    }
    setCreating(null);
    setEditing(null);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this document?")) return;
    await supabase.from("documents").delete().eq("id", id);
    load();
  }

  async function quickDownload(d: StudioDocument) {
    const tpl = getTemplate(d.doc_type);
    await downloadDocxFromBody({
      title: d.title,
      body: d.body,
      metadata: { ...d.metadata, client_name: d.client_name ?? "", client_email: d.client_email ?? "" },
      filename: `${tpl?.type ?? "document"}-${(d.client_name || "doc").toLowerCase().replace(/\s+/g, "-")}.docx`,
    });
  }

  // Show individual doc editor
  if (creating || editing) {
    const docType = editing?.doc_type ?? creating!;
    return (
      <DocumentEditor
        doc={editing ?? { doc_type: docType }}
        clients={clients}
        onSave={handleSave}
        onCancel={() => { setCreating(null); setEditing(null); }}
      />
    );
  }

  // Show full combined editor
  if (showFullEditor) {
    return (
      <FullDocumentEditor
        clients={clients}
        onBack={() => setShowFullEditor(false)}
      />
    );
  }

  if (loading) {
    return <div className="flex items-center justify-center h-48 text-muted-foreground text-sm">Loading documents…</div>;
  }

  return (
    <div className="space-y-6">
      {/* Page header + view toggle */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-lg font-bold text-foreground">Documents</h2>
          <p className="text-sm text-muted-foreground">Per-client editable docs · download as .docx</p>
        </div>

        {/* Separate / Full toggle */}
        <div className="flex items-center gap-1 p-1 rounded-xl bg-muted border border-border">
          <button
            onClick={() => setViewMode("separate")}
            className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all ${
              viewMode === "separate"
                ? "bg-background text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Separate
          </button>
          <button
            onClick={() => setViewMode("full")}
            className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all ${
              viewMode === "full"
                ? "bg-background text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Full
          </button>
        </div>
      </div>

      {/* ── SEPARATE view ─────────────────────────────────────────────────── */}
      {viewMode === "separate" && (
        <div className="space-y-8">
          {CATEGORY_ORDER.map((cat) => (
            <section key={cat} className="space-y-3">
              <h3 className="text-xs font-mono uppercase tracking-widest text-muted-foreground">{cat}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {DOC_TEMPLATES.filter((t) => t.category === cat).map((t) => (
                  <button key={t.type} onClick={() => setCreating(t.type)}
                    className="text-left p-4 rounded-2xl border border-border bg-card hover:border-primary hover:shadow-md transition-all">
                    <div className="text-2xl mb-2">{t.emoji}</div>
                    <div className="font-semibold text-sm text-foreground">{t.title}</div>
                    <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{t.description}</div>
                    <div className="mt-3 text-[11px] text-primary font-medium">+ New from template →</div>
                  </button>
                ))}
              </div>
            </section>
          ))}

          {/* Saved docs list */}
          <section className="space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Saved Documents ({docs.length})</h3>
            {docs.length === 0 ? (
              <div className="text-sm text-muted-foreground p-8 text-center bg-muted/30 rounded-xl border border-border">
                No documents yet. Pick a template above to create one.
              </div>
            ) : (
              <div className="space-y-2">
                {docs.map((d) => {
                  const tpl = getTemplate(d.doc_type);
                  const date = new Date(d.created_at).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" });
                  return (
                    <div key={d.id} className="bg-card border border-border rounded-2xl p-4 flex items-center gap-4">
                      <div className="text-2xl">{tpl?.emoji ?? "📄"}</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm text-foreground truncate">{d.title}</div>
                        <div className="text-xs text-muted-foreground">{d.client_name || "Unassigned"} · {date}</div>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => quickDownload(d)}
                          className="px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary">
                          .docx
                        </button>
                        <button onClick={() => setEditing(d)}
                          className="px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary">
                          Edit
                        </button>
                        <button onClick={() => handleDelete(d.id)}
                          className="px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:border-destructive hover:text-destructive">
                          Delete
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </div>
      )}

      {/* ── FULL view ─────────────────────────────────────────────────────── */}
      {viewMode === "full" && (
        <div className="space-y-6">
          {/* Summary of all 11 docs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {DOC_TEMPLATES.map((t) => (
              <div key={t.type} className="p-4 rounded-2xl border border-border bg-card flex items-start gap-3">
                <div className="text-2xl">{t.emoji}</div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm text-foreground">{t.title}</div>
                  <div className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{t.description}</div>
                  <div className="mt-1.5 text-[11px] font-mono uppercase tracking-widest text-muted-foreground/60">{t.category}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Single Edit button */}
          <div className="flex justify-center">
            <button
              onClick={() => setShowFullEditor(true)}
              className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors shadow-sm"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
              </svg>
              Edit All 11 Documents
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
