import { useEffect, useState } from "react";
import { supabase, type Message } from "@/lib/supabase";

export function Messages() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Message | null>(null);
  const [rlsError, setRlsError] = useState(false);

  async function load() {
    setLoading(true);
    setRlsError(false);
    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      if (error.code === "42501" || error.message?.includes("permission")) {
        setRlsError(true);
      }
      setMessages([]);
    } else {
      setMessages(data ?? []);
      // Keep selected in sync
      if (selected) {
        const fresh = (data ?? []).find((m) => m.id === selected.id);
        setSelected(fresh ?? null);
      }
    }
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleDelete(id: string) {
    if (!confirm("Delete this message?")) return;
    await supabase.from("messages").delete().eq("id", id);
    if (selected?.id === id) setSelected(null);
    await load();
  }

  return (
    <div className="flex h-[calc(100vh-140px)] gap-4">
      {/* Sidebar list */}
      <div className="w-80 flex-shrink-0 flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold text-foreground">Messages</h1>
            <p className="text-xs text-muted-foreground mt-0.5">{messages.length} total</p>
          </div>
          <button
            onClick={load}
            disabled={loading}
            className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
            title="Refresh"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={loading ? "animate-spin" : ""}>
              <polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-4.12"/>
            </svg>
          </button>
        </div>

        {rlsError && (
          <div className="mb-3 p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20 text-xs text-yellow-700 dark:text-yellow-400">
            <strong>RLS error:</strong> Add a policy on the <code>messages</code> table allowing service role or authenticated reads. Example:
            <code className="block mt-1 bg-yellow-500/10 rounded p-1">CREATE POLICY "Admin read" ON messages FOR SELECT USING (true);</code>
          </div>
        )}

        <div className="flex-1 overflow-y-auto space-y-2">
          {loading ? (
            [...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-card border border-border rounded-xl animate-pulse" />
            ))
          ) : messages.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground text-sm">
              {rlsError ? "Permission denied." : "No messages yet."}
            </div>
          ) : (
            messages.map((m) => (
              <button
                key={m.id}
                onClick={() => setSelected(m)}
                className={`w-full text-left p-3 rounded-xl border transition-colors ${
                  selected?.id === m.id
                    ? "bg-primary/10 border-primary/30"
                    : "bg-card border-border hover:bg-muted/40"
                }`}
              >
                <div className="font-medium text-sm text-foreground truncate">{m.name}</div>
                <div className="text-xs text-muted-foreground truncate">{m.subject ?? m.email}</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {new Date(m.created_at).toLocaleDateString()}
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Detail panel */}
      <div className="flex-1 bg-card border border-border rounded-2xl">
        {selected ? (
          <div className="p-6 h-full flex flex-col">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-lg font-bold text-foreground">{selected.subject ?? "(no subject)"}</h2>
                <div className="text-sm text-muted-foreground mt-1">
                  From: <strong>{selected.name}</strong> &lt;{selected.email}&gt;
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {new Date(selected.created_at).toLocaleString()}
                </div>
              </div>
              <button
                onClick={() => handleDelete(selected.id)}
                className="p-2 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                title="Delete message"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/>
                  <path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/>
                </svg>
              </button>
            </div>
            <div className="flex-1 bg-muted/30 rounded-xl p-5 text-sm text-foreground leading-relaxed whitespace-pre-wrap overflow-y-auto">
              {selected.message}
            </div>
            <div className="mt-4">
              <a
                href={`mailto:${selected.email}?subject=Re: ${selected.subject ?? ""}`}
                className="inline-flex items-center gap-2 bg-primary text-primary-foreground rounded-xl px-4 py-2.5 text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                  <polyline points="22,6 12,13 2,6"/>
                </svg>
                Reply via email
              </a>
            </div>
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
            Select a message to read
          </div>
        )}
      </div>
    </div>
  );
}
