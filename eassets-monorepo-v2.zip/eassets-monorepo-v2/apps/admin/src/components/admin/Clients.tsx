import { useEffect, useState } from "react";
import { supabase, type Client, type Payment, type Quotation } from "@/lib/supabase";
import { generateInvoicePDF } from "@/lib/pdfUtils";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmt(n: number) {
  return `₹${n.toLocaleString("en-IN", { minimumFractionDigits: 0 })}`;
}

function generateUserId(name: string, index: number): string {
  const year = new Date().getFullYear();
  const initials = name
    .split(" ")
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("")
    .slice(0, 3)
    .padEnd(3, "X");
  const num = String(index).padStart(3, "0");
  return `${initials}-${year}-${num}`;
}

function generatePassword(length = 10): string {
  const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789!@#$";
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text).catch(() => {
    const el = document.createElement("textarea");
    el.value = text;
    document.body.appendChild(el);
    el.select();
    document.execCommand("copy");
    document.body.removeChild(el);
  });
}

// ─── Generate Login Details Modal ─────────────────────────────────────────────

interface GeneratedCreds {
  user_id: string;
  password: string;
}

interface GenerateLoginModalProps {
  client: Client;
  onClose: () => void;
}

function GenerateLoginModal({ client, onClose }: GenerateLoginModalProps) {
  const [generated, setGenerated] = useState<GeneratedCreds | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  async function handleGenerate() {
    setLoading(true);
    setError("");

    // Check if portal user already exists for this client
    const { data: existing } = await supabase
      .from("client_portal_users")
      .select("id, user_id, password_hash")
      .eq("client_id", client.id)
      .maybeSingle();

    if (existing) {
      // Return existing credentials
      setGenerated({ user_id: existing.user_id, password: existing.password_hash });
      setLoading(false);
      return;
    }

    // Generate fresh credentials
    const password = generatePassword();

    const { count } = await supabase
      .from("client_portal_users")
      .select("*", { count: "exact", head: true });

    const userId = generateUserId(client.name, (count ?? 0) + 1);

    const { error: insertError } = await supabase.from("client_portal_users").insert({
      user_id: userId,
      password_hash: password,
      client_id: client.id,
      client_name: client.name,
      client_email: client.email,
      company: client.company || null,
      is_active: true,
    });

    setLoading(false);

    if (insertError) {
      setError(insertError.message || "Failed to generate credentials. Please try again.");
      return;
    }

    setGenerated({ user_id: userId, password });
  }

  function handleCopy() {
    if (!generated) return;
    const text = `Client Portal Access — eassets.studio\n\nURL: ${window.location.origin}/client\nUser ID: ${generated.user_id}\nPassword: ${generated.password}\n\nPlease save these credentials safely.`;
    copyToClipboard(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative bg-card border border-border rounded-2xl shadow-2xl w-full max-w-sm p-6 space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-base font-bold text-foreground">Generate Login Details</h2>
            <p className="text-xs text-muted-foreground mt-0.5">{client.name}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        {!generated ? (
          <>
            <div className="bg-muted/50 rounded-xl px-4 py-3 text-sm text-muted-foreground">
              This will generate a unique <span className="font-mono text-foreground">User ID</span> and{" "}
              <span className="font-mono text-foreground">Password</span> for{" "}
              <span className="font-medium text-foreground">{client.name}</span> to access the client
              portal at <span className="text-primary">/client</span>.
            </div>

            {error && (
              <div className="flex items-center gap-2 text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-xl px-4 py-2.5">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
                {error}
              </div>
            )}

            <button
              onClick={handleGenerate}
              disabled={loading}
              className="w-full bg-primary text-primary-foreground rounded-xl py-3 text-sm font-medium hover:bg-primary/90 disabled:opacity-60 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <svg className="animate-spin" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                  </svg>
                  Generating…
                </>
              ) : (
                <>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
                  </svg>
                  Generate Login Details
                </>
              )}
            </button>
          </>
        ) : (
          <div className="space-y-4">
            {/* Success */}
            <div className="flex items-center gap-2 text-sm text-green-600">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="20 6 9 17 4 12" />
              </svg>
              <span className="font-medium">Credentials ready!</span>
            </div>

            {/* Credentials display */}
            <div className="grid grid-cols-1 gap-3">
              <div className="bg-background border border-border rounded-xl px-4 py-3">
                <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">User ID</div>
                <div className="font-mono font-bold text-foreground text-lg tracking-wider">{generated.user_id}</div>
              </div>
              <div className="bg-background border border-border rounded-xl px-4 py-3">
                <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">Password</div>
                <div className="font-mono font-bold text-foreground text-lg">{generated.password}</div>
              </div>
            </div>

            {/* Portal URL hint */}
            <div className="text-xs text-muted-foreground text-center">
              Login at{" "}
              <a href="/client" className="text-primary hover:underline font-mono">
                {window.location.origin}/client
              </a>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={handleCopy}
                className="flex-1 flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-xl py-2.5 text-xs font-medium hover:bg-primary/90 transition-colors"
              >
                {copied ? (
                  <>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    Copied!
                  </>
                ) : (
                  <>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                    </svg>
                    Copy credentials
                  </>
                )}
              </button>
              <button
                onClick={onClose}
                className="flex-1 bg-muted text-muted-foreground rounded-xl py-2.5 text-xs font-medium hover:bg-muted/80 transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Client Form ──────────────────────────────────────────────────────────────

interface ClientFormProps {
  initial?: Partial<Client>;
  onSave: (data: Partial<Client>) => void;
  onCancel: () => void;
}

function ClientForm({ initial = {}, onSave, onCancel }: ClientFormProps) {
  const [form, setForm] = useState({
    name: initial.name ?? "",
    email: initial.email ?? "",
    phone: initial.phone ?? "",
    company: initial.company ?? "",
    notes: initial.notes ?? "",
  });

  function update(k: string, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Field label="Name *" value={form.name} onChange={(v) => update("name", v)} />
        <Field label="Email *" value={form.email} onChange={(v) => update("email", v)} type="email" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Phone" value={form.phone} onChange={(v) => update("phone", v)} />
        <Field label="Company" value={form.company} onChange={(v) => update("company", v)} />
      </div>
      <div>
        <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Notes</label>
        <textarea
          value={form.notes}
          onChange={(e) => update("notes", e.target.value)}
          rows={3}
          className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary resize-none"
        />
      </div>
      <div className="flex gap-3 pt-2">
        <button
          onClick={() => onSave(form)}
          className="flex-1 bg-primary text-primary-foreground rounded-xl py-2.5 text-sm font-medium hover:bg-primary/90 transition-colors"
        >
          Save client
        </button>
        <button
          onClick={onCancel}
          className="flex-1 bg-muted text-muted-foreground rounded-xl py-2.5 text-sm font-medium hover:bg-muted/80 transition-colors"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <div>
      <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-colors"
      />
    </div>
  );
}

// ─── Client Detail ─────────────────────────────────────────────────────────────

interface ClientDetailProps {
  client: Client;
  onBack: () => void;
}

function ClientDetail({ client, onBack }: ClientDetailProps) {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showGenerateModal, setShowGenerateModal] = useState(false);

  useEffect(() => {
    async function load() {
      const [{ data: p }, { data: q }] = await Promise.all([
        supabase.from("payments").select("*").eq("client_id", client.id).order("created_at", { ascending: false }),
        supabase.from("quotations").select("*").eq("client_id", client.id).order("created_at", { ascending: false }),
      ]);
      setPayments(p ?? []);
      setQuotations(q ?? []);
      setLoading(false);
    }
    load();
  }, [client.id]);

  const totalPaid = payments.filter((p) => p.status === "paid").reduce((s, p) => s + p.amount, 0);
  const totalPending = payments.filter((p) => p.status !== "paid").reduce((s, p) => s + p.amount, 0);

  return (
    <div>
      {showGenerateModal && (
        <GenerateLoginModal client={client} onClose={() => setShowGenerateModal(false)} />
      )}

      <button onClick={onBack} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
        Back to clients
      </button>

      <div className="bg-card border border-border rounded-2xl p-6 mb-6">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-xl font-bold text-foreground">{client.name}</h2>
            {client.company && <p className="text-sm text-muted-foreground">{client.company}</p>}
            <div className="flex gap-4 mt-3 text-sm text-muted-foreground">
              <span>{client.email}</span>
              {client.phone && <span>{client.phone}</span>}
            </div>
            {client.notes && <p className="text-sm text-muted-foreground mt-2 italic">{client.notes}</p>}
          </div>
          <div className="flex flex-col items-end gap-3">
            <div className="flex gap-3 text-center">
              <div className="bg-green-500/10 rounded-xl px-4 py-2">
                <div className="text-sm font-bold text-green-600">{fmt(totalPaid)}</div>
                <div className="text-xs text-muted-foreground">Paid</div>
              </div>
              <div className="bg-red-500/10 rounded-xl px-4 py-2">
                <div className="text-sm font-bold text-red-600">{fmt(totalPending)}</div>
                <div className="text-xs text-muted-foreground">Pending</div>
              </div>
            </div>
            {/* Generate Login Details button in detail view */}
            <button
              onClick={() => setShowGenerateModal(true)}
              className="flex items-center gap-2 bg-primary/10 text-primary border border-primary/20 rounded-xl px-4 py-2 text-xs font-medium hover:bg-primary/20 transition-colors"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
              Generate Login Details
            </button>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-10 text-muted-foreground text-sm">Loading...</div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Payments */}
          <div className="bg-card border border-border rounded-2xl p-5">
            <h3 className="font-semibold text-foreground mb-4">Payments</h3>
            {payments.length === 0 ? (
              <p className="text-sm text-muted-foreground">No payments yet.</p>
            ) : (
              <div className="space-y-3">
                {payments.map((p) => (
                  <div key={p.id} className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium text-foreground">{fmt(p.amount)}</div>
                      <div className="text-xs text-muted-foreground">{p.type ?? "Payment"} · {new Date(p.created_at).toLocaleDateString()}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                        p.status === "paid" ? "bg-green-500/10 text-green-600" :
                        p.status === "overdue" ? "bg-red-500/10 text-red-600" :
                        "bg-yellow-500/10 text-yellow-600"
                      }`}>{p.status}</span>
                      {p.invoice_id && (
                        <button
                          onClick={async () => {
                            const { data } = await supabase.from("invoices").select("*").eq("id", p.invoice_id).single();
                            if (data) generateInvoicePDF(data);
                          }}
                          className="text-xs text-primary hover:underline"
                        >
                          PDF
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quotations */}
          <div className="bg-card border border-border rounded-2xl p-5">
            <h3 className="font-semibold text-foreground mb-4">Quotations</h3>
            {quotations.length === 0 ? (
              <p className="text-sm text-muted-foreground">No quotations yet.</p>
            ) : (
              <div className="space-y-3">
                {quotations.map((q) => (
                  <div key={q.id} className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium text-foreground">{fmt(q.total)}</div>
                      <div className="text-xs text-muted-foreground">{new Date(q.created_at).toLocaleDateString()}</div>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                      q.status === "accepted" ? "bg-green-500/10 text-green-600" :
                      q.status === "rejected" ? "bg-red-500/10 text-red-600" :
                      q.status === "sent" ? "bg-blue-500/10 text-blue-600" :
                      "bg-muted text-muted-foreground"
                    }`}>{q.status}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main Clients Page ────────────────────────────────────────────────────────

export function Clients() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<"list" | "create" | "edit" | "detail">("list");
  const [selected, setSelected] = useState<Client | null>(null);
  const [search, setSearch] = useState("");
  const [generateTarget, setGenerateTarget] = useState<Client | null>(null);

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("clients").select("*").order("created_at", { ascending: false });
    setClients(data ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleSave(data: Partial<Client>) {
    if (!data.name || !data.email) return;
    if (view === "edit" && selected) {
      await supabase.from("clients").update(data).eq("id", selected.id);
    } else {
      await supabase.from("clients").insert(data);
    }
    await load();
    setView("list");
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this client?")) return;
    await supabase.from("clients").delete().eq("id", id);
    await load();
  }

  const filtered = clients.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase()) ||
      (c.company ?? "").toLowerCase().includes(search.toLowerCase())
  );

  if (view === "detail" && selected) {
    return <ClientDetail client={selected} onBack={() => setView("list")} />;
  }

  if (view === "create" || view === "edit") {
    return (
      <div>
        <h1 className="text-2xl font-bold text-foreground mb-6">{view === "create" ? "New Client" : "Edit Client"}</h1>
        <div className="bg-card border border-border rounded-2xl p-6 max-w-xl">
          <ClientForm
            initial={selected ?? {}}
            onSave={handleSave}
            onCancel={() => setView("list")}
          />
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Generate Login Modal (from list view) */}
      {generateTarget && (
        <GenerateLoginModal client={generateTarget} onClose={() => setGenerateTarget(null)} />
      )}

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Clients</h1>
          <p className="text-sm text-muted-foreground mt-1">{clients.length} total</p>
        </div>
        <button
          onClick={() => { setSelected(null); setView("create"); }}
          className="flex items-center gap-2 bg-primary text-primary-foreground rounded-xl px-4 py-2.5 text-sm font-medium hover:bg-primary/90 transition-colors"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14"/></svg>
          New client
        </button>
      </div>

      <div className="mb-4">
        <input
          type="text"
          placeholder="Search clients..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full max-w-sm bg-card border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
        />
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-20 bg-card border border-border rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground text-sm">
          {search ? "No clients match your search." : "No clients yet. Add your first one!"}
        </div>
      ) : (
        <div className="bg-card border border-border rounded-2xl divide-y divide-border overflow-hidden">
          {filtered.map((c) => (
            <div key={c.id} className="flex items-center justify-between px-5 py-4 hover:bg-muted/30 transition-colors">
              <button
                onClick={() => { setSelected(c); setView("detail"); }}
                className="text-left flex-1"
              >
                <div className="font-medium text-foreground">{c.name}</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {c.email}
                  {c.company && ` · ${c.company}`}
                </div>
              </button>
              <div className="flex items-center gap-2 ml-4">
                {/* Generate Login Details button */}
                <button
                  onClick={() => setGenerateTarget(c)}
                  title="Generate login details"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 text-xs font-medium transition-colors border border-primary/20"
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
                  </svg>
                  Login Details
                </button>
                <button
                  onClick={() => { setSelected(c); setView("edit"); }}
                  className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                </button>
                <button
                  onClick={() => handleDelete(c.id)}
                  className="p-2 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
