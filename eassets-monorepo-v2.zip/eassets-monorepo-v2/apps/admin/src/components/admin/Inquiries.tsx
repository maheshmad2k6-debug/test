import { useEffect, useState } from "react";
import { supabase, type ProjectInquiry } from "@/lib/supabase";

const STATUS_COLORS: Record<string, string> = {
  new: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  contacted: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400",
  closed: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
};

const FLOW: ProjectInquiry["status"][] = ["new", "contacted", "closed"];

export function Inquiries() {
  const [items, setItems] = useState<ProjectInquiry[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<ProjectInquiry | null>(null);
  const [filter, setFilter] = useState<"all" | ProjectInquiry["status"]>("all");

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("project_inquiries")
      .select("*")
      .order("created_at", { ascending: false });
    setItems(data ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function cycleStatus(it: ProjectInquiry) {
    const next = FLOW[(FLOW.indexOf(it.status) + 1) % FLOW.length];
    await supabase.from("project_inquiries").update({ status: next }).eq("id", it.id);
    load();
    if (selected?.id === it.id) setSelected({ ...it, status: next });
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this enquiry?")) return;
    await supabase.from("project_inquiries").delete().eq("id", id);
    if (selected?.id === id) setSelected(null);
    load();
  }

  const filtered = filter === "all" ? items : items.filter(i => i.status === filter);
  const counts = {
    all: items.length,
    new: items.filter(i => i.status === "new").length,
    contacted: items.filter(i => i.status === "contacted").length,
    closed: items.filter(i => i.status === "closed").length,
  };

  if (loading) {
    return <div className="flex items-center justify-center h-48 text-muted-foreground text-sm">Loading enquiries…</div>;
  }

  return (
    <div className="flex h-[calc(100vh-140px)] gap-4">
      <div className="w-80 flex-shrink-0 flex flex-col">
        <div className="mb-4">
          <h1 className="text-xl font-bold text-foreground">Project Enquiries</h1>
          <p className="text-xs text-muted-foreground mt-0.5">{items.length} total</p>
        </div>

        <div className="flex gap-1 mb-3 bg-muted p-1 rounded-xl">
          {(["all", "new", "contacted", "closed"] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`flex-1 text-[10px] font-mono uppercase tracking-wider py-1.5 rounded-lg transition-colors ${
                filter === f ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {f} {counts[f] > 0 && <span className="opacity-60">({counts[f]})</span>}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-center">
              <div className="text-3xl mb-2">📬</div>
              <p className="text-sm text-muted-foreground">No {filter === "all" ? "" : filter} enquiries</p>
            </div>
          ) : (
            filtered.map((it) => (
              <button
                key={it.id}
                onClick={() => setSelected(it)}
                className={`w-full text-left p-3 rounded-xl border transition-all ${
                  selected?.id === it.id ? "border-primary bg-primary/5" : "border-border hover:border-primary/40 bg-card"
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-semibold text-sm text-foreground truncate">{it.name}</p>
                    <p className="text-xs text-muted-foreground truncate mt-0.5">{it.email}</p>
                  </div>
                  <span className={`flex-shrink-0 px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${STATUS_COLORS[it.status]}`}>
                    {it.status}
                  </span>
                </div>
                {it.project_title && (
                  <p className="text-[11px] text-primary mt-1.5 truncate">→ {it.project_title}</p>
                )}
              </button>
            ))
          )}
        </div>
      </div>

      <div className="flex-1 min-w-0">
        {!selected ? (
          <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
            <div className="text-4xl mb-3">📬</div>
            <p className="text-sm">Select an enquiry to view details</p>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-2xl h-full flex flex-col overflow-hidden">
            <div className="p-6 border-b border-border flex items-start justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-foreground">{selected.name}</h2>
                <p className="text-sm text-muted-foreground mt-0.5">{selected.email}</p>
                {selected.phone && <p className="text-sm text-muted-foreground">{selected.phone}</p>}
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => cycleStatus(selected)}
                  className="px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary transition-colors"
                >
                  Mark {FLOW[(FLOW.indexOf(selected.status) + 1) % FLOW.length]} →
                </button>
                <button
                  onClick={() => handleDelete(selected.id)}
                  className="p-2 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                  title="Delete"
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/>
                  </svg>
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <div className="flex gap-2 flex-wrap">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold uppercase ${STATUS_COLORS[selected.status]}`}>{selected.status}</span>
                {selected.project_title && (
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-primary/10 text-primary">
                    Project: {selected.project_title}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                {selected.phone && <Cell label="Phone" value={selected.phone} />}
                <Cell
                  label="Received"
                  value={new Date(selected.created_at).toLocaleString("en-IN", {
                    day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
                  })}
                />
              </div>

              {selected.message && (
                <div className="bg-muted/50 rounded-xl p-4">
                  <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">Message</p>
                  <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">{selected.message}</p>
                </div>
              )}

              <a
                href={`mailto:${selected.email}?subject=${encodeURIComponent(`Re: Your enquiry${selected.project_title ? ` about ${selected.project_title}` : ""}`)}`}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
                </svg>
                Reply to {selected.name.split(" ")[0]}
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Cell({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-muted/50 rounded-xl p-3">
      <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-1">{label}</p>
      <p className="text-sm font-medium text-foreground">{value}</p>
    </div>
  );
}
