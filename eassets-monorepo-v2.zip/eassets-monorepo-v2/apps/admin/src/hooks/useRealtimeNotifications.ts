import { useEffect, useRef } from "react";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";

interface NotifyConfig {
  /** Limit subscriptions to one client (portal user view) */
  clientId?: string;
  /** When true, subscribe to global tables: inquiries, bookings */
  global?: boolean;
  /** When true, subscribe to revision requests (admin-side) */
  watchRevisions?: boolean;
}

const TABLES = [
  { table: "portal_messages", label: "New message" },
  { table: "portal_files", label: "New file" },
  { table: "portal_tasks", label: "Task update" },
  { table: "portal_onboarding_docs", label: "Document update" },
] as const;

const GLOBAL_TABLES = [
  { table: "project_inquiries", label: "New project enquiry" },
  { table: "bookings", label: "New booking" },
  { table: "messages", label: "New site message" },
] as const;

function ensurePermission() {
  if (typeof Notification === "undefined") return;
  if (Notification.permission === "default") {
    Notification.requestPermission().catch(() => {});
  }
}

function systemNotify(title: string, body: string) {
  if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
  // Push even when tab is visible for revision requests (admin needs to know)
  try {
    new Notification(title, { body, icon: "/favicon.svg" });
  } catch {
    /* noop */
  }
}

function systemNotifyAlways(title: string, body: string) {
  // Always fires regardless of tab visibility — used for high-priority events like revisions
  if (typeof Notification === "undefined") return;
  if (Notification.permission !== "granted") {
    Notification.requestPermission().then((perm) => {
      if (perm === "granted") {
        try { new Notification(title, { body, icon: "/favicon.svg" }); } catch { /* noop */ }
      }
    }).catch(() => {});
    return;
  }
  try {
    new Notification(title, { body, icon: "/favicon.svg" });
  } catch {
    /* noop */
  }
}

/** Subscribe to portal events and surface toast + system notifications. */
export function useRealtimeNotifications({ clientId, global, watchRevisions }: NotifyConfig) {
  const startedAt = useRef<number>(Date.now());

  useEffect(() => {
    ensurePermission();
    const channels: ReturnType<typeof supabase.channel>[] = [];

    for (const t of TABLES) {
      const filter = clientId ? `client_id=eq.${clientId}` : undefined;
      const ch = supabase.channel(`notify_${t.table}_${clientId ?? "all"}`);
      ch.on(
        "postgres_changes",
        filter
          ? { event: "INSERT", schema: "public", table: t.table, filter }
          : { event: "INSERT", schema: "public", table: t.table },
        (payload) => {
          // Skip events from before mount
          const created = (payload.new as { created_at?: string })?.created_at;
          if (created && new Date(created).getTime() < startedAt.current - 5000) return;
          const desc = (payload.new as { title?: string; body?: string; name?: string })?.title
            ?? (payload.new as { body?: string })?.body
            ?? (payload.new as { name?: string })?.name
            ?? "";
          toast(t.label, { description: desc.slice(0, 80) });
          systemNotify(t.label, desc.slice(0, 120));
        }
      );
      ch.subscribe();
      channels.push(ch);
    }

    if (global) {
      for (const t of GLOBAL_TABLES) {
        const ch = supabase.channel(`notify_global_${t.table}`);
        ch.on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: t.table },
          (payload) => {
            const created = (payload.new as { created_at?: string })?.created_at;
            if (created && new Date(created).getTime() < startedAt.current - 5000) return;
            const who = (payload.new as { name?: string })?.name ?? "";
            const msg = (payload.new as { message?: string; subject?: string })?.message
              ?? (payload.new as { subject?: string })?.subject
              ?? "";
            const body = [who, msg].filter(Boolean).join(" — ");
            toast(t.label, { description: body.slice(0, 80) });
            systemNotify(t.label, body.slice(0, 120));
          }
        );
        ch.subscribe();
        channels.push(ch);
      }
    }

    // ─── Revision push notifications (admin) ──────────────────────────────────
    // When watchRevisions=true (admin portal), fire a push notification whenever
    // a client submits a new revision request, even if the tab is in focus.
    if (watchRevisions) {
      const revCh = supabase.channel(`notify_revisions_admin`);
      revCh.on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "portal_revision_requests" },
        (payload) => {
          const created = (payload.new as { created_at?: string })?.created_at;
          if (created && new Date(created).getTime() < startedAt.current - 5000) return;
          const desc = (payload.new as { description?: string })?.description ?? "";
          const title = "New Revision Request";
          // Toast in-app
          toast(title, {
            description: desc.slice(0, 100),
            duration: 8000,
          });
          // Always-on push notification so admin sees it even if tab is open elsewhere
          systemNotifyAlways(title, desc.slice(0, 120));
        }
      );
      revCh.subscribe();
      channels.push(revCh);
    }

    return () => {
      channels.forEach((c) => supabase.removeChannel(c));
    };
  }, [clientId, global, watchRevisions]);
}
