import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";
import { AdminGate } from "./components/admin/AdminGate";
import { AdminLayout } from "./components/admin/AdminLayout";

const rootEl = document.getElementById("root")!;
createRoot(rootEl).render(
  <StrictMode>
    <AdminGate>
      <AdminLayout />
    </AdminGate>
  </StrictMode>
);
