# EAssets Studio — Monorepo Deploy Guide

## Structure

```
eassets-monorepo/
├── apps/
│   ├── web/      → eassets.studio           (main public site)
│   ├── admin/    → admin.eassets.studio      (admin panel)
│   └── client/   → client.eassets.studio     (client portal)
└── packages/
    ├── ui/        → shared shadcn/ui components
    ├── supabase/  → shared supabase client + types
    └── config/    → shared tailwind + ts config
```

---

## Step 1 — Push to GitHub

```bash
cd eassets-monorepo
git init
git add .
git commit -m "initial monorepo setup"
git remote add origin https://github.com/YOUR_USERNAME/eassets-studio.git
git push -u origin main
```

---

## Step 2 — Create 3 Vercel Projects

Go to https://vercel.com → **Add New Project** → Import the **same GitHub repo 3 times**.

### Project 1 — Main Website
| Setting | Value |
|---|---|
| Project Name | `eassets-web` |
| Root Directory | `apps/web` |
| Build Command | `npm run build` |
| Output Directory | `dist` |
| Install Command | `npm install` |

### Project 2 — Admin Panel
| Setting | Value |
|---|---|
| Project Name | `eassets-admin` |
| Root Directory | `apps/admin` |
| Build Command | `npm run build` |
| Output Directory | `dist` |
| Install Command | `npm install` |

### Project 3 — Client Portal
| Setting | Value |
|---|---|
| Project Name | `eassets-client` |
| Root Directory | `apps/client` |
| Build Command | `npm run build` |
| Output Directory | `dist` |
| Install Command | `npm install` |

---

## Step 3 — Add Custom Domains

In each Vercel project → **Settings → Domains**:

| Project | Domain |
|---|---|
| eassets-web | `eassets.studio` |
| eassets-admin | `admin.eassets.studio` |
| eassets-client | `client.eassets.studio` |

---

## Step 4 — Environment Variables

Add in **each** Vercel project → **Settings → Environment Variables**:

```
VITE_SUPABASE_URL=https://jbqgjqyeopolflojihtq.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here
```

---

## Step 5 — Local Development

```bash
# Install all dependencies from root
npm install

# Run each app separately
npm run dev:web      # → localhost:5173
npm run dev:admin    # → localhost:5174
npm run dev:client   # → localhost:5175
```

---

## Auto Deploys

Every GitHub push → Vercel detects which app changed → only redeploys that app. Other apps untouched. ✅
