-- Run in: Supabase SQL Editor
-- This is the missing table that powers credential generation in /portal and /admin → Client Portals.

create table if not exists public.client_portal_users (
  id uuid primary key default gen_random_uuid(),
  user_id text not null unique,
  password_hash text not null,
  client_id uuid references public.clients(id) on delete cascade,
  client_name text not null,
  client_email text not null,
  company text,
  is_active boolean not null default true,
  last_login timestamptz,
  created_at timestamptz not null default now()
);

alter table public.client_portal_users enable row level security;

drop policy if exists "client_portal_users_all" on public.client_portal_users;
create policy "client_portal_users_all"
  on public.client_portal_users for all using (true) with check (true);

create index if not exists client_portal_users_client_idx
  on public.client_portal_users(client_id);
create index if not exists client_portal_users_user_idx
  on public.client_portal_users(user_id);
