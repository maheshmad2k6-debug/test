-- Run in: https://supabase.com/dashboard/project/jbqgjqyeopolflojihtq/sql/new

-- ─── Tasks ────────────────────────────────────────────────────────────────────
create table if not exists public.portal_tasks (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null,
  title text not null,
  description text,
  status text not null default 'todo' check (status in ('todo','in_progress','done')),
  due_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.portal_tasks enable row level security;
drop policy if exists "portal_tasks_all" on public.portal_tasks;
create policy "portal_tasks_all" on public.portal_tasks for all using (true) with check (true);
create index if not exists portal_tasks_client_idx on public.portal_tasks(client_id);

-- ─── Messages ─────────────────────────────────────────────────────────────────
create table if not exists public.portal_messages (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null,
  sender text not null check (sender in ('admin','client')),
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.portal_messages enable row level security;
drop policy if exists "portal_messages_all" on public.portal_messages;
create policy "portal_messages_all" on public.portal_messages for all using (true) with check (true);
create index if not exists portal_messages_client_idx on public.portal_messages(client_id, created_at);

-- ─── Files ────────────────────────────────────────────────────────────────────
create table if not exists public.portal_files (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null,
  uploader text not null check (uploader in ('admin','client')),
  name text not null,
  mime text,
  size integer,
  storage_path text not null,
  created_at timestamptz not null default now()
);
alter table public.portal_files enable row level security;
drop policy if exists "portal_files_all" on public.portal_files;
create policy "portal_files_all" on public.portal_files for all using (true) with check (true);
create index if not exists portal_files_client_idx on public.portal_files(client_id);

-- ─── Onboarding Documents ────────────────────────────────────────────────────
create table if not exists public.portal_onboarding_docs (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null,
  title text not null,
  description text,
  doc_storage_path text,
  doc_name text,
  doc_mime text,
  status text not null default 'pending' check (status in ('pending','esigned','accepted','rejected','changes')),
  client_comment text,
  signature_name text,
  signed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.portal_onboarding_docs enable row level security;
drop policy if exists "portal_onboarding_all" on public.portal_onboarding_docs;
create policy "portal_onboarding_all" on public.portal_onboarding_docs for all using (true) with check (true);
create index if not exists portal_onboarding_client_idx on public.portal_onboarding_docs(client_id);

-- ─── Reports (one per client, upserted) ──────────────────────────────────────
create table if not exists public.portal_reports (
  client_id uuid primary key,
  stage text,
  progress_pct integer default 0,
  notes text,
  milestones jsonb default '[]'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.portal_reports enable row level security;
drop policy if exists "portal_reports_all" on public.portal_reports;
create policy "portal_reports_all" on public.portal_reports for all using (true) with check (true);

-- ─── Storage bucket ──────────────────────────────────────────────────────────
insert into storage.buckets (id, name, public)
values ('portal-files', 'portal-files', true)
on conflict (id) do nothing;

drop policy if exists "portal_files_storage_all" on storage.objects;
create policy "portal_files_storage_all" on storage.objects
  for all using (bucket_id = 'portal-files') with check (bucket_id = 'portal-files');

-- ─── Realtime ────────────────────────────────────────────────────────────────
alter publication supabase_realtime add table public.portal_tasks;
alter publication supabase_realtime add table public.portal_messages;
alter publication supabase_realtime add table public.portal_files;
alter publication supabase_realtime add table public.portal_onboarding_docs;
alter publication supabase_realtime add table public.portal_reports;
