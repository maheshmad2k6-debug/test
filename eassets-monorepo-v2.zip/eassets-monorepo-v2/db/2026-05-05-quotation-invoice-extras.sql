-- Run in: https://supabase.com/dashboard/project/jbqgjqyeopolflojihtq/sql/new

alter table public.invoices
  add column if not exists razorpay_button_html text;

alter table public.quotations
  add column if not exists notes text,
  add column if not exists payment_terms text,
  add column if not exists razorpay_button_html text;
