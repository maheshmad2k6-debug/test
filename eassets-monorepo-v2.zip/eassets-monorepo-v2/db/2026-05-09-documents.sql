-- Run in: https://supabase.com/dashboard/project/jbqgjqyeopolflojihtq/sql/new

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.clients(id) on delete set null,
  client_name text,
  client_email text,
  doc_type text not null,
  title text not null,
  body text not null default '',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.documents enable row level security;

create policy "documents_all_anon" on public.documents
  for all using (true) with check (true);

create index if not exists documents_client_id_idx on public.documents(client_id);
create index if not exists documents_doc_type_idx on public.documents(doc_type);
