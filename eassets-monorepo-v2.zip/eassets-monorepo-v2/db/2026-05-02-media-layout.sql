-- Per-media layout control
-- Run in: https://supabase.com/dashboard/project/jbqgjqyeopolflojihtq/sql/new

alter table public.project_media
  add column if not exists layout text not null default 'full';

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'project_media_layout_check' and conrelid = 'public.project_media'::regclass
  ) then
    alter table public.project_media
      add constraint project_media_layout_check
      check (layout in ('hero','full','left','right','mockup'));
  end if;
end $$;
