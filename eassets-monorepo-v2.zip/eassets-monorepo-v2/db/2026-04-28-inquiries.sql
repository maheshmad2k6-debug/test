-- ═════════════════════════════════════════════════════════════════════════════
-- EAssets Studio · Project Inquiries
-- HOW TO RUN: paste in Supabase SQL editor and run.
-- ═════════════════════════════════════════════════════════════════════════════

create table if not exists public.project_inquiries (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid references public.projects(id) on delete set null,
  project_title text,
  name        text not null,
  email       text not null,
  phone       text,
  message     text,
  status      text not null default 'new' check (status in ('new','contacted','closed')),
  created_at  timestamptz not null default now()
);

create index if not exists project_inquiries_created_idx on public.project_inquiries(created_at desc);

alter table public.project_inquiries enable row level security;

drop policy if exists "inquiries_anon_insert" on public.project_inquiries;
drop policy if exists "inquiries_anon_all"    on public.project_inquiries;
create policy "inquiries_anon_all" on public.project_inquiries
  for all using (true) with check (true);
