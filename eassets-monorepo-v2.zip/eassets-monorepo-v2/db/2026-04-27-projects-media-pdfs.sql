-- ═════════════════════════════════════════════════════════════════════════════
-- EAssets Studio · Supabase migration  (idempotent — safe to re-run)
--
-- HOW TO RUN:
--   1. Open https://supabase.com/dashboard/project/jbqgjqyeopolflojihtq/sql/new
--   2. Paste this entire file
--   3. Click "Run"
-- ═════════════════════════════════════════════════════════════════════════════

-- ─── 1. Projects table ───────────────────────────────────────────────────────
create table if not exists public.projects (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  created_at  timestamptz not null default now()
);

-- Add any missing columns (works whether table is brand-new or pre-existing)
alter table public.projects
  add column if not exists description text,
  add column if not exists sector      text,
  add column if not exists url         text,
  add column if not exists cover_url   text,
  add column if not exists cover_type  text,
  add column if not exists sort_order  int  not null default 0,
  add column if not exists published   boolean not null default true;

-- Add CHECK on cover_type only if not already present
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'projects_cover_type_check' and conrelid = 'public.projects'::regclass
  ) then
    alter table public.projects
      add constraint projects_cover_type_check
      check (cover_type is null or cover_type in ('image','video'));
  end if;
end $$;

alter table public.projects enable row level security;

drop policy if exists "projects_public_read" on public.projects;
drop policy if exists "projects_anon_write"  on public.projects;
create policy "projects_public_read" on public.projects
  for select using (coalesce(published, true) = true);
create policy "projects_anon_write" on public.projects
  for all using (true) with check (true);


-- ─── 2. Project media (multiple images/videos per project) ───────────────────
create table if not exists public.project_media (
  id           uuid primary key default gen_random_uuid(),
  project_id   uuid not null references public.projects(id) on delete cascade,
  url          text not null,
  storage_path text,
  type         text not null check (type in ('image','video')),
  sort_order   int  not null default 0,
  created_at   timestamptz not null default now()
);
create index if not exists project_media_project_idx on public.project_media(project_id);
alter table public.project_media enable row level security;

drop policy if exists "project_media_public_read" on public.project_media;
drop policy if exists "project_media_anon_write"  on public.project_media;
create policy "project_media_public_read" on public.project_media for select using (true);
create policy "project_media_anon_write"  on public.project_media for all using (true) with check (true);


-- ─── 3. Storage bucket: project media (no size limit) ────────────────────────
insert into storage.buckets (id, name, public, file_size_limit)
values ('projects-media', 'projects-media', true, null)
on conflict (id) do update set public = true, file_size_limit = null;

drop policy if exists "projects_media_public_read" on storage.objects;
drop policy if exists "projects_media_anon_write"  on storage.objects;
create policy "projects_media_public_read" on storage.objects
  for select using (bucket_id = 'projects-media');
create policy "projects_media_anon_write" on storage.objects
  for all using (bucket_id = 'projects-media') with check (bucket_id = 'projects-media');


-- ─── 4. Storage bucket: generated PDFs ───────────────────────────────────────
insert into storage.buckets (id, name, public, file_size_limit)
values ('documents', 'documents', true, 26214400)
on conflict (id) do update set public = true;

drop policy if exists "documents_public_read" on storage.objects;
drop policy if exists "documents_anon_write"  on storage.objects;
create policy "documents_public_read" on storage.objects
  for select using (bucket_id = 'documents');
create policy "documents_anon_write" on storage.objects
  for all using (bucket_id = 'documents') with check (bucket_id = 'documents');


-- ─── 5. PDF URL columns on invoices & quotations ─────────────────────────────
alter table public.invoices
  add column if not exists pdf_url         text,
  add column if not exists pdf_uploaded_at timestamptz;

alter table public.quotations
  add column if not exists pdf_url         text,
  add column if not exists pdf_uploaded_at timestamptz,
  add column if not exists currency        text default 'INR',
  add column if not exists budget_min      numeric,
  add column if not exists budget_max      numeric;


-- ─── 6. Timezone-correct booking timestamp ───────────────────────────────────
alter table public.bookings
  add column if not exists scheduled_at timestamptz;

-- Best-effort backfill from legacy date + time_slot (assumes IST)
update public.bookings
set scheduled_at = (
  (date::text || ' ' || coalesce(time_slot,'09:00 AM'))::timestamp at time zone 'Asia/Kolkata'
)
where scheduled_at is null and date is not null;


-- ─── DONE ────────────────────────────────────────────────────────────────────
-- Verify:
--   select * from public.projects limit 1;
--   select id from storage.buckets where id in ('projects-media','documents');
