// supabase/functions/send-email/index.ts
// Deploy:   supabase functions deploy send-email --no-verify-jwt
// Secret:   supabase secrets set BREVO_API_KEY=your_key_here

const BREVO_API_URL = "https://api.brevo.com/v3/smtp/email";
const OWNER_EMAIL = "hreassets@gmail.com";
const OWNER_NAME = "eassets.studio";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// ─── HTML Templates ───────────────────────────────────────────────────────────

function contactOwnerHtml(name: string, email: string, message: string, company?: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#0a0a0a;font-family:'Helvetica Neue',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0a;padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:#111;border-radius:16px 16px 0 0;padding:32px 40px;border-bottom:2px solid #e11d48;">
    <table width="100%"><tr>
      <td><span style="font-size:22px;font-weight:900;color:#e11d48;">eassets</span><span style="font-size:22px;font-weight:900;color:#fff;">.studio</span></td>
      <td align="right"><span style="background:#e11d48;color:#fff;font-size:11px;font-weight:700;padding:5px 14px;border-radius:99px;text-transform:uppercase;letter-spacing:1px;">New Message</span></td>
    </tr></table>
  </td></tr>
  <tr><td style="background:#111111;padding:36px 40px;">
    <h2 style="margin:0 0 6px;color:#fff;font-size:20px;font-weight:700;">You have a new message 📬</h2>
    <p style="margin:0 0 24px;color:#777;font-size:13px;">Via the eassets.studio contact form</p>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border-radius:12px;overflow:hidden;margin-bottom:24px;">
      <tr><td style="padding:14px 20px;border-bottom:1px solid #2a2a2a;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:3px;">From</span>
        <span style="color:#fff;font-size:14px;font-weight:600;">${name}</span>
      </td></tr>
      <tr><td style="padding:14px 20px;border-bottom:1px solid #2a2a2a;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:3px;">Email</span>
        <a href="mailto:${email}" style="color:#e11d48;font-size:14px;text-decoration:none;">${email}</a>
      </td></tr>
      ${company ? `<tr><td style="padding:14px 20px;border-bottom:1px solid #2a2a2a;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:3px;">Company</span>
        <span style="color:#fff;font-size:14px;">${company}</span>
      </td></tr>` : ""}
      <tr><td style="padding:14px 20px;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:8px;">Message</span>
        <span style="color:#ccc;font-size:14px;line-height:1.6;white-space:pre-wrap;">${message}</span>
      </td></tr>
    </table>
    <a href="mailto:${email}" style="display:inline-block;background:#e11d48;color:#fff;font-size:13px;font-weight:700;padding:13px 26px;border-radius:99px;text-decoration:none;">Reply to ${name} →</a>
  </td></tr>
  <tr><td style="background:#0d0d0d;border-radius:0 0 16px 16px;padding:20px 40px;border-top:1px solid #1f1f1f;">
    <p style="margin:0;color:#444;font-size:11px;text-align:center;">eassets.studio — Premium Digital Studio | hreassets@gmail.com</p>
  </td></tr>
</table>
</td></tr></table>
</body></html>`;
}

function contactCustomerHtml(name: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#0a0a0a;font-family:'Helvetica Neue',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0a;padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:#111;border-radius:16px 16px 0 0;padding:32px 40px;border-bottom:2px solid #e11d48;">
    <span style="font-size:26px;font-weight:900;color:#e11d48;">eassets</span><span style="font-size:26px;font-weight:900;color:#fff;">.studio</span>
  </td></tr>
  <tr><td style="background:#111111;padding:48px 40px;text-align:center;">
    <h1 style="margin:0 0 10px;color:#fff;font-size:24px;font-weight:800;">Message Received! ✦</h1>
    <p style="margin:0 0 6px;color:#aaa;font-size:15px;">Hi <strong style="color:#fff;">${name}</strong>,</p>
    <p style="margin:0 0 28px;color:#777;font-size:14px;line-height:1.7;max-width:400px;margin-left:auto;margin-right:auto;">
      Your message has been received.<br/>We'll get back to you within <strong style="color:#e11d48;">48 hours</strong>.
    </p>
    <a href="https://eassets.studio" style="display:inline-block;background:#e11d48;color:#fff;font-size:13px;font-weight:700;padding:13px 30px;border-radius:99px;text-decoration:none;">Visit our studio →</a>
  </td></tr>
  <tr><td style="background:#0d0d0d;border-radius:0 0 16px 16px;padding:20px 40px;border-top:1px solid #1f1f1f;">
    <p style="margin:0;color:#444;font-size:11px;text-align:center;">eassets.studio — Premium Digital Studio | hreassets@gmail.com</p>
  </td></tr>
</table>
</td></tr></table>
</body></html>`;
}

function bookingOwnerHtml(name: string, email: string, mode: string, date?: string, time?: string, message?: string): string {
  const isCall = mode === "call";
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#0a0a0a;font-family:'Helvetica Neue',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0a;padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:#111;border-radius:16px 16px 0 0;padding:32px 40px;border-bottom:2px solid #e11d48;">
    <table width="100%"><tr>
      <td><span style="font-size:22px;font-weight:900;color:#e11d48;">eassets</span><span style="font-size:22px;font-weight:900;color:#fff;">.studio</span></td>
      <td align="right"><span style="background:${isCall ? "#7c3aed" : "#059669"};color:#fff;font-size:11px;font-weight:700;padding:5px 14px;border-radius:99px;text-transform:uppercase;letter-spacing:1px;">${isCall ? "New Booking (Pending)" : "Quote Request"}</span></td>
    </tr></table>
  </td></tr>
  <tr><td style="background:#111111;padding:36px 40px;">
    <h2 style="margin:0 0 6px;color:#fff;font-size:20px;font-weight:700;">${isCall ? "New discovery call request ⏳" : "New quote request received 📄"}</h2>
    <p style="margin:0 0 8px;color:#777;font-size:13px;">Via the eassets.studio contact form</p>
    ${isCall ? `<p style="margin:0 0 24px;padding:10px 16px;background:#7c3aed22;border:1px solid #7c3aed44;border-radius:8px;color:#a78bfa;font-size:12px;font-weight:600;">⚠️ Approval required — go to Admin &rarr; Bookings to confirm and send the client their confirmation email.</p>` : ""}
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border-radius:12px;overflow:hidden;margin-bottom:24px;">
      <tr><td style="padding:14px 20px;border-bottom:1px solid #2a2a2a;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:3px;">From</span>
        <span style="color:#fff;font-size:14px;font-weight:600;">${name}</span>
      </td></tr>
      <tr><td style="padding:14px 20px;border-bottom:1px solid #2a2a2a;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:3px;">Email</span>
        <a href="mailto:${email}" style="color:#e11d48;font-size:14px;text-decoration:none;">${email}</a>
      </td></tr>
      ${isCall && date ? `<tr><td style="padding:14px 20px;border-bottom:1px solid #2a2a2a;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:3px;">Requested Date</span>
        <span style="color:#fff;font-size:14px;">${date}</span>
      </td></tr>` : ""}
      ${isCall && time ? `<tr><td style="padding:14px 20px;border-bottom:1px solid #2a2a2a;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:3px;">Requested Time (IST)</span>
        <span style="color:#fff;font-size:14px;">${time}</span>
      </td></tr>` : ""}
      ${!isCall && message ? `<tr><td style="padding:14px 20px;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:8px;">Requirements</span>
        <span style="color:#ccc;font-size:14px;line-height:1.6;white-space:pre-wrap;">${message}</span>
      </td></tr>` : ""}
    </table>
    <a href="mailto:${email}" style="display:inline-block;background:#e11d48;color:#fff;font-size:13px;font-weight:700;padding:13px 26px;border-radius:99px;text-decoration:none;">Reply to ${name} →</a>
  </td></tr>
  <tr><td style="background:#0d0d0d;border-radius:0 0 16px 16px;padding:20px 40px;border-top:1px solid #1f1f1f;">
    <p style="margin:0;color:#444;font-size:11px;text-align:center;">eassets.studio — Premium Digital Studio | hreassets@gmail.com</p>
  </td></tr>
</table>
</td></tr></table>
</body></html>`;
}

function bookingCustomerHtml(name: string, mode: string, date?: string, time?: string): string {
  const isCall = mode === "call";
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#0a0a0a;font-family:'Helvetica Neue',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0a;padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:#111;border-radius:16px 16px 0 0;padding:32px 40px;border-bottom:2px solid #e11d48;">
    <span style="font-size:26px;font-weight:900;color:#e11d48;">eassets</span><span style="font-size:26px;font-weight:900;color:#fff;">.studio</span>
  </td></tr>
  <tr><td style="background:#111111;padding:48px 40px;text-align:center;">
    <h1 style="margin:0 0 10px;color:#fff;font-size:24px;font-weight:800;">${isCall ? "Quote Request Received! 📄" : "Quote Request Received! 📄"}</h1>
    <p style="margin:0 0 6px;color:#aaa;font-size:15px;">Hi <strong style="color:#fff;">${name}</strong>,</p>
    <p style="margin:0 0 28px;color:#777;font-size:14px;line-height:1.7;max-width:400px;margin-left:auto;margin-right:auto;">
      We've received your quote request and will send a detailed estimate within <strong style="color:#e11d48;">48 hours</strong>.
    </p>
    <a href="https://eassets.studio" style="display:inline-block;background:#e11d48;color:#fff;font-size:13px;font-weight:700;padding:13px 30px;border-radius:99px;text-decoration:none;">Visit our studio →</a>
  </td></tr>
  <tr><td style="background:#0d0d0d;border-radius:0 0 16px 16px;padding:20px 40px;border-top:1px solid #1f1f1f;">
    <p style="margin:0;color:#444;font-size:11px;text-align:center;">eassets.studio — Premium Digital Studio | hreassets@gmail.com</p>
  </td></tr>
</table>
</td></tr></table>
</body></html>`;
}

/** Sent to client ONLY after admin approves the discovery call */
function bookingConfirmationClientHtml(name: string, date: string, time: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#0a0a0a;font-family:'Helvetica Neue',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0a;padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:#111;border-radius:16px 16px 0 0;padding:32px 40px;border-bottom:2px solid #e11d48;">
    <span style="font-size:26px;font-weight:900;color:#e11d48;">eassets</span><span style="font-size:26px;font-weight:900;color:#fff;">.studio</span>
  </td></tr>
  <tr><td style="background:#111111;padding:48px 40px;text-align:center;">
    <div style="display:inline-block;background:#16a34a22;border:1px solid #16a34a44;border-radius:99px;padding:8px 20px;margin-bottom:20px;">
      <span style="color:#4ade80;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;">✓ Confirmed</span>
    </div>
    <h1 style="margin:0 0 10px;color:#fff;font-size:26px;font-weight:800;">Call Confirmed! 📅</h1>
    <p style="margin:0 0 6px;color:#aaa;font-size:15px;">Hi <strong style="color:#fff;">${name}</strong>,</p>
    <p style="margin:0 0 8px;color:#777;font-size:14px;line-height:1.7;max-width:420px;margin-left:auto;margin-right:auto;">
      Great news — your discovery call has been <strong style="color:#4ade80;">approved</strong>!
    </p>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border-radius:12px;overflow:hidden;margin:24px 0;text-align:left;">
      <tr><td style="padding:16px 24px;border-bottom:1px solid #2a2a2a;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:4px;">Date</span>
        <span style="color:#fff;font-size:15px;font-weight:700;">${date}</span>
      </td></tr>
      <tr><td style="padding:16px 24px;">
        <span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:4px;">Time (IST)</span>
        <span style="color:#e11d48;font-size:15px;font-weight:700;">${time}</span>
      </td></tr>
    </table>
    <p style="margin:0 0 28px;color:#777;font-size:13px;line-height:1.7;">
      We'll send you a calendar invite shortly. If you need to reschedule, please reply to this email.
    </p>
    <a href="https://eassets.studio" style="display:inline-block;background:#e11d48;color:#fff;font-size:13px;font-weight:700;padding:13px 30px;border-radius:99px;text-decoration:none;">Visit our studio →</a>
  </td></tr>
  <tr><td style="background:#0d0d0d;border-radius:0 0 16px 16px;padding:20px 40px;border-top:1px solid #1f1f1f;">
    <p style="margin:0;color:#444;font-size:11px;text-align:center;">eassets.studio — Premium Digital Studio | hreassets@gmail.com</p>
  </td></tr>
</table>
</td></tr></table>
</body></html>`;
}

function invoiceEmailHtml(
  recipientName: string, invoiceNumber: string, total: string,
  currency: string, isOwner: boolean, clientEmail?: string
): string {
  const title = isOwner ? "Invoice Sent to Client 🧾" : "Your Invoice is Ready 🧾";
  const subtitle = isOwner
    ? `Invoice <strong>${invoiceNumber}</strong> has been dispatched to <strong>${recipientName}</strong> (${clientEmail}).`
    : `Hi <strong>${recipientName}</strong>, your invoice from eassets.studio is ready. Please find the invoice attached to this email.`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#0a0a0a;font-family:'Helvetica Neue',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0a;padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:#111;border-radius:16px 16px 0 0;padding:32px 40px;border-bottom:2px solid #e11d48;">
    <table width="100%"><tr>
      <td><span style="font-size:22px;font-weight:900;color:#e11d48;">eassets</span><span style="font-size:22px;font-weight:900;color:#fff;">.studio</span></td>
      <td align="right"><span style="background:#1d4ed8;color:#fff;font-size:11px;font-weight:700;padding:5px 14px;border-radius:99px;text-transform:uppercase;letter-spacing:1px;">Invoice</span></td>
    </tr></table>
  </td></tr>
  <tr><td style="background:#111111;padding:36px 40px;">
    <h2 style="margin:0 0 8px;color:#fff;font-size:20px;font-weight:700;">${title}</h2>
    <p style="margin:0 0 24px;color:#777;font-size:13px;line-height:1.6;">${subtitle}</p>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border-radius:12px;overflow:hidden;margin-bottom:24px;">
      <tr><td style="padding:18px 24px;border-bottom:1px solid #2a2a2a;">
        <span style="font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;">Invoice Number</span>
        <span style="display:block;color:#e11d48;font-size:20px;font-weight:800;font-family:monospace;margin-top:3px;">${invoiceNumber}</span>
      </td></tr>
      <tr><td style="padding:18px 24px;">
        <span style="font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;">Amount Due</span>
        <span style="display:block;color:#fff;font-size:26px;font-weight:800;margin-top:3px;">${total} <span style="font-size:13px;color:#555;">${currency}</span></span>
      </td></tr>
    </table>
    ${!isOwner ? `<p style="color:#777;font-size:13px;margin:0 0 16px;">📎 The full invoice is attached as a PDF.</p>` : ""}
    <p style="color:#555;font-size:12px;margin:0;">Questions? <a href="mailto:hreassets@gmail.com" style="color:#e11d48;text-decoration:none;">hreassets@gmail.com</a></p>
  </td></tr>
  <tr><td style="background:#0d0d0d;border-radius:0 0 16px 16px;padding:20px 40px;border-top:1px solid #1f1f1f;">
    <p style="margin:0;color:#444;font-size:11px;text-align:center;">eassets.studio — Premium Digital Studio | hreassets@gmail.com</p>
  </td></tr>
</table>
</td></tr></table>
</body></html>`;
}

function quotationEmailHtml(
  recipientName: string, quotationId: string, total: string,
  isOwner: boolean, clientEmail?: string
): string {
  const title = isOwner ? "Quotation Sent to Client 📄" : "Your Quotation from eassets.studio 📄";
  const subtitle = isOwner
    ? `Quotation <strong>#${quotationId}</strong> has been dispatched to <strong>${recipientName}</strong> (${clientEmail}).`
    : `Hi <strong>${recipientName}</strong>, your quotation from eassets.studio is ready. Please find the quotation attached to this email.`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#0a0a0a;font-family:'Helvetica Neue',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0a;padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:#111;border-radius:16px 16px 0 0;padding:32px 40px;border-bottom:2px solid #e11d48;">
    <table width="100%"><tr>
      <td><span style="font-size:22px;font-weight:900;color:#e11d48;">eassets</span><span style="font-size:22px;font-weight:900;color:#fff;">.studio</span></td>
      <td align="right"><span style="background:#059669;color:#fff;font-size:11px;font-weight:700;padding:5px 14px;border-radius:99px;text-transform:uppercase;letter-spacing:1px;">Quotation</span></td>
    </tr></table>
  </td></tr>
  <tr><td style="background:#111111;padding:36px 40px;">
    <h2 style="margin:0 0 8px;color:#fff;font-size:20px;font-weight:700;">${title}</h2>
    <p style="margin:0 0 24px;color:#777;font-size:13px;line-height:1.6;">${subtitle}</p>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border-radius:12px;overflow:hidden;margin-bottom:24px;">
      <tr><td style="padding:18px 24px;border-bottom:1px solid #2a2a2a;">
        <span style="font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;">Quotation ID</span>
        <span style="display:block;color:#e11d48;font-size:20px;font-weight:800;font-family:monospace;margin-top:3px;">#${quotationId.toUpperCase()}</span>
      </td></tr>
      <tr><td style="padding:18px 24px;">
        <span style="font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#555;">Quoted Amount</span>
        <span style="display:block;color:#fff;font-size:26px;font-weight:800;margin-top:3px;">${total}</span>
      </td></tr>
    </table>
    ${!isOwner ? `<p style="color:#777;font-size:13px;margin:0 0 16px;">📎 The full quotation is attached as a PDF.</p>` : ""}
    <p style="color:#555;font-size:11px;margin:0 0 4px;">Valid for 30 days from date of issue.</p>
    <p style="color:#555;font-size:12px;margin:0;">Questions? <a href="mailto:hreassets@gmail.com" style="color:#e11d48;text-decoration:none;">hreassets@gmail.com</a></p>
  </td></tr>
  <tr><td style="background:#0d0d0d;border-radius:0 0 16px 16px;padding:20px 40px;border-top:1px solid #1f1f1f;">
    <p style="margin:0;color:#444;font-size:11px;text-align:center;">eassets.studio — Premium Digital Studio | hreassets@gmail.com</p>
  </td></tr>
</table>
</td></tr></table>
</body></html>`;
}

// ─── Brevo sender ─────────────────────────────────────────────────────────────

interface Attachment {
  content: string;   // base64
  name: string;
  type: string;
}

async function sendBrevoEmail(opts: {
  toEmail: string;
  toName: string;
  subject: string;
  html: string;
  attachments?: Attachment[];
}): Promise<void> {
  const apiKey = Deno.env.get("BREVO_API_KEY");
  if (!apiKey) throw new Error("BREVO_API_KEY secret is not set in Supabase");

  const payload: Record<string, unknown> = {
    sender: { name: OWNER_NAME, email: OWNER_EMAIL },
    to: [{ email: opts.toEmail, name: opts.toName }],
    subject: opts.subject,
    htmlContent: opts.html,
  };

  if (opts.attachments && opts.attachments.length > 0) {
    payload.attachment = opts.attachments.map((a) => ({
      content: a.content,
      name: a.name,
    }));
  }

  const res = await fetch(BREVO_API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", "api-key": apiKey },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Brevo API error ${res.status}: ${body}`);
  }
}

// ─── Main handler ─────────────────────────────────────────────────────────────

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    const body = await req.json();
    const { type } = body;

    if (type === "contact") {
      const { name, email, message, company } = body;
      if (!name || !email || !message) throw new Error("Missing required fields: name, email, message");

      await Promise.all([
        sendBrevoEmail({
          toEmail: OWNER_EMAIL, toName: OWNER_NAME,
          subject: `New message from ${name} — eassets.studio`,
          html: contactOwnerHtml(name, email, message, company),
        }),
        sendBrevoEmail({
          toEmail: email, toName: name,
          subject: "We received your message — eassets.studio",
          html: contactCustomerHtml(name),
        }),
      ]);

    } else if (type === "booking") {
      const { name, email, mode, date, time, message, pendingCall } = body;
      if (!name || !email || !mode) throw new Error("Missing required booking fields");

      if (pendingCall && mode === "call") {
        // Discovery call: only notify owner — client confirmation is withheld until admin approves
        await sendBrevoEmail({
          toEmail: OWNER_EMAIL, toName: OWNER_NAME,
          subject: `New discovery call request from ${name} — ${date} at ${time} [PENDING APPROVAL]`,
          html: bookingOwnerHtml(name, email, mode, date, time, message),
        });
      } else if (mode === "call") {
        // Fallback: both emails (shouldn't normally be reached for calls)
        await Promise.all([
          sendBrevoEmail({
            toEmail: OWNER_EMAIL, toName: OWNER_NAME,
            subject: `New booking from ${name} — ${date} at ${time}`,
            html: bookingOwnerHtml(name, email, mode, date, time, message),
          }),
          sendBrevoEmail({
            toEmail: email, toName: name,
            subject: "Your discovery call is confirmed — eassets.studio",
            html: bookingCustomerHtml(name, mode, date, time),
          }),
        ]);
      } else {
        // Quote request: notify owner + send receipt to client
        await Promise.all([
          sendBrevoEmail({
            toEmail: OWNER_EMAIL, toName: OWNER_NAME,
            subject: `New quote request from ${name} — eassets.studio`,
            html: bookingOwnerHtml(name, email, mode, date, time, message),
          }),
          sendBrevoEmail({
            toEmail: email, toName: name,
            subject: "We received your quote request — eassets.studio",
            html: bookingCustomerHtml(name, mode, date, time),
          }),
        ]);
      }

    } else if (type === "booking_confirm") {
      // ── Admin approved a discovery call — send confirmation email to client ──
      const { name, email, date, time } = body;
      if (!name || !email || !date || !time) throw new Error("Missing required fields for booking_confirm: name, email, date, time");

      await sendBrevoEmail({
        toEmail: email, toName: name,
        subject: "Your discovery call is confirmed — eassets.studio ✓",
        html: bookingConfirmationClientHtml(name, date, time),
      });

    } else if (type === "invoice") {
      const { clientEmail, clientName, invoiceNumber, total, currency, pdfBase64 } = body;
      if (!clientEmail || !clientName || !invoiceNumber) throw new Error("Missing required invoice fields");

      const attachments: Attachment[] = pdfBase64
        ? [{ content: pdfBase64, name: `invoice-${invoiceNumber}.pdf`, type: "application/pdf" }]
        : [];

      await Promise.all([
        sendBrevoEmail({
          toEmail: OWNER_EMAIL, toName: OWNER_NAME,
          subject: `Invoice ${invoiceNumber} sent to ${clientName}`,
          html: invoiceEmailHtml(clientName, invoiceNumber, total, currency, true, clientEmail),
          attachments,
        }),
        sendBrevoEmail({
          toEmail: clientEmail, toName: clientName,
          subject: `Your Invoice ${invoiceNumber} from eassets.studio`,
          html: invoiceEmailHtml(clientName, invoiceNumber, total, currency, false),
          attachments,
        }),
      ]);

    } else if (type === "quotation") {
      const { clientEmail, clientName, quotationId, total, pdfBase64 } = body;
      if (!clientEmail || !clientName || !quotationId) throw new Error("Missing required quotation fields");

      const attachments: Attachment[] = pdfBase64
        ? [{ content: pdfBase64, name: `quotation-${quotationId}.pdf`, type: "application/pdf" }]
        : [];

      await Promise.all([
        sendBrevoEmail({
          toEmail: OWNER_EMAIL, toName: OWNER_NAME,
          subject: `Quotation sent to ${clientName} — eassets.studio`,
          html: quotationEmailHtml(clientName, quotationId, total, true, clientEmail),
          attachments,
        }),
        sendBrevoEmail({
          toEmail: clientEmail, toName: clientName,
          subject: "Your Quotation from eassets.studio",
          html: quotationEmailHtml(clientName, quotationId, total, false),
          attachments,
        }),
      ]);

    } else {
      return new Response(JSON.stringify({ error: `Unknown type: "${type}"` }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[send-email]", message);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
